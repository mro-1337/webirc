IRC Client — desktop and terminal versions for Windows and Linux
================================================================

NEW IN THIS VERSION (2.2)
-------------------------
COPY AND PASTE
  Desktop:
  - Ctrl+V pastes into the typing box even if you clicked in the chat.
  - Ctrl+C / Ctrl+X / Ctrl+A work in the typing box as usual
    (right-click it for Cut / Copy / Paste / Select all too).
  - To copy chat text: right-click a line -> Copy message / whole line /
    link / nickname, or "Select text to copy…" (also Ctrl+Shift+C, or
    Ctrl+C when the typing box isn't selected) opens the window's text
    where you can select any part with the mouse and press Ctrl+C.
  - F11 = full screen on/off.
  Terminal:
  - Ctrl+C copies what's in the typing box. With an empty box it opens a
    copy menu: last message, pick any line, pick a link, whole window.
    (Ctrl+C no longer quits — use Ctrl+Q or /quit.)
  - Ctrl+X cuts the typing box, Ctrl+V pastes. Your terminal's own paste
    (right-click, Shift+Insert, Ctrl+Shift+V) works too.
  - Right-click the chat = copy menu. Right-click the typing box = paste.
  - F9 turns the mouse off so you can select text with your terminal
    (most terminals also let you Shift+drag with the mouse on).
  - Over SSH, copying also uses the OSC 52 code, which puts the text on
    your own computer's clipboard in terminals that support it (Windows
    Terminal, xterm, kitty, WezTerm, iTerm2…).
  Both: pasting several lines asks whether to send them as separate
  messages (sent at a safe speed) or put them on one line.

KEYS CHANGED (terminal)
  F11 is no longer used, so your terminal's full-screen key works.
  DCC chats & transfers moved to F4 (or /transfers). Adding a server is
  in the F5 Servers menu. Channel settings: F10, or /chanset (handy if
  your terminal uses F10 for its menu).

VERSION 2.1
-----------
Both versions:
- Servers window: every server in one list with Edit, Connect/Disconnect,
  Delete, Add, Import and Export.
  Desktop: "Servers" button (bottom left; box icon in tab mode). The
  "Server" button at the top edits the server you're in.
  Terminal: F5 (first item edits the server you're in).
- Import servers: /import path/to/file  (add "all" at the end to also
  take the nickname, theme and other settings). It reads:
    * this program's settings file or an exported copy
    * a WebIRC config.txt (lines it doesn't know are skipped and listed)
    * HexChat  servlist.conf  (with channels, commands, SASL login)
    * mIRC     servers.ini    (one entry per network)
    * a text file with one server per line, for example:
        irc.libera.chat 6697 tls #linux #go
        ircs://irc.oftc.net:6697/#debian
        irc.example.net:6667
  Servers you already have (same address and port) are updated rather
  than duplicated. Imported servers are not connected automatically.
- Export: /export file.txt  saves your servers and settings (includes
  passwords — keep it safe).
- SASL login: "Account (SASL)" and "Account password" in the server
  settings log you in to your registered nick while connecting (Libera,
  OFTC, etc. — no NickServ command needed).
- Channel list: browse and search a server's channels, click/Enter to
  join. Desktop: "Channel list" button in a server window.
  Terminal: F12, or /list.
- Ignore list: /ignore nick  or  /ignore *!*@host  hides their messages,
  notices, CTCP and DCC offers. /unignore nick. Also in Settings.
- Highlight words: words besides your nick that count as a mention
  (/highlight add word, or Settings). Mentions and private messages show
  a desktop notification (terminal: a beep). Turn off in Settings.
- Flood protection: when you paste lots of lines they're sent at a safe
  speed so the server doesn't disconnect you.
- More commands: /cycle (leave and rejoin), /back, /umode, /motd, /whowas.
- Terminal: F2 now jumps to the people list (Enter on a name = menu);
  F2 again hides it.

PREVIOUS VERSION (2.0)
----------------------
Both versions:
- DCC chat and DCC file transfers (send and receive).
- CTCP: check someone's client version, ping (lag), time, etc.
- Click a name in the people list for a menu: private chat, whois,
  CTCP version/ping/time, DCC chat, send a file, op/deop, voice/devoice,
  kick, ban, kick+ban (choose the ban mask), copy nickname.
- Channel settings: change topic, modes (+t +n +m +i +s +p), channel
  key (password), user limit, and view/remove/add bans.
  Desktop: "Channel" button at the top.  Terminal: F10.
- Transfers window: Desktop: download button at the top.  Terminal: F4.

BAN MASKS (pick one when banning)
  1  *!*@host        everyone from their address (most common)
  2  *!*user@host    their user name at their address
  3  *!user@host     exact user name and address
  4  *!*@*.domain    their whole provider / network
  5  nick!*@*        only that nickname, anywhere
  6  nick!*@host     that nickname from their address

DCC — PORTS AND ROUTERS
  Settings: "DCC ports" (e.g. 5000-5010, or one port like 5000; empty =
  any free port), "DCC public IP" (your internet address, only needed if
  you are behind a router and people can't connect to you), and
  "Downloads folder" (default: "downloads" next to the program).
  To RECEIVE from people you don't need any ports open. To SEND files or
  offer chats from behind a router, forward the DCC port range to your
  computer and fill in your public IP. If you can't open ports, receivers
  using "passive DCC" (port 0) still work: your client answers those
  automatically. Incoming offers always ask before accepting; files are
  never overwritten ("file (1).ext" is used instead). Resume is not
  supported.
  In settings file: dccports: 5000-5010   dccip: 1.2.3.4   downloads: D:\Files

OLDER VERSIONS
--------------
Both versions:
- Channel list: a pane on the left, or tabs along the top or bottom.
  Desktop: Settings > Channel list.  Terminal: F6, or /tabs top|bottom|left
- Alt + arrow keys switch channels/tabs (terminal also: F7 / F8,
  Alt+1..9, /next, /prev, /win N, /win #channel)
- More color themes: dracula, nord, gruvbox-dark, gruvbox-light,
  monokai, ocean, amber, sepia (plus dark, light, midnight, bbs,
  terminal, solarized-dark/light, classic, high-contrast)
- The "Add server" form starts empty (leave Port empty for 6697
  encrypted / 6667 plain)

Desktop version:
- Font and text size in Settings (any installed .ttf/.otf font, or
  put fonts in a "fonts" folder next to the program). Ctrl + / Ctrl - /
  Ctrl 0 make text bigger / smaller / normal.
- Drag the dividers to resize the channel pane and the people pane.
  The ≡ button (top left) hides/shows the channel pane; the person
  button (top right) hides/shows the people pane.
- Window opacity (see-through window) in Settings, 20-100%.
- Tray icon (Show / Hide / Quit). Optional: close button hides to tray.
- Copy: right-click any chat line -> Copy message / whole line / link /
  nickname / whole window. Paste with Ctrl+V in the typing box.

Terminal version:
- Copy: press F9 to turn the mouse off, then select text and copy it with
  your terminal as usual; F9 again turns the mouse back on.
  Paste works with your terminal's paste (Ctrl+Shift+V, Shift+Insert or
  right-click, depending on the terminal).
- Fixed: a stray "q" appearing in Bitvise/PuTTY and similar terminals.

Two programs, built from the same code and sharing the same IRC engine:

  Desktop (windowed) version         Terminal version
  --------------------------         ----------------
  Windows 64-bit: IRC-Client.exe     Windows 64-bit: irc-term.exe
  Windows 32-bit: IRC-Client-32bit.exe
                                     Windows 32-bit: irc-term-32bit.exe
  Linux 64-bit:   irc-client-linux-amd64
                                     Linux 64-bit:   irc-term-linux-amd64
  Linux 32-bit:   irc-client-linux-386
                                     Linux 32-bit:   irc-term-linux-386
                                     Raspberry Pi:   irc-term-linux-arm64 / -armv7

start with no servers: click "Servers" (desktop) or press F5
start with no servers: click "Add server" (desktop) or press F4
(terminal) to add one.

PORTABLE
--------
Everything is kept in the program's own folder — nothing is written to
your user profile or the registry:
  irc-client.txt   your settings and servers
  logs\            chat logs: logs\<server>\<#channel>.log
Copy the whole folder to a USB stick or another computer and it keeps
working. Keep it somewhere you can write to (not C:\Program Files).

STARTING
--------
Windows: double-click IRC-Client.exe (desktop) or irc-term.exe (opens a
         console window). If SmartScreen warns, click "More info" -> "Run
         anyway" (the programs aren't code-signed).
Linux:   chmod +x irc-client-linux-amd64  then  ./irc-client-linux-amd64
         The terminal version runs in any terminal: ./irc-term-linux-amd64
         The desktop version needs a normal desktop (X11 or Wayland with
         XWayland); it uses the system's OpenGL (libGL), which every
         desktop Linux has.

Your nickname starts as your computer login name plus two numbers.
Change it in Settings (desktop) or with F6 (terminal).

PORTABLE — EVERYTHING STAYS IN THE PROGRAM'S FOLDER
---------------------------------------------------
Nothing is installed and nothing is written anywhere else. Next to the
program you'll find:

  irc-client.txt   your settings: servers, nickname, channels, theme,
                   connect commands (created on first start)
  logs\            chat logs:  logs\<server name>\<#channel>.log
                   (private chats: <nick>.log, server messages: server.log)

Copy the whole folder to a USB stick or another computer and it keeps
working with all your settings. Put it in a folder you can write to
(e.g. Desktop or Documents, not C:\Program Files). Turn logging on/off in
Settings (desktop) / F6 (terminal), or "logging: yes/no" in the file.
Desktop: Settings -> "Open logs folder".  Terminal: type /logs.

SETTINGS FILE
-------------
irc-client.txt uses the same easy "setting: value" style as WebIRC:

  nick: myname
  altnick: myname_
  realname: My Name
  theme: dark
  showmedia: yes
  showjoins: yes
  logging: yes

  server: irc.example.net
  port: 6697
  name: Example
  encryption: yes
  selfsigned: no
  password:
  autoconnect: yes
  channel: #bbs
  command: /msg NickServ IDENTIFY mypassword
  sasluser: myaccount
  saslpassword: mypassword

Each  server:  line starts a new server. "command:" lines run every time
that server connects ($me = your nick, /wait 2 = pause 2 seconds), then
the channels are joined. The programs update this file themselves when
you add servers, change settings or join/leave channels.

DESKTOP VERSION
---------------
- Left: servers and channels (green dot = connected). Numbers show unread
  messages; red = someone said your name or messaged you privately.
- Middle: chat. Pictures and YouTube links show as pictures right in the
  chat — click one to open it. Video/audio links get a Play button.
  Links are clickable. Your name being mentioned is highlighted.
- Right: people in the channel — click a name to chat privately.
- Top buttons: Connect/Disconnect, server settings (gear: address, port,
  encryption, self-signed, password, nickname, channels, connect
  commands), Light/Dark mode, show/hide people.
- Settings (bottom left): nickname, theme (Dark, Light, Midnight, BBS,
  Green terminal, Solarized dark/light, Classic mIRC, High contrast),
  show pictures, show join/part messages.
- Keys: Enter send, Tab complete a nickname, Up/Down previous messages,
  Ctrl+Tab / Ctrl+Shift+Tab next/previous window, PgUp/PgDn scroll.

TERMINAL VERSION
----------------
Works over SSH too (Bitvise, PuTTY, etc.). Set IRCTERM_RAW=1 only if you
want the program to use the newest terminal codes (cursor shape etc.).
Works in Windows Terminal, Command Prompt, PowerShell and Linux terminals.
The mouse works (click channels, names, links).
  F1 help                  F2 people list (again = hide)
  F3 open the last link    F4 DCC chats & transfers
  F5 servers (edit, connect, add, import, export)
  F10 channel settings     F12 channel list
  Ctrl+C copy · Ctrl+X cut · Ctrl+V paste · right-click chat = copy menu
  F6 settings (nickname, theme, pictures, joins)
  F7 / F8  previous / next window (also Ctrl+P/Ctrl+N, Alt+Left/Right)
  Alt+1..9  jump to window    /next /prev /win N /win #chan  (commands)
  Tab complete nick   Up/Down history   PgUp/PgDn scroll   Ctrl+Q quit (not Ctrl+C)
Picture/video links are marked [picture] / [video] / [YouTube video];
click the link (or type /open N, /links lists them) to open it in your
picture viewer or browser. /theme light, /theme bbs ... change colors.

COMMANDS (both versions)
------------------------
/join #chan [key]  /part [reason]  /msg nick text  /query nick
/me does something  /nick newname  /topic text  /whois nick
/notice target text  /away [msg]  /kick nick  /op /deop /voice nick
/ns ... (NickServ)  /cs ... (ChanServ)  /raw LINE  /connect  /disconnect
/close (leave channel / close chat)  /clear  /theme name  /help  /quit
/ban nick [1-6] [reason]   /kickban (/kb) nick [1-6] [reason]
/unban mask   /bans (list bans)   /topic new topic
/version nick  /ping nick  /time nick  /clientinfo nick  /ctcp nick WHAT
/dcc chat nick   /dcc send nick path/to/file   /dcc list
/dcc accept N   /dcc decline N   /dcc cancel N
(DCC chats open in a window named =nick; just type there.)
/ignore nick  /unignore nick  /highlight add|del word  /list [filter]
/cycle  /back  /umode +x  /motd  /import file [all]  /export file
Terminal only: /server host port [tls] [selfsigned]  /links  /open N

ZNC / BNC BOUNCERS
------------------
In the server settings fill in "Server username" and "Server password"
(in irc-client.txt:  serveruser:  and  password: ). They're sent the way
bouncers expect:  username:password . To pick a network on the bouncer,
use  username/network  as the username (e.g.  bob/libera ).

ENCRYPTION
----------
Works with old and new servers (TLS 1.0 - 1.3). If a server uses a
self-made certificate, tick "Allow self-signed certificate" (or
selfsigned: yes). If something's wrong, the server window explains it,
e.g. "this port answered WITHOUT encryption — turn encryption off".

PICTURES AND VIDEOS
-------------------
Desktop version:
- Pictures show right in the chat. Animated GIFs play. Click a picture
  to see it bigger inside the program.
- Video links (mp4, webm, mov, ...) show a preview picture. Click it to
  play the video inside the chat (picture only) — use "Open with sound"
  to play it with sound in your normal video player.
- YouTube links show the video's picture; click to watch in your browser.
Terminal version: pictures and video previews are drawn with colored
blocks (works best in Windows Terminal or a modern Linux terminal).

Video previews/playback need ffmpeg (free):
  Windows: download an ffmpeg build (e.g. from gyan.dev or the
           BtbN builds on GitHub) and put ffmpeg.exe in the same folder
           as IRC-Client.exe (or in an "ffmpeg" or "ffmpeg\bin" folder
           next to it). That keeps it portable.
  Linux:   sudo apt install ffmpeg   (or put ffmpeg next to the program)
Without ffmpeg, videos just get a "Play video" button that opens them in
your normal player. Pictures and GIFs don't need ffmpeg.

BUILDING FROM SOURCE
--------------------
Needs Go 1.24+.
Terminal version (no C compiler needed):
  CGO_ENABLED=0 go build -o irc-term ./cmd/ircterm
Desktop version (uses the Fyne toolkit, needs a C compiler):
  Linux:   sudo apt install gcc libgl1-mesa-dev xorg-dev
           go build -o irc-client ./cmd/ircgui
  Windows: install a MinGW-w64 gcc, then
           go build -ldflags "-H windowsgui" -o IRC-Client.exe ./cmd/ircgui
  (cross-compiling for Windows from Linux:
   CGO_ENABLED=1 GOOS=windows GOARCH=amd64 CC=x86_64-w64-mingw32-gcc \
   go build -ldflags "-H windowsgui" -o IRC-Client.exe ./cmd/ircgui)
Note: go.mod points some libraries at their GitHub mirrors (the
"replace" lines); normal internet access works with or without them.

Layout: core/ = shared IRC engine, cmd/ircgui = desktop app,
        cmd/ircterm = terminal app.
