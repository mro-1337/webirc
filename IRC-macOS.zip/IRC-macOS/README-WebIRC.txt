WebIRC — password-protected web IRC client for Windows and Linux
===============================================================

STARTING IT ON WINDOWS
----------------------
1. Double-click  WebIRC.exe  (use WebIRC-32bit.exe on 32-bit Windows).
   If Windows SmartScreen warns you, click "More info" -> "Run anyway"
   (the program isn't code-signed). If Windows Firewall asks, click
   "Allow" so other devices on your network can reach it.
2. Settings are in  config.txt  next to the .exe. The included one
   uses web port 9080, entry password  kaboom , and connects everyone
   to irc.bbses.info port 16669 (encrypted) channel #bbs.
   Change the entry password in config.txt if you like.
3. Your browser opens to  http://localhost:9080/
   Type the entry password, then create your account. The FIRST account
   created is the admin.

Keep the black console window open — closing it stops the server.

STARTING IT ON LINUX
--------------------
Pick the file for your machine:
  webirc-linux-amd64   normal 64-bit PCs and servers
  webirc-linux-386     32-bit PCs
  webirc-linux-arm64   Raspberry Pi 4/5 (64-bit OS), ARM servers
  webirc-linux-armv7   Raspberry Pi with a 32-bit OS
Then in a terminal:
  chmod +x webirc-linux-amd64
  ./webirc-linux-amd64 -nobrowser
Open http://localhost:9080/ (or http://SERVER-IP:9080/ from another
computer). Keep config.txt next to the program; webirc-data is created
there too.
To keep it running after you log out:
  nohup ./webirc-linux-amd64 -nobrowser &
Ports below 1024 need root, so keep 9080 or similar.

CONFIG.TXT  (next to the program — restart WebIRC after editing)
----------
Open it with Notepad (or any text editor). Every setting is one line:

  setting: value

Lines starting with # are notes. Yes/no settings take  yes  or  no.

The web page settings come first:

  webport: 9080          port the web page runs on
  listen: all            all   = other devices on your network can connect
                         local = only this computer
  https: no              yes = encrypted web page (self-signed certificate;
                         your browser warns once — accept it). Use this if
                         you open WebIRC to the internet.
  entrypassword: abc123  password everyone types BEFORE they can log in or
                         create an account. Leave empty to turn it off.
  signup: yes            yes = people can create their own accounts
                         no  = only admins create accounts (Users screen)
  customservers: yes     no  = users can't add their own IRC servers
  theme: dark            default look for everyone: dark, light, auto,
                         midnight, bbs, terminal, solarized-dark,
                         solarized-light, classic, high-contrast
                         (auto follows the computer's light/dark mode)

Then the IRC servers EVERYONE is connected to. Each one starts with a
server: line, and the lines under it belong to that server:

  server: irc.bbses.info
  port: 16669
  name: irc.BBSes.info
  encryption: yes
  selfsigned: yes
  password:
  channel: #bbs

  server:      address of the IRC server
  port:        the IRC server's port
  name:        name shown in the server list (optional)
  encryption:  yes = encrypted (TLS/SSL), no = plain
  selfsigned:  yes = accept self-signed certificates
  password:    server password (leave empty if none)
  channel:     a channel everyone joins and can't leave. Use one
               channel: line per channel (or  channel: #a, #b ).

To add another server, copy the whole block, paste it below, and change
it. To remove a server, delete its block.

Users can't remove these servers or leave these channels (they show a
lock). If kicked, they rejoin. Users can still change their own nickname
and join extra channels.

If config.txt has a mistake, WebIRC says which line in the console
window. If you delete config.txt, WebIRC makes a fresh one with the
settings above.

If you used an older WebIRC with config.json, it's converted to
config.txt automatically (the old file is renamed config.json.old).

Command-line options (override config.txt):
  -port 9000   -https   -nobrowser   -config C:\path\config.txt   -data C:\path
  -test host:port   check an IRC server's settings and exit

COMMANDS TO RUN WHEN CONNECTED (per user)
-----------------------------------------
Each user can save commands that run automatically every time a server
connects — for example logging in to NickServ. Click the gear icon next
to a server name in the left list, and fill in "Commands to run when
connected", one per line:

  /msg NickServ IDENTIFY mypassword
  /mode $me +x
  /wait 2
  /join #secret key
  PRIVMSG ChanServ :INVITE #private

- Lines starting with / work like commands typed in the chat.
- Other lines are sent to the IRC server exactly as written.
- $me (or $nick) is replaced with your current nickname.
- /wait 2 pauses for 2 seconds before the next line.
- Channels are joined after the commands, so NickServ logins finish first.
- These are saved per user and per server; other users can't see them.
  /msg lines are sent quietly (no window opens showing your password).

THEMES (LIGHT / DARK MODE)
--------------------------
Click the sun / moon button at the top left to switch between light and
dark. Settings (bottom left) has more themes: Auto, Light, Dark, Midnight,
BBS (ANSI), Green terminal, Solarized dark/light, Classic (mIRC) and High
contrast. Dark is the default. Each person's choice is saved in their
own browser. The default for new visitors is the  theme:  line in
config.txt.

ENCRYPTED IRC / SELF-SIGNED CERTIFICATES
----------------------------------------
- encryption: yes  works with old and new servers (TLS 1.0 to 1.3).
- If the server's certificate is self-made (self-signed), expired, or
  for a different name, set  selfsigned: yes  (or tick "Allow
  self-signed / invalid certificate" when adding a server).
- If something goes wrong, the server window explains it, e.g. "this
  port answered WITHOUT encryption — turn encryption off".

To check a server yourself, open a Command Prompt in the WebIRC folder:
  WebIRC.exe -test irc.bbses.info:16669
(on Linux:  ./webirc-linux-amd64 -test irc.bbses.info:16669 )
It tries the port with and without encryption, shows the certificate,
and tells you which settings to use.

ZNC / BNC BOUNCERS
------------------
When adding a server, fill in "Server username" and "Server password".
They're sent the way bouncers expect:  username:password . To pick a
network on the bouncer, use  username/network  as the username.

USING IT FROM YOUR PHONE / OTHER COMPUTERS
------------------------------------------
The console window lists addresses like http://192.168.1.20:9080/ —
open that from any device on your network.

USER ACCOUNTS
-------------
Admins see a "Users" link at the bottom left: create accounts, delete
them, reset passwords, make other users admins. Everyone can change their
own password with the "Password" link. Each user has their own nicknames,
channels and (if allowed) their own extra IRC servers.

IRC
---
- Connections stay online even when the browser is closed, and
  reconnect by themselves if they drop.
- Channels you /join are remembered and re-joined automatically.
- Up to 1000 lines per channel are kept while WebIRC runs.

IMAGES AND VIDEOS
-----------------
Links to images (jpg, png, gif, webp...), videos (mp4, webm, imgur gifv),
audio, and YouTube show right in the chat. Click an image to see it full
size. Media loads through the WebIRC server by default so the person
posting the link can't see your IP. Change this under "Settings".

COMMANDS
--------
Type /help in the chat. Common ones: /join #chan, /part, /msg nick text,
/me action, /nick newname, /topic text, /whois nick, /raw COMMAND.

FILES
-----
  config.txt                    your settings (above)
  webirc-data/webirc-data.json  accounts and each user's IRC settings
  webirc-data/secret.key        used to sign entry-password cookies
Keep the webirc-data folder private: IRC server and NickServ passwords
are stored in it readable (they must be sent to IRC servers). Login
passwords are stored hashed (PBKDF2-SHA256), never in plain text.

SECURITY NOTES
--------------
- 8 wrong entry passwords or logins from one address = 10 minute wait.
- If you open WebIRC to the internet (port forwarding), set
  https: yes  and use strong passwords.
- People stay logged in for 30 days; restarting WebIRC logs everyone
  out (the entry password is remembered by their browser).

BUILDING FROM SOURCE
--------------------
Install Go 1.24+, then in the source folder:
  Linux 64-bit:   CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -ldflags "-s -w" -o webirc-linux-amd64 .
  Windows 64-bit: CGO_ENABLED=0 GOOS=windows GOARCH=amd64 go build -ldflags "-s -w" -o WebIRC.exe .
  Use GOARCH=386 for 32-bit.
