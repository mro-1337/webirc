package main

import (
	"net"
	"net/http"
	"sync"
	"time"
)

const sessionCookie = "webirc_session"
const sessionLifetime = 30 * 24 * time.Hour

type session struct {
	user    string
	expires time.Time
}

// Sessions holds logged-in browser sessions in memory.
type Sessions struct {
	mu       sync.Mutex
	sessions map[string]*session
	fails    map[string][]time.Time // failed logins per IP
}

func NewSessions() *Sessions {
	return &Sessions{sessions: map[string]*session{}, fails: map[string][]time.Time{}}
}

func (s *Sessions) Create(user string) string {
	tok := randomID(32)
	s.mu.Lock()
	s.sessions[tok] = &session{user: user, expires: time.Now().Add(sessionLifetime)}
	s.mu.Unlock()
	return tok
}

func (s *Sessions) Get(tok string) (string, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	ss, ok := s.sessions[tok]
	if !ok || time.Now().After(ss.expires) {
		delete(s.sessions, tok)
		return "", false
	}
	return ss.user, true
}

func (s *Sessions) Delete(tok string) {
	s.mu.Lock()
	delete(s.sessions, tok)
	s.mu.Unlock()
}

// DeleteUser logs a user out everywhere (used on delete / password change).
func (s *Sessions) DeleteUser(user string, except string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for tok, ss := range s.sessions {
		if ss.user == user && tok != except {
			delete(s.sessions, tok)
		}
	}
}

// Blocked reports whether this IP has too many recent failed logins.
func (s *Sessions) Blocked(ip string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	cut := time.Now().Add(-10 * time.Minute)
	recent := s.fails[ip][:0]
	for _, t := range s.fails[ip] {
		if t.After(cut) {
			recent = append(recent, t)
		}
	}
	s.fails[ip] = recent
	return len(recent) >= 8
}

func (s *Sessions) Fail(ip string) {
	s.mu.Lock()
	s.fails[ip] = append(s.fails[ip], time.Now())
	s.mu.Unlock()
}

func (s *Sessions) ClearFails(ip string) {
	s.mu.Lock()
	delete(s.fails, ip)
	s.mu.Unlock()
}

func clientIP(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}

func setSessionCookie(w http.ResponseWriter, r *http.Request, tok string, maxAge int) {
	http.SetCookie(w, &http.Cookie{
		Name:     sessionCookie,
		Value:    tok,
		Path:     "/",
		MaxAge:   maxAge,
		HttpOnly: true,
		Secure:   r.TLS != nil,
		SameSite: http.SameSiteStrictMode,
	})
}
