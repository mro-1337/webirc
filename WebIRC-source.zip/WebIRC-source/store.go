package main

import (
	"crypto/pbkdf2"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Network is one saved IRC server configuration belonging to a user.
type Network struct {
	ID           string   `json:"id"`
	Name         string   `json:"name"`
	Host         string   `json:"host"`
	Port         int      `json:"port"`
	TLS          bool     `json:"tls"`
	SkipVerify   bool     `json:"skipVerify"`
	ServerUser   string   `json:"serverUser"` // bouncer login (ZNC/BNC)
	ServerPass   string   `json:"serverPass"`
	Nick         string   `json:"nick"`
	AltNick      string   `json:"altNick"`
	Username     string   `json:"username"`
	Realname     string   `json:"realname"`
	NickServPass string   `json:"nickservPass"`
	Channels     []string `json:"channels"`
	AutoConnect  bool     `json:"autoConnect"`
	// Commands run (in order) right after connecting, e.g.
	// "/msg NickServ IDENTIFY secret" or "MODE $me +x".
	Commands []string `json:"commands"`

	// Set from config.txt for servers every user is forced onto (not saved).
	Forced         bool     `json:"forced,omitempty"`
	ForcedChannels []string `json:"forcedChannels,omitempty"`
}

// User is a login account for the web interface.
type User struct {
	Username string     `json:"username"`
	PassHash string     `json:"passHash"`
	Admin    bool       `json:"admin"`
	Created  time.Time  `json:"created"`
	Networks []*Network `json:"networks"`
}

type storeFile struct {
	Users map[string]*User `json:"users"`
}

// Store keeps all accounts and their IRC networks in a JSON file.
type Store struct {
	mu    sync.Mutex
	path  string
	users map[string]*User
}

var validUsername = regexp.MustCompile(`^[A-Za-z0-9_.\-]{1,32}$`)

func OpenStore(path string) (*Store, error) {
	s := &Store{path: path, users: map[string]*User{}}
	b, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return s, nil
	}
	if err != nil {
		return nil, err
	}
	var f storeFile
	if err := json.Unmarshal(b, &f); err != nil {
		return nil, fmt.Errorf("reading %s: %w", path, err)
	}
	if f.Users != nil {
		s.users = f.Users
	}
	return s, nil
}

// saveLocked writes the file atomically. Caller holds s.mu.
func (s *Store) saveLocked() error {
	b, err := json.MarshalIndent(storeFile{Users: s.users}, "", "  ")
	if err != nil {
		return err
	}
	tmp := s.path + ".tmp"
	if err := os.WriteFile(tmp, b, 0600); err != nil {
		return err
	}
	return os.Rename(tmp, s.path)
}

func (s *Store) UserCount() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	return len(s.users)
}

func (s *Store) CreateUser(username, password string, admin bool) error {
	if !validUsername.MatchString(username) {
		return errors.New("username must be 1-32 letters, numbers, _ . or -")
	}
	if len(password) < 6 {
		return errors.New("password must be at least 6 characters")
	}
	h, err := hashPassword(password)
	if err != nil {
		return err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	key := strings.ToLower(username)
	if _, ok := s.users[key]; ok {
		return errors.New("that username already exists")
	}
	s.users[key] = &User{Username: username, PassHash: h, Admin: admin, Created: time.Now()}
	return s.saveLocked()
}

func (s *Store) DeleteUser(username string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	key := strings.ToLower(username)
	if _, ok := s.users[key]; !ok {
		return errors.New("no such user")
	}
	delete(s.users, key)
	return s.saveLocked()
}

func (s *Store) SetPassword(username, password string) error {
	if len(password) < 6 {
		return errors.New("password must be at least 6 characters")
	}
	h, err := hashPassword(password)
	if err != nil {
		return err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.users[strings.ToLower(username)]
	if !ok {
		return errors.New("no such user")
	}
	u.PassHash = h
	return s.saveLocked()
}

func (s *Store) SetAdmin(username string, admin bool) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.users[strings.ToLower(username)]
	if !ok {
		return errors.New("no such user")
	}
	u.Admin = admin
	return s.saveLocked()
}

// CheckLogin returns the canonical username if the password matches.
func (s *Store) CheckLogin(username, password string) (string, bool) {
	s.mu.Lock()
	u, ok := s.users[strings.ToLower(username)]
	var hash, name string
	if ok {
		hash, name = u.PassHash, u.Username
	}
	s.mu.Unlock()
	if !ok {
		// Spend the same time so usernames can't be guessed by timing.
		checkPassword(password, "pbkdf2$600000$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=")
		return "", false
	}
	return name, checkPassword(password, hash)
}

type UserInfo struct {
	Username string    `json:"username"`
	Admin    bool      `json:"admin"`
	Created  time.Time `json:"created"`
}

func (s *Store) GetUser(username string) (UserInfo, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.users[strings.ToLower(username)]
	if !ok {
		return UserInfo{}, false
	}
	return UserInfo{u.Username, u.Admin, u.Created}, true
}

func (s *Store) ListUsers() []UserInfo {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := []UserInfo{}
	for _, u := range s.users {
		out = append(out, UserInfo{u.Username, u.Admin, u.Created})
	}
	sort.Slice(out, func(i, j int) bool { return strings.ToLower(out[i].Username) < strings.ToLower(out[j].Username) })
	return out
}

func (s *Store) AdminCount() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	n := 0
	for _, u := range s.users {
		if u.Admin {
			n++
		}
	}
	return n
}

// Networks returns copies of a user's networks.
func (s *Store) Networks(username string) []Network {
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.users[strings.ToLower(username)]
	if !ok {
		return nil
	}
	out := make([]Network, 0, len(u.Networks))
	for _, n := range u.Networks {
		c := *n
		c.Channels = append([]string(nil), n.Channels...)
		out = append(out, c)
	}
	return out
}

func (s *Store) Network(username, id string) (Network, bool) {
	for _, n := range s.Networks(username) {
		if n.ID == id {
			return n, true
		}
	}
	return Network{}, false
}

// SaveNetwork adds or replaces a network. Returns the stored copy.
func (s *Store) SaveNetwork(username string, n Network) (Network, error) {
	n.Name = strings.TrimSpace(n.Name)
	n.Host = strings.TrimSpace(n.Host)
	n.Nick = strings.TrimSpace(n.Nick)
	if n.Host == "" {
		return n, errors.New("server address is required")
	}
	if n.Nick == "" || strings.ContainsAny(n.Nick, " ,*?!@#:") {
		return n, errors.New("a valid nickname is required")
	}
	if n.Port <= 0 || n.Port > 65535 {
		if n.TLS {
			n.Port = 6697
		} else {
			n.Port = 6667
		}
	}
	if n.Name == "" {
		n.Name = n.Host
	}
	if strings.TrimSpace(n.Username) == "" {
		n.Username = n.Nick
	}
	n.Username = strings.Fields(n.Username)[0]
	if strings.TrimSpace(n.Realname) == "" {
		n.Realname = n.Nick
	}
	n.Channels = cleanChannels(n.Channels)
	n.Forced, n.ForcedChannels = false, nil
	n.Commands = cleanCommands(n.Commands)

	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.users[strings.ToLower(username)]
	if !ok {
		return n, errors.New("no such user")
	}
	if n.ID == "" {
		n.ID = randomID(6)
		c := n
		u.Networks = append(u.Networks, &c)
	} else {
		found := false
		for i, old := range u.Networks {
			if old.ID == n.ID {
				c := n
				u.Networks[i] = &c
				found = true
			}
		}
		if !found {
			return n, errors.New("no such network")
		}
	}
	return n, s.saveLocked()
}

func (s *Store) DeleteNetwork(username, id string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.users[strings.ToLower(username)]
	if !ok {
		return errors.New("no such user")
	}
	for i, n := range u.Networks {
		if n.ID == id {
			u.Networks = append(u.Networks[:i], u.Networks[i+1:]...)
			return s.saveLocked()
		}
	}
	return errors.New("no such network")
}

// EnsureNetwork adds a network with this ID if the user doesn't have it yet.
func (s *Store) EnsureNetwork(username string, n Network) {
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.users[strings.ToLower(username)]
	if !ok {
		return
	}
	for _, x := range u.Networks {
		if x.ID == n.ID {
			return
		}
	}
	c := n
	u.Networks = append(u.Networks, &c)
	s.saveLocked()
}

// SetChannels updates the auto-join list (called when you /join or /part).
func (s *Store) SetChannels(username, id string, chans []string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.users[strings.ToLower(username)]
	if !ok {
		return
	}
	for _, n := range u.Networks {
		if n.ID == id {
			n.Channels = cleanChannels(chans)
			s.saveLocked()
		}
	}
}

func cleanChannels(in []string) []string {
	out := []string{}
	seen := map[string]bool{}
	for _, c := range in {
		c = strings.TrimSpace(c)
		if c == "" {
			continue
		}
		parts := strings.Fields(c)
		name := parts[0]
		if !strings.ContainsAny(name[:1], "#&+!") {
			name = "#" + name
		}
		if seen[strings.ToLower(name)] {
			continue
		}
		seen[strings.ToLower(name)] = true
		if len(parts) > 1 {
			name += " " + parts[1] // channel key
		}
		out = append(out, name)
	}
	return out
}

// ---- password hashing (PBKDF2-SHA256) ----

const pbkdf2Iter = 600000

func hashPassword(pw string) (string, error) {
	salt := make([]byte, 16)
	if _, err := rand.Read(salt); err != nil {
		return "", err
	}
	key, err := pbkdf2.Key(sha256.New, pw, salt, pbkdf2Iter, 32)
	if err != nil {
		return "", err
	}
	return fmt.Sprintf("pbkdf2$%d$%s$%s", pbkdf2Iter,
		base64.StdEncoding.EncodeToString(salt), base64.StdEncoding.EncodeToString(key)), nil
}

func checkPassword(pw, stored string) bool {
	p := strings.Split(stored, "$")
	if len(p) != 4 || p[0] != "pbkdf2" {
		return false
	}
	iter, err := strconv.Atoi(p[1])
	if err != nil || iter < 1 {
		return false
	}
	salt, err1 := base64.StdEncoding.DecodeString(p[2])
	want, err2 := base64.StdEncoding.DecodeString(p[3])
	if err1 != nil || err2 != nil {
		return false
	}
	got, err := pbkdf2.Key(sha256.New, pw, salt, iter, len(want))
	if err != nil {
		return false
	}
	return subtle.ConstantTimeCompare(got, want) == 1
}

func randomID(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func cleanCommands(in []string) []string {
	out := []string{}
	for _, c := range in {
		c = strings.TrimSpace(strings.NewReplacer("\r", "", "\n", " ").Replace(c))
		if c != "" && len(out) < 50 {
			if len(c) > 450 {
				c = c[:450]
			}
			out = append(out, c)
		}
	}
	return out
}
