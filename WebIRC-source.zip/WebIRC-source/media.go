package main

// Media proxy: images/videos posted in IRC are fetched by this server and
// passed to the browser, so people posting links can't see your IP address.
// Requests to private / local network addresses are blocked.

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"mime"
	"net"
	"net/http"
	"net/url"
	"path"
	"strings"
	"sync"
	"syscall"
	"time"
)

var errBlockedAddr = errors.New("address not allowed")

func blockedIP(ip net.IP) bool {
	if ip == nil {
		return true
	}
	if ip4 := ip.To4(); ip4 != nil {
		if ip4[0] == 0 || (ip4[0] == 100 && ip4[1]&0xc0 == 64) { // 0.0.0.0/8, 100.64.0.0/10
			return true
		}
	}
	return ip.IsLoopback() || ip.IsPrivate() || ip.IsUnspecified() || ip.IsLinkLocalUnicast() ||
		ip.IsLinkLocalMulticast() || ip.IsInterfaceLocalMulticast() || ip.IsMulticast()
}

func safeDialControl(network, address string, _ syscall.RawConn) error {
	host, _, err := net.SplitHostPort(address)
	if err != nil {
		return err
	}
	if blockedIP(net.ParseIP(host)) {
		return errBlockedAddr
	}
	return nil
}

var mediaClient = &http.Client{
	Transport: &http.Transport{
		Proxy: nil,
		DialContext: (&net.Dialer{
			Timeout: 15 * time.Second,
			Control: safeDialControl,
		}).DialContext,
		TLSHandshakeTimeout:   15 * time.Second,
		ResponseHeaderTimeout: 20 * time.Second,
		MaxIdleConns:          20,
		IdleConnTimeout:       60 * time.Second,
	},
	CheckRedirect: func(req *http.Request, via []*http.Request) error {
		if len(via) >= 5 {
			return errors.New("too many redirects")
		}
		if req.URL.Scheme != "http" && req.URL.Scheme != "https" {
			return errors.New("bad redirect")
		}
		return nil
	},
}

var imageExt = map[string]string{
	".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".gif": "image/gif",
	".webp": "image/webp", ".avif": "image/avif", ".bmp": "image/bmp",
}
var videoExt = map[string]string{
	".mp4": "video/mp4", ".m4v": "video/mp4", ".webm": "video/webm", ".mov": "video/quicktime", ".ogv": "video/ogg",
}
var audioExt = map[string]string{
	".mp3": "audio/mpeg", ".ogg": "audio/ogg", ".oga": "audio/ogg", ".wav": "audio/wav", ".m4a": "audio/mp4", ".flac": "audio/flac", ".opus": "audio/ogg",
}

// mediaKind returns "image", "video", "audio" or "" for a content type.
func mediaKind(ct string) string {
	mt, _, _ := mime.ParseMediaType(ct)
	switch {
	case mt == "image/svg+xml":
		return "" // SVG can contain scripts; never proxied
	case strings.HasPrefix(mt, "image/"):
		return "image"
	case strings.HasPrefix(mt, "video/"):
		return "video"
	case strings.HasPrefix(mt, "audio/"):
		return "audio"
	}
	return ""
}

func extType(u *url.URL) string {
	ext := strings.ToLower(path.Ext(u.Path))
	if t, ok := imageExt[ext]; ok {
		return t
	}
	if t, ok := videoExt[ext]; ok {
		return t
	}
	if t, ok := audioExt[ext]; ok {
		return t
	}
	return ""
}

func parseMediaURL(raw string) (*url.URL, error) {
	u, err := url.Parse(raw)
	if err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Hostname() == "" {
		return nil, errors.New("bad url")
	}
	if ip := net.ParseIP(u.Hostname()); ip != nil && blockedIP(ip) {
		return nil, errBlockedAddr
	}
	if strings.EqualFold(u.Hostname(), "localhost") {
		return nil, errBlockedAddr
	}
	return u, nil
}

func fetchMedia(ctx context.Context, u *url.URL, rangeHdr string) (*http.Response, error) {
	req, err := http.NewRequestWithContext(ctx, "GET", u.String(), nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "Mozilla/5.0 (compatible; WebIRC media fetcher)")
	req.Header.Set("Accept", "image/*,video/*,audio/*;q=0.9,*/*;q=0.5")
	if rangeHdr != "" {
		req.Header.Set("Range", rangeHdr)
	}
	return mediaClient.Do(req)
}

func (s *Server) handleMedia(w http.ResponseWriter, r *http.Request, user string) {
	u, err := parseMediaURL(r.URL.Query().Get("u"))
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	resp, err := fetchMedia(r.Context(), u, r.Header.Get("Range"))
	if err != nil {
		http.Error(w, "fetch failed", http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		http.Error(w, "remote error", http.StatusBadGateway)
		return
	}
	ct := resp.Header.Get("Content-Type")
	kind := mediaKind(ct)
	if kind == "" {
		// Some hosts send application/octet-stream; trust the file extension then.
		if et := extType(resp.Request.URL); et != "" && !strings.HasPrefix(ct, "text/") {
			ct, kind = et, mediaKind(et)
		}
	}
	if kind == "" {
		http.Error(w, "not an image or video", http.StatusUnsupportedMediaType)
		return
	}
	h := w.Header()
	h.Set("Content-Type", ct)
	for _, k := range []string{"Content-Length", "Content-Range", "Accept-Ranges", "Last-Modified", "ETag"} {
		if v := resp.Header.Get(k); v != "" {
			h.Set(k, v)
		}
	}
	h.Set("Cache-Control", "private, max-age=86400")
	h.Set("X-Content-Type-Options", "nosniff")
	h.Set("Content-Security-Policy", "sandbox; default-src 'none'")
	h.Set("Content-Disposition", "inline")
	w.WriteHeader(resp.StatusCode)
	var body io.Reader = resp.Body
	if kind == "image" {
		body = io.LimitReader(resp.Body, 50<<20)
	}
	io.Copy(w, body)
}

// ---- probe: figure out if an extension-less link is an image/video ----

type probeResult struct {
	Kind string `json:"kind"`
}

var probeCache = struct {
	sync.Mutex
	m map[string]string
}{m: map[string]string{}}

func (s *Server) handleProbe(w http.ResponseWriter, r *http.Request, user string) {
	raw := r.URL.Query().Get("u")
	probeCache.Lock()
	kind, ok := probeCache.m[raw]
	probeCache.Unlock()
	if !ok {
		kind = ""
		if u, err := parseMediaURL(raw); err == nil {
			ctx, cancel := context.WithTimeout(r.Context(), 12*time.Second)
			resp, err := fetchMedia(ctx, u, "bytes=0-0")
			if err == nil {
				if resp.StatusCode < 400 {
					kind = mediaKind(resp.Header.Get("Content-Type"))
				}
				resp.Body.Close()
			}
			cancel()
		}
		probeCache.Lock()
		if len(probeCache.m) > 5000 {
			probeCache.m = map[string]string{}
		}
		probeCache.m[raw] = kind
		probeCache.Unlock()
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(probeResult{Kind: kind})
}
