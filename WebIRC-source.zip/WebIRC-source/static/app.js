'use strict';
// WebIRC browser client

const $ = (id) => document.getElementById(id);
const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };

// ---------------------------------------------------------------------------
// Settings (kept in this browser)
// ---------------------------------------------------------------------------
const defaults = { theme: '', media: true, proxy: true, probe: true, joins: true, notify: false, maxh: 320 };
let settings = { ...defaults };
try { Object.assign(settings, JSON.parse(localStorage.getItem('webirc.settings') || '{}')); } catch (e) {}
function saveSettings() { try { localStorage.setItem('webirc.settings', JSON.stringify(settings)); } catch (e) {} }
document.documentElement.style.setProperty('--maxh', settings.maxh + 'px');

// ---------------------------------------------------------------------------
// Themes
// ---------------------------------------------------------------------------
const THEMES = [
  { id: 'dark', name: 'Dark', sw: ['#0f1216', '#161a20', '#3b82f6'] },
  { id: 'light', name: 'Light', sw: ['#ffffff', '#f5f6f8', '#3b82f6'] },
  { id: 'auto', name: 'Auto (system)', sw: ['#ffffff', '#0f1216', '#3b82f6'] },
  { id: 'midnight', name: 'Midnight', sw: ['#0b1020', '#16204a', '#7c5cff'] },
  { id: 'bbs', name: 'BBS (ANSI)', sw: ['#000000', '#0000a8', '#ffff55'] },
  { id: 'terminal', name: 'Green terminal', sw: ['#000000', '#0a1a0a', '#33ff66'] },
  { id: 'solarized-dark', name: 'Solarized dark', sw: ['#002b36', '#073642', '#268bd2'] },
  { id: 'solarized-light', name: 'Solarized light', sw: ['#fdf6e3', '#eee8d5', '#268bd2'] },
  { id: 'classic', name: 'Classic (mIRC)', sw: ['#ffffff', '#d4d0c8', '#000080'] },
  { id: 'high-contrast', name: 'High contrast', sw: ['#000000', '#ffffff', '#ffd600'] },
];
const DARK_THEMES = new Set(['dark', 'midnight', 'bbs', 'terminal', 'solarized-dark', 'high-contrast']);
let serverDefaultTheme = 'dark';
try { serverDefaultTheme = localStorage.getItem('webirc.defaultTheme') || 'dark'; } catch (e) {}

function currentTheme() { return settings.theme || serverDefaultTheme || 'dark'; }
function isDarkNow() {
  const t = currentTheme();
  if (t === 'auto') return window.matchMedia('(prefers-color-scheme: dark)').matches;
  return DARK_THEMES.has(t);
}
function applyTheme() {
  document.documentElement.setAttribute('data-theme', currentTheme());
  const icon = isDarkNow() ? '☀️' : '🌙';
  document.querySelectorAll('.theme-toggle').forEach(b => { b.textContent = icon; b.title = isDarkNow() ? 'Switch to light mode' : 'Switch to dark mode'; });
  document.querySelectorAll('.theme-chip').forEach(c => c.classList.toggle('sel', c.dataset.theme === currentTheme()));
}
function setTheme(t) { settings.theme = t; saveSettings(); applyTheme(); }
function buildThemeGrid() {
  const g = document.getElementById('themeGrid');
  if (!g || g.childElementCount) return;
  for (const t of THEMES) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'theme-chip'; b.dataset.theme = t.id;
    const sw = document.createElement('span'); sw.className = 'sw';
    for (const c of t.sw) { const x = document.createElement('span'); x.style.background = c; sw.append(x); }
    const n = document.createElement('span'); n.className = 'tn'; n.textContent = t.name;
    b.append(sw, n);
    b.onclick = () => setTheme(t.id);
    g.append(b);
  }
}
document.querySelectorAll('.theme-toggle').forEach(b => b.addEventListener('click', () => setTheme(isDarkNow() ? 'light' : 'dark')));
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);
applyTheme();

// ---------------------------------------------------------------------------
// API
// ---------------------------------------------------------------------------
async function api(method, path, body) {
  const opt = { method, headers: { 'X-WebIRC': '1' }, credentials: 'same-origin' };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  const r = await fetch(path, opt);
  let data = null;
  try { data = await r.json(); } catch (e) {}
  const authPaths = ['/api/login', '/api/gate', '/api/signup'];
  if (!authPaths.includes(path) && (r.status === 401 || (r.status === 403 && data && /entry password/.test(data.error)))) {
    boot(); throw new Error('please log in');
  }
  if (!r.ok) throw new Error((data && data.error) || ('error ' + r.status));
  return data;
}

function toast(msg) {
  const t = $('toast'); t.textContent = msg; t.classList.remove('hidden');
  clearTimeout(toast.timer); toast.timer = setTimeout(() => t.classList.add('hidden'), 4500);
}

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
const S = {
  user: null,
  nets: new Map(),   // id -> {id,name,status,nick,error,config,bufs: Map(key -> buf)}
  cur: null,         // {net, key}
  es: null,
  loading: false,
  queue: [],
};
const bkey = (name) => (name || '').toLowerCase();

function makeBuf(b) {
  return { name: b.name, kind: b.kind, topic: b.topic || '', joined: !!b.joined, users: b.users || [], lines: b.lines || [], unread: 0, hl: false };
}

// ---------------------------------------------------------------------------
// Boot / auth
// ---------------------------------------------------------------------------
let authInfo = {};
let authMode = 'login'; // gate | login | signup

async function boot() {
  let st;
  try { st = await api('GET', '/api/status'); } catch (e) { setTimeout(boot, 3000); return; }
  authInfo = st;
  if (st.theme) { serverDefaultTheme = st.theme; try { localStorage.setItem('webirc.defaultTheme', st.theme); } catch (e) {} applyTheme(); }
  if (st.user) { S.user = st.user; startApp(); return; }
  showAuth(st.gate ? 'gate' : (st.setup ? 'signup' : 'login'));
}

function showAuth(mode) {
  if (S.es) { S.es.close(); S.es = null; }
  authMode = mode;
  $('app').classList.add('hidden');
  $('authScreen').classList.remove('hidden');
  const gate = mode === 'gate', signup = mode === 'signup';
  $('authTitle').textContent = gate ? 'WebIRC' : signup ? (authInfo.setup ? 'Welcome to WebIRC' : 'Create an account') : 'Log in';
  $('authHint').textContent = gate ? 'Enter the entry password to continue.'
    : signup ? (authInfo.setup ? 'Create the first account. It will be the admin account.' : 'Choose a username and password.')
    : 'Log in with your account.';
  $('authUserWrap').classList.toggle('hidden', gate);
  $('authUser').required = !gate;
  $('authPassLabel').textContent = gate ? 'Entry password' : 'Password';
  $('authPass2Wrap').classList.toggle('hidden', !signup);
  $('authPass').autocomplete = signup ? 'new-password' : (gate ? 'off' : 'current-password');
  $('authBtn').textContent = gate ? 'Enter' : signup ? 'Create account' : 'Log in';
  const sw = $('authSwitch');
  sw.parentElement.classList.toggle('hidden', gate || authInfo.setup || (!signup && !authInfo.signup));
  sw.textContent = signup ? 'I already have an account — log in' : 'No account? Create one';
  $('authErr').textContent = '';
  $('authPass').value = ''; $('authPass2').value = '';
  (gate ? $('authPass') : $('authUser')).focus();
}

$('authSwitch').onclick = () => showAuth(authMode === 'signup' ? 'login' : 'signup');

$('authForm').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const username = $('authUser').value.trim(), password = $('authPass').value;
  $('authErr').textContent = '';
  if (authMode === 'signup' && password !== $('authPass2').value) { $('authErr').textContent = 'The passwords do not match'; return; }
  $('authBtn').disabled = true;
  try {
    if (authMode === 'gate') await api('POST', '/api/gate', { password });
    else await api('POST', authMode === 'signup' ? '/api/signup' : '/api/login', { username, password });
    await boot();
  } catch (e) { $('authErr').textContent = e.message; }
  $('authBtn').disabled = false;
});

function startApp() {
  $('authScreen').classList.add('hidden');
  $('app').classList.remove('hidden');
  $('whoami').textContent = S.user.username;
  $('usersBtn').classList.toggle('hidden', !S.user.admin);
  connectEvents();
}

// ---------------------------------------------------------------------------
// Live events (Server-Sent Events)
// ---------------------------------------------------------------------------
function connectEvents() {
  if (S.es) S.es.close();
  const es = new EventSource('/api/events');
  S.es = es;
  es.onopen = () => loadState();
  es.onmessage = (ev) => {
    let e; try { e = JSON.parse(ev.data); } catch (x) { return; }
    if (S.loading) S.queue.push(e); else applyEvent(e);
  };
  es.onerror = async () => {
    if (es.readyState === EventSource.CLOSED) {
      // Could be logged out, or server restarted.
      try { const st = await api('GET', '/api/status'); if (!st.user) { boot(); return; } } catch (x) {}
      setTimeout(connectEvents, 3000);
    }
  };
}

async function loadState() {
  S.loading = true; S.queue = [];
  let st;
  try { st = await api('GET', '/api/state'); }
  catch (e) { S.loading = false; return; }
  S.customServers = st.customServers !== false;
  $('addNetBtn').classList.toggle('hidden', !S.customServers);
  $('emptyAddBtn').classList.toggle('hidden', !S.customServers);
  const prev = S.nets;
  S.nets = new Map();
  for (const n of st.networks) {
    const net = { ...n, bufs: new Map() };
    for (const b of n.buffers) {
      const nb = makeBuf(b);
      const old = prev.get(n.id) && prev.get(n.id).bufs.get(bkey(b.name));
      if (old) { nb.unread = old.unread; nb.hl = old.hl; }
      net.bufs.set(bkey(b.name), nb);
    }
    delete net.buffers;
    S.nets.set(n.id, net);
  }
  S.loading = false;
  for (const e of S.queue) applyEvent(e, true);
  S.queue = [];
  if (!S.cur || !getBuf(S.cur.net, S.cur.key)) {
    let saved = null;
    try { saved = JSON.parse(localStorage.getItem('webirc.cur') || 'null'); } catch (e) {}
    if (saved && getBuf(saved.net, saved.key)) S.cur = saved;
    else {
      const first = S.nets.values().next().value;
      S.cur = first ? { net: first.id, key: pickDefaultBuf(first) } : null;
    }
  }
  renderAll();
}

function pickDefaultBuf(net) {
  for (const [k, b] of net.bufs) if (b.kind === 'channel') return k;
  return '*';
}

function getNet(id) { return S.nets.get(id); }
function getBuf(netId, key) { const n = S.nets.get(netId); return n ? n.bufs.get(key) : null; }

function applyEvent(e, replay) {
  switch (e.type) {
    case 'line': {
      const net = getNet(e.net); if (!net) return;
      const key = bkey(e.buf);
      let b = net.bufs.get(key);
      if (!b) { b = makeBuf({ name: e.buf, kind: e.buf === '*' ? 'server' : (/^[#&+!]/.test(e.buf) ? 'channel' : 'query') }); net.bufs.set(key, b); renderSidebar(); }
      if (replay && b.lines.slice(-80).some(l => l.t === e.line.t && l.m === e.line.m && l.n === e.line.n)) return;
      b.lines.push(e.line);
      if (b.lines.length > 1000) b.lines.splice(0, b.lines.length - 1000);
      onNewLine(net, key, b, e.line);
      break;
    }
    case 'net': {
      const n = e.net;
      let net = getNet(n.id);
      if (!net) { net = { ...n, bufs: new Map() }; S.nets.set(n.id, net); }
      Object.assign(net, { name: n.name, status: n.status, nick: n.nick, error: n.error, config: n.config });
      const seen = new Set();
      for (const b of n.buffers) {
        const k = bkey(b.name); seen.add(k);
        const ex = net.bufs.get(k);
        if (ex) { ex.name = b.name; ex.topic = b.topic; ex.joined = b.joined; ex.kind = b.kind; }
        else net.bufs.set(k, makeBuf({ ...b, users: [] }));
      }
      for (const k of [...net.bufs.keys()]) if (!seen.has(k)) net.bufs.delete(k);
      delete net.buffers;
      if (!S.cur) { S.cur = { net: n.id, key: pickDefaultBuf(net) }; renderAll(); }
      else if (S.cur.net === n.id && !net.bufs.has(S.cur.key)) { S.cur.key = '*'; renderAll(); }
      else { renderSidebar(); if (S.cur.net === n.id) renderHeader(); }
      break;
    }
    case 'buf': {
      const b = getBuf(e.net, bkey(e.buf.name)); if (!b) return;
      b.topic = e.buf.topic; b.joined = e.buf.joined; b.users = e.buf.users || [];
      if (isCur(e.net, bkey(e.buf.name))) { renderHeader(); renderUsers(); }
      renderSidebar();
      break;
    }
    case 'netdel': {
      S.nets.delete(e.id);
      if (S.cur && S.cur.net === e.id) S.cur = null;
      if (!S.cur) { const f = S.nets.values().next().value; if (f) S.cur = { net: f.id, key: '*' }; }
      renderAll();
      break;
    }
  }
}

const isCur = (net, key) => S.cur && S.cur.net === net && S.cur.key === key;

function mentionsMe(net, line) {
  if (!net.nick || line.s) return false;
  const re = new RegExp('(^|[^\\w\\[\\]\\\\`^{}|-])' + net.nick.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '($|[^\\w\\[\\]\\\\`^{}|-])', 'i');
  return re.test(line.m);
}

function onNewLine(net, key, b, line) {
  const chatty = line.k === 'msg' || line.k === 'action' || line.k === 'notice';
  const hl = chatty && !line.s && (b.kind === 'query' || mentionsMe(net, line));
  const visible = isCur(net.id, key) && !document.hidden;
  if (isCur(net.id, key)) appendLine(b, line, true);
  if (!visible && chatty && !line.s) {
    b.unread++;
    if (hl) b.hl = true;
    renderSidebar();
    updateTitle();
  }
  if (hl && document.hidden && settings.notify && 'Notification' in window && Notification.permission === 'granted') {
    try {
      const n = new Notification((b.kind === 'query' ? line.n : line.n + ' in ' + b.name), { body: stripFormatting(line.m).slice(0, 200), tag: 'webirc' });
      n.onclick = () => { window.focus(); selectBuf(net.id, key); n.close(); };
    } catch (e) {}
  }
}

function updateTitle() {
  let n = 0, hl = false;
  for (const net of S.nets.values()) for (const b of net.bufs.values()) { n += b.unread; hl = hl || b.hl; }
  document.title = (n ? `(${hl ? '!' : ''}${n}) ` : '') + 'WebIRC';
}

document.addEventListener('visibilitychange', () => {
  if (!document.hidden && S.cur) { const b = getBuf(S.cur.net, S.cur.key); if (b) { b.unread = 0; b.hl = false; renderSidebar(); updateTitle(); } }
});

// ---------------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------------
function renderAll() {
  renderSidebar();
  renderHeader();
  renderMessages();
  renderUsers();
  updateTitle();
  $('emptyState').classList.toggle('hidden', S.nets.size > 0);
  $('inputForm').classList.toggle('hidden', S.nets.size === 0);
}

function renderSidebar() {
  $('emptyState').classList.toggle('hidden', S.nets.size > 0);
  $('inputForm').classList.toggle('hidden', S.nets.size === 0);
  $('emptyState').querySelector('p').textContent = S.customServers === false ? 'No IRC servers are set up yet. Ask the WebIRC admin.' : 'Add an IRC server to get started.';
  const list = $('netList');
  list.textContent = '';
  for (const net of S.nets.values()) {
    const box = el('div', 'net');
    const head = el('div', 'net-head');
    head.append(el('span', 'dot ' + net.status), el('span', 'name', net.name));
    const edit = el('button', 'icon-btn', '⚙'); edit.title = 'Edit server'; edit.style.fontSize = '13px';
    edit.onclick = () => openNetDialog(net);
    head.append(edit);
    box.append(head);
    const bufs = [...net.bufs.entries()];
    bufs.sort((a, b) => {
      const o = { server: 0, channel: 1, query: 2 };
      return (o[a[1].kind] - o[b[1].kind]) || a[0].localeCompare(b[0]);
    });
    for (const [key, b] of bufs) {
      const row = el('div', 'buf');
      if (isCur(net.id, key)) row.classList.add('active');
      if (b.unread) row.classList.add('unread');
      if (b.kind === 'channel' && !b.joined) row.classList.add('parted');
      const label = b.kind === 'server' ? '⌂ ' + statusText(net) : (b.kind === 'query' ? '@ ' + b.name : b.name);
      row.append(el('span', 'bname', label));
      if (b.unread) row.append(el('span', 'badge' + (b.hl ? ' hl' : ''), String(b.unread)));
      const forcedChan = b.kind === 'channel' && isForcedChan(net, b.name);
      if (forcedChan) { const l = el('span', 'lock', '🔒'); l.title = 'Required channel'; row.append(l); }
      if (b.kind !== 'server' && !forcedChan) {
        const x = el('button', 'x', '✕'); x.title = b.kind === 'channel' ? 'Leave channel' : 'Close';
        x.onclick = (ev) => { ev.stopPropagation(); closeBuf(net.id, b.name); };
        row.append(x);
      }
      row.onclick = () => selectBuf(net.id, key);
      box.append(row);
    }
    list.append(box);
  }
}

function isForcedChan(net, name) {
  const list = (net.config && net.config.forcedChannels) || [];
  return list.some(c => c.split(' ')[0].toLowerCase() === (name || '').toLowerCase());
}

function statusText(net) {
  return { connected: 'Server', connecting: 'Connecting…', registering: 'Logging in…', waiting: 'Reconnecting…', disconnected: 'Disconnected' }[net.status] || net.status;
}

function selectBuf(netId, key) {
  S.cur = { net: netId, key };
  try { localStorage.setItem('webirc.cur', JSON.stringify(S.cur)); } catch (e) {}
  const b = getBuf(netId, key);
  if (b) { b.unread = 0; b.hl = false; }
  $('app').classList.remove('show-side', 'show-users');
  renderAll();
  if (window.matchMedia('(min-width: 901px)').matches) $('input').focus();
}

function renderHeader() {
  const net = S.cur && getNet(S.cur.net);
  const b = S.cur && getBuf(S.cur.net, S.cur.key);
  if (!net || !b) { $('bufTitle').textContent = ''; $('bufTopic').textContent = ''; return; }
  if (b.kind === 'server') {
    $('bufTitle').textContent = net.name;
    const c = net.config || {};
    $('bufTopic').textContent = `${c.host}:${c.port} · ${c.tls ? 'encrypted 🔒' : 'not encrypted'} · ${statusText(net)}` + (net.error && net.status !== 'connected' ? ' · ' + net.error : '');
  } else {
    $('bufTitle').textContent = b.name + (b.kind === 'channel' && !b.joined ? ' (not joined)' : '');
    $('bufTopic').textContent = '';
    if (b.topic) $('bufTopic').append(...formatIRC(b.topic));
    $('bufTopic').title = stripFormatting(b.topic || '');
  }
  const connected = net.status !== 'disconnected';
  $('connectBtn').classList.toggle('hidden', connected);
  $('disconnectBtn').classList.toggle('hidden', !connected);
  $('inputNick').textContent = net.nick || '';
  const showUsers = b.kind === 'channel';
  $('app').classList.toggle('no-users', !showUsers);
  $('usersToggle').classList.toggle('hidden', !showUsers);
}

function renderUsers() {
  const b = S.cur && getBuf(S.cur.net, S.cur.key);
  const ul = $('userList'); ul.textContent = '';
  if (!b || b.kind !== 'channel') { $('userCount').textContent = ''; return; }
  $('userCount').textContent = b.users.length + (b.users.length === 1 ? ' person' : ' people');
  const frag = document.createDocumentFragment();
  for (const u of b.users) {
    const m = u.match(/^([~&@%+!]?)(.*)$/);
    const li = el('li');
    li.append(el('span', 'pfx', m[1]));
    const n = el('span', null, m[2]); n.style.color = nickColor(m[2]);
    li.append(n);
    li.title = 'Click to chat privately with ' + m[2];
    li.onclick = () => openQuery(m[2]);
    frag.append(li);
  }
  ul.append(frag);
}

let lastDay = '';
function renderMessages() {
  const box = $('messages');
  box.textContent = '';
  lastDay = '';
  const b = S.cur && getBuf(S.cur.net, S.cur.key);
  if (!b) return;
  const frag = document.createDocumentFragment();
  for (const l of b.lines) { const n = lineNode(b, l); if (n) frag.append(...n); }
  box.append(frag);
  box.scrollTop = box.scrollHeight;
}

function atBottom() { const m = $('messages'); return m.scrollHeight - m.scrollTop - m.clientHeight < 60; }
function stickBottom(was) { if (was) { const m = $('messages'); m.scrollTop = m.scrollHeight; } }

function appendLine(b, l) {
  const was = atBottom();
  const nodes = lineNode(b, l);
  if (!nodes) return;
  $('messages').append(...nodes);
  const max = 1200;
  while ($('messages').childElementCount > max) $('messages').firstElementChild.remove();
  stickBottom(was);
}

const eventKinds = new Set(['join', 'part', 'quit', 'nick', 'kick', 'mode', 'topic', 'info', 'error']);
const joinKinds = new Set(['join', 'part', 'quit']);

function lineNode(b, l) {
  if (!settings.joins && joinKinds.has(l.k) && !l.s) return null;
  const out = [];
  const d = new Date(l.t);
  const day = d.toDateString();
  if (day !== lastDay) {
    if (lastDay) out.push(el('div', 'day-sep', d.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })));
    lastDay = day;
  }
  const row = el('div', 'msg ' + l.k);
  if (eventKinds.has(l.k)) row.classList.add('event');
  const net = getNet(S.cur.net);
  if ((l.k === 'msg' || l.k === 'action' || l.k === 'notice') && net && mentionsMe(net, l) && b.kind !== 'query') row.classList.add('hl');
  row.append(el('span', 'time', d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })));
  const nick = el('span', 'nick');
  if (l.k === 'msg') nick.textContent = l.n || '';
  else if (l.k === 'action') nick.textContent = '*';
  else if (l.k === 'notice') nick.textContent = l.n ? '-' + l.n + '-' : '';
  else nick.textContent = { join: '→', part: '←', quit: '←', kick: '✕', nick: '↔', topic: '✎', mode: '⚙', error: '!', info: '•' }[l.k] || '';
  if (l.n && (l.k === 'msg' || l.k === 'notice')) { nick.style.color = nickColor(l.n); nick.onclick = () => openQuery(l.n); }
  row.append(nick);
  const text = el('span', 'text');
  if (l.k === 'action') {
    const who = el('span', 'nick'); who.textContent = l.n + ' '; who.style.color = nickColor(l.n || ''); who.onclick = () => openQuery(l.n);
    text.append(who);
  }
  text.append(...formatIRC(l.m || ''));
  row.append(text);
  if (settings.media && (l.k === 'msg' || l.k === 'action' || l.k === 'notice')) {
    const urls = findURLs(stripFormatting(l.m || ''));
    if (urls.length) {
      const embeds = el('div', 'embeds');
      for (const u of urls.slice(0, 6)) addEmbed(embeds, u);
      row.append(embeds);
    }
  }
  out.push(row);
  return out;
}

function nickColor(nick) {
  let h = 0;
  for (const c of nick.toLowerCase()) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return `hsl(${h % 360}, var(--nick-s), var(--nick-l))`;
}

// ---------------------------------------------------------------------------
// mIRC formatting codes + links
// ---------------------------------------------------------------------------
const mircColors = ['#ffffff', '#000000', '#00007f', '#009300', '#ff0000', '#7f0000', '#9c009c', '#fc7f00', '#ffff00', '#00fc00', '#009393', '#00ffff', '#0000fc', '#ff00ff', '#7f7f7f', '#d2d2d2'];

function stripFormatting(s) {
  return s.replace(/\x03(\d{1,2}(,\d{1,2})?)?/g, '').replace(/\x04([0-9a-fA-F]{6}(,[0-9a-fA-F]{6})?)?/g, '').replace(/[\x02\x0f\x11\x16\x1d\x1e\x1f]/g, '');
}

function formatIRC(s) {
  const nodes = [];
  let st = { b: 0, i: 0, u: 0, s: 0, m: 0, fg: null, bg: null, rev: 0 };
  let buf = '';
  const flush = () => {
    if (!buf) return;
    const plain = !st.b && !st.i && !st.u && !st.s && !st.m && st.fg == null && st.bg == null && !st.rev;
    const parts = linkify(buf);
    if (plain) nodes.push(...parts);
    else {
      const span = el('span');
      span.className = ['b', 'i', 'u', 's', 'm'].filter(k => st[k]).join(' ');
      let fg = st.fg, bg = st.bg;
      if (st.rev) [fg, bg] = [bg ?? 0, fg ?? 1];
      if (fg != null && mircColors[fg]) span.style.color = mircColors[fg];
      if (bg != null && mircColors[bg]) span.style.backgroundColor = mircColors[bg];
      span.append(...parts);
      nodes.push(span);
    }
    buf = '';
  };
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    switch (c) {
      case '\x02': flush(); st.b ^= 1; break;
      case '\x1d': flush(); st.i ^= 1; break;
      case '\x1f': flush(); st.u ^= 1; break;
      case '\x1e': flush(); st.s ^= 1; break;
      case '\x11': flush(); st.m ^= 1; break;
      case '\x16': flush(); st.rev ^= 1; break;
      case '\x0f': flush(); st = { b: 0, i: 0, u: 0, s: 0, m: 0, fg: null, bg: null, rev: 0 }; break;
      case '\x03': {
        flush();
        const m = s.slice(i + 1).match(/^(\d{1,2})(?:,(\d{1,2}))?/);
        if (m) { st.fg = +m[1]; if (m[2] != null) st.bg = +m[2]; i += m[0].length; }
        else { st.fg = null; st.bg = null; }
        break;
      }
      case '\x04': {
        flush();
        const m = s.slice(i + 1).match(/^[0-9a-fA-F]{6}(?:,[0-9a-fA-F]{6})?/);
        if (m) i += m[0].length;
        break;
      }
      default: buf += c;
    }
  }
  flush();
  return nodes;
}

const urlRe = /\bhttps?:\/\/[^\s<>"'\x00-\x1f]+/gi;
function trimURL(u) {
  // Drop trailing punctuation, but keep balanced parentheses (Wikipedia links).
  while (/[.,;:!?'"\]>]$/.test(u) || (u.endsWith(')') && (u.split('(').length < u.split(')').length))) u = u.slice(0, -1);
  return u;
}
function findURLs(text) {
  const out = [];
  for (const m of text.matchAll(urlRe)) { const u = trimURL(m[0]); if (!out.includes(u)) out.push(u); }
  return out;
}
function linkify(text) {
  const out = [];
  let last = 0;
  for (const m of text.matchAll(urlRe)) {
    const u = trimURL(m[0]);
    if (m.index > last) out.push(document.createTextNode(text.slice(last, m.index)));
    const a = el('a', null, u); a.href = u; a.target = '_blank'; a.rel = 'noopener noreferrer';
    out.push(a);
    last = m.index + u.length;
  }
  if (last < text.length) out.push(document.createTextNode(text.slice(last)));
  return out;
}

// ---------------------------------------------------------------------------
// Image / video embeds
// ---------------------------------------------------------------------------
const imgExt = /\.(jpe?g|png|gif|webp|avif|bmp)$/i;
const vidExt = /\.(mp4|m4v|webm|mov|ogv)$/i;
const audExt = /\.(mp3|ogg|oga|wav|m4a|flac|opus)$/i;
const probeCache = new Map();

function mediaSrc(u) { return settings.proxy ? '/media?u=' + encodeURIComponent(u) : u; }

function youtubeId(u) {
  try {
    const x = new URL(u);
    const h = x.hostname.replace(/^www\.|^m\./, '');
    if (h === 'youtu.be') return x.pathname.slice(1).split('/')[0];
    if (h === 'youtube.com' || h === 'music.youtube.com') {
      if (x.pathname === '/watch') return x.searchParams.get('v');
      const m = x.pathname.match(/^\/(shorts|embed|live)\/([\w-]{6,})/);
      if (m) return m[2];
    }
  } catch (e) {}
  return null;
}

function addEmbed(box, url) {
  let u;
  try { u = new URL(url); } catch (e) { return; }
  const yt = youtubeId(url);
  if (yt && /^[\w-]{6,20}$/.test(yt)) return box.append(ytEmbed(yt));
  let path = u.pathname;
  // imgur .gifv is really an mp4
  if (/(^|\.)imgur\.com$/.test(u.hostname) && /\.gifv$/i.test(path)) { url = url.replace(/\.gifv/i, '.mp4'); path = path.replace(/\.gifv$/i, '.mp4'); }
  if (imgExt.test(path)) return box.append(mediaEmbed('image', url));
  if (vidExt.test(path)) return box.append(mediaEmbed('video', url));
  if (audExt.test(path)) return box.append(mediaEmbed('audio', url));
  if (!settings.probe) return;
  // No file extension: ask the server what it is.
  const known = probeCache.get(url);
  const place = (kind) => { if (kind) { const was = atBottom(); box.append(mediaEmbed(kind, url)); stickBottom(was); } };
  if (known !== undefined) { if (known instanceof Promise) known.then(place); else place(known); return; }
  const p = fetch('/api/probe?u=' + encodeURIComponent(url), { credentials: 'same-origin' })
    .then(r => r.ok ? r.json() : { kind: '' }).then(j => j.kind || '').catch(() => '');
  probeCache.set(url, p);
  p.then(k => { probeCache.set(url, k); place(k); });
}

function mediaEmbed(kind, url) {
  const wrap = el('div', 'embed');
  const was = () => atBottom();
  let m;
  if (kind === 'image') {
    m = el('img'); m.loading = 'lazy'; m.alt = ''; m.referrerPolicy = 'no-referrer';
    m.onclick = () => openLightbox(url);
  } else if (kind === 'video') {
    m = el('video'); m.controls = true; m.preload = 'metadata'; m.playsInline = true;
    if (/\.gifv$|imgur/.test(url)) { m.loop = true; m.muted = true; }
  } else {
    m = el('audio'); m.controls = true; m.preload = 'none';
  }
  const before = was();
  m.addEventListener(kind === 'image' ? 'load' : 'loadedmetadata', () => stickBottom(before || atBottom()));
  m.addEventListener('error', () => wrap.classList.add('broken'));
  m.src = mediaSrc(url);
  wrap.append(m);
  const hide = el('button', 'hide', '✕'); hide.title = 'Hide'; hide.onclick = () => wrap.remove();
  wrap.append(hide);
  return wrap;
}

function ytEmbed(id) {
  const wrap = el('div', 'embed yt');
  const img = el('img'); img.alt = ''; img.referrerPolicy = 'no-referrer';
  img.src = mediaSrc(`https://i.ytimg.com/vi/${id}/hqdefault.jpg`);
  wrap.append(img, el('div', 'play', '▶'));
  wrap.title = 'Play video';
  wrap.onclick = () => {
    const f = el('iframe');
    f.src = `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?autoplay=1`;
    f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
    f.allowFullscreen = true;
    f.referrerPolicy = 'strict-origin-when-cross-origin';
    wrap.textContent = ''; wrap.append(f); wrap.onclick = null; wrap.style.cursor = 'default';
  };
  return wrap;
}

function openLightbox(url) {
  $('lightboxImg').src = mediaSrc(url);
  $('lightboxLink').href = url;
  $('lightbox').classList.remove('hidden');
}
$('lightbox').onclick = (e) => { if (e.target.id !== 'lightboxLink') $('lightbox').classList.add('hidden'); };
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') $('lightbox').classList.add('hidden'); });

// ---------------------------------------------------------------------------
// Sending
// ---------------------------------------------------------------------------
const sentHistory = [];
let histPos = -1;

const helpText = [
  'Commands:',
  '/join #channel [key] — join a channel',
  '/part [reason] — leave this channel',
  '/msg nick text — private message',
  '/query nick — open a private chat',
  '/me does something — action',
  '/nick newname — change nickname',
  '/topic new topic — set channel topic',
  '/whois nick — info about someone',
  '/notice target text, /away [msg], /invite nick, /kick nick [reason]',
  '/op /deop /voice /devoice nick, /mode …',
  '/ns … (NickServ), /cs … (ChanServ)',
  '/raw LINE — send a raw IRC command',
  '/connect, /disconnect [reason]',
  '/clear — clear this window (in this browser only)',
];

$('inputForm').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const inp = $('input');
  const text = inp.value;
  if (!text.trim() || !S.cur) return;
  sentHistory.unshift(text); if (sentHistory.length > 100) sentHistory.pop(); histPos = -1;
  inp.value = '';
  const cmd = text.trim().toLowerCase();
  const b = getBuf(S.cur.net, S.cur.key);
  if (cmd === '/help') { for (const h of helpText) appendLine(b, { t: Date.now(), k: 'info', m: h }); return; }
  if (cmd === '/clear') { b.lines = []; renderMessages(); return; }
  if (cmd === '/close') { if (b.kind !== 'server') closeBuf(S.cur.net, b.name); return; }
  try {
    const r = await api('POST', '/api/send', { net: S.cur.net, buf: b.kind === 'server' ? '*' : b.name, text });
    if (r && r.switch) waitAndSelect(S.cur.net, bkey(r.switch));
  } catch (e) { toast(e.message); inp.value = text; }
});

function waitAndSelect(netId, key, tries = 0) {
  if (getBuf(netId, key)) selectBuf(netId, key);
  else if (tries < 25) setTimeout(() => waitAndSelect(netId, key, tries + 1), 200);
}

async function openQuery(nick) {
  if (!S.cur || !nick) return;
  const netId = S.cur.net;
  const key = bkey(nick);
  if (getBuf(netId, key)) return selectBuf(netId, key);
  try { await api('POST', '/api/send', { net: netId, buf: '*', text: '/query ' + nick }); waitAndSelect(netId, key); }
  catch (e) { toast(e.message); }
}

async function closeBuf(netId, name) {
  try { await api('POST', '/api/close', { net: netId, buf: name }); } catch (e) { toast(e.message); }
}

// Tab completion of nicknames, and history with up/down.
let tabState = null;
$('input').addEventListener('keydown', (e) => {
  const inp = e.target;
  if (e.key === 'Tab') {
    e.preventDefault();
    const b = S.cur && getBuf(S.cur.net, S.cur.key);
    if (!b) return;
    if (!tabState) {
      const pos = inp.selectionStart;
      const before = inp.value.slice(0, pos);
      const m = before.match(/(\S*)$/);
      const word = m[1].toLowerCase();
      if (!word) return;
      const nicks = (b.kind === 'channel' ? b.users.map(u => u.replace(/^[~&@%+!]/, '')) : [b.name]).filter(n => n.toLowerCase().startsWith(word));
      if (!nicks.length) return;
      tabState = { start: pos - m[1].length, end: pos, nicks, i: 0, atStart: pos - m[1].length === 0 };
    } else tabState.i = (tabState.i + 1) % tabState.nicks.length;
    const n = tabState.nicks[tabState.i] + (tabState.atStart ? ': ' : ' ');
    inp.value = inp.value.slice(0, tabState.start) + n + inp.value.slice(tabState.end);
    tabState.end = tabState.start + n.length;
    inp.setSelectionRange(tabState.end, tabState.end);
    return;
  }
  tabState = null;
  if (e.key === 'ArrowUp' && sentHistory.length) { e.preventDefault(); histPos = Math.min(histPos + 1, sentHistory.length - 1); inp.value = sentHistory[histPos]; }
  if (e.key === 'ArrowDown') { e.preventDefault(); histPos = Math.max(histPos - 1, -1); inp.value = histPos >= 0 ? sentHistory[histPos] : ''; }
});

// ---------------------------------------------------------------------------
// Header buttons, mobile panels
// ---------------------------------------------------------------------------
$('connectBtn').onclick = () => S.cur && api('POST', `/api/networks/${S.cur.net}/connect`).catch(e => toast(e.message));
$('disconnectBtn').onclick = () => S.cur && api('POST', `/api/networks/${S.cur.net}/disconnect`).catch(e => toast(e.message));
$('menuBtn').onclick = () => $('app').classList.toggle('show-side');
$('usersToggle').onclick = () => {
  if (window.matchMedia('(max-width: 900px)').matches) $('app').classList.toggle('show-users');
  else $('app').classList.toggle('no-users');
};
$('scrim').onclick = () => $('app').classList.remove('show-side', 'show-users');
$('logoutBtn').onclick = async () => { try { await api('POST', '/api/logout'); } catch (e) {} S.nets = new Map(); S.cur = null; boot(); };

// Close buttons in dialogs
document.querySelectorAll('dialog [data-close]').forEach(b => b.addEventListener('click', (e) => { e.preventDefault(); b.closest('dialog').close(); }));

// ---------------------------------------------------------------------------
// Network dialog
// ---------------------------------------------------------------------------
let editingNet = null;
function openNetDialog(net) {
  editingNet = net || null;
  const f = $('netForm');
  f.reset();
  $('netErr').textContent = '';
  $('preset').value = '';
  $('preset').closest('label').classList.toggle('hidden', !!net);
  $('netDlgTitle').textContent = net ? 'Edit ' + net.name : 'Add IRC server';
  $('netDelete').classList.toggle('hidden', !net);
  const c = net ? net.config : { name: 'irc.BBSes.info', host: 'irc.bbses.info', port: 16669, tls: true, skipVerify: true, autoConnect: true, channels: ['#bbs'], nick: S.user ? S.user.username.replace(/[^A-Za-z0-9_\-\[\]\\^{}|`]/g, '_') : '' };
  for (const k of ['name', 'host', 'port', 'serverUser', 'serverPass', 'nick', 'altNick', 'username', 'realname', 'nickservPass']) f.elements[k].value = c[k] ?? '';
  for (const k of ['tls', 'skipVerify', 'autoConnect']) f.elements[k].checked = !!c[k];
  const forced = !!(net && c.forced);
  const forcedList = forced ? (c.forcedChannels || []).map(x => x.split(' ')[0].toLowerCase()) : [];
  // For admin-forced servers, only show the user's own extra channels.
  f.elements.commands.value = (c.commands || []).join('\n');
  f.elements.channels.value = (c.channels || []).filter(x => !forcedList.includes(x.split(' ')[0].toLowerCase())).join(', ');
  for (const k of ['name', 'host', 'port', 'tls', 'skipVerify', 'serverPass', 'autoConnect']) f.elements[k].disabled = forced;
  $('netForcedNote').classList.toggle('hidden', !forced);
  if (forced) $('netForcedNote').textContent = 'This server is set up by the WebIRC admin. Required channels: ' + (c.forcedChannels || []).join(', ') + '. You can change your nickname and add extra channels below.';
  $('netDelete').classList.toggle('hidden', !net || forced);
  $('netDialog').showModal();
}
$('addNetBtn').onclick = () => openNetDialog(null);
$('emptyAddBtn').onclick = () => openNetDialog(null);

$('preset').onchange = (e) => {
  if (!e.target.value) return;
  const [name, host, port, tls, selfsigned] = e.target.value.split('|');
  const f = $('netForm');
  f.elements.name.value = name; f.elements.host.value = host; f.elements.port.value = port; f.elements.tls.checked = tls === '1';
  f.elements.skipVerify.checked = selfsigned === '1';
};
$('netForm').elements.tls.onchange = (e) => {
  const p = $('netForm').elements.port;
  if (e.target.checked && p.value === '6667') p.value = '6697';
  if (!e.target.checked && p.value === '6697') p.value = '6667';
};

$('netForm').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const f = ev.target;
  const n = {
    id: editingNet ? editingNet.id : '',
    name: f.elements.name.value, host: f.elements.host.value.trim(), port: parseInt(f.elements.port.value, 10) || 0,
    tls: f.elements.tls.checked, skipVerify: f.elements.skipVerify.checked,
    serverUser: f.elements.serverUser.value.trim(), serverPass: f.elements.serverPass.value, nick: f.elements.nick.value.trim(), altNick: f.elements.altNick.value.trim(),
    username: f.elements.username.value.trim(), realname: f.elements.realname.value,
    nickservPass: f.elements.nickservPass.value,
    commands: f.elements.commands.value.split('\n').map(s => s.trim()).filter(Boolean),
    channels: f.elements.channels.value.split(',').map(s => s.trim()).filter(Boolean),
    autoConnect: f.elements.autoConnect.checked,
  };
  try {
    const r = await api('POST', '/api/networks', n);
    $('netDialog').close();
    if (!editingNet) {
      // Connect right away if they didn't choose auto-connect.
      if (!n.autoConnect) api('POST', `/api/networks/${r.id}/connect`).catch(() => {});
      waitAndSelect(r.id, '*');
    }
  } catch (e) { $('netErr').textContent = e.message; }
});

$('netDelete').onclick = async () => {
  if (!editingNet || !confirm(`Delete "${editingNet.name}"? This disconnects and removes the saved server.`)) return;
  try { await api('DELETE', '/api/networks/' + editingNet.id); $('netDialog').close(); } catch (e) { $('netErr').textContent = e.message; }
};

// ---------------------------------------------------------------------------
// Settings dialog
// ---------------------------------------------------------------------------
$('settingsBtn').onclick = () => {
  buildThemeGrid(); applyTheme();
  $('setMedia').checked = settings.media; $('setProxy').checked = settings.proxy; $('setProbe').checked = settings.probe;
  $('setJoins').checked = settings.joins; $('setNotify').checked = settings.notify; $('setMaxH').value = settings.maxh;
  $('settingsDialog').showModal();
};
$('settingsDialog').addEventListener('close', () => {
  settings.media = $('setMedia').checked; settings.proxy = $('setProxy').checked; settings.probe = $('setProbe').checked;
  settings.joins = $('setJoins').checked;
  settings.maxh = Math.max(80, Math.min(2000, parseInt($('setMaxH').value, 10) || 320));
  const wantNotify = $('setNotify').checked;
  if (wantNotify && 'Notification' in window && Notification.permission === 'default') Notification.requestPermission();
  settings.notify = wantNotify;
  document.documentElement.style.setProperty('--maxh', settings.maxh + 'px');
  saveSettings();
  renderMessages();
});

// ---------------------------------------------------------------------------
// Change own password
// ---------------------------------------------------------------------------
$('accountBtn').onclick = () => { $('accountForm').reset(); $('accountErr').textContent = ''; $('accountDialog').showModal(); };
$('accountForm').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const f = ev.target;
  if (f.elements.new.value !== f.elements.new2.value) { $('accountErr').textContent = 'The new passwords do not match'; return; }
  try {
    await api('POST', '/api/password', { old: f.elements.old.value, new: f.elements.new.value });
    $('accountDialog').close(); toast('Password changed');
    $('toast').style.background = 'var(--ok)'; setTimeout(() => $('toast').style.background = '', 4600);
  } catch (e) { $('accountErr').textContent = e.message; }
});

// ---------------------------------------------------------------------------
// User admin
// ---------------------------------------------------------------------------
async function loadUsers() {
  const tb = $('usersBody'); tb.textContent = '';
  let users;
  try { users = await api('GET', '/api/users'); } catch (e) { $('usersErr').textContent = e.message; return; }
  for (const u of users) {
    const tr = el('tr');
    tr.append(el('td', null, u.username));
    const adm = el('td'); const cb = el('input'); cb.type = 'checkbox'; cb.checked = u.admin;
    cb.disabled = u.username.toLowerCase() === S.user.username.toLowerCase();
    cb.onchange = async () => { try { await api('POST', `/api/users/${encodeURIComponent(u.username)}/admin`, { admin: cb.checked }); } catch (e) { cb.checked = !cb.checked; $('usersErr').textContent = e.message; } };
    adm.append(cb); tr.append(adm);
    tr.append(el('td', 'muted', new Date(u.created).toLocaleDateString()));
    const act = el('td');
    const pw = el('button', 'btn small', 'Set password');
    pw.onclick = async () => {
      const p = prompt('New password for ' + u.username + ' (at least 6 characters):');
      if (!p) return;
      try { await api('POST', `/api/users/${encodeURIComponent(u.username)}/password`, { password: p }); toast('Password updated'); } catch (e) { $('usersErr').textContent = e.message; }
    };
    act.append(pw);
    if (!cb.disabled) {
      const del = el('button', 'btn small danger', 'Delete');
      del.style.marginLeft = '6px';
      del.onclick = async () => {
        if (!confirm(`Delete user "${u.username}" and all their saved servers?`)) return;
        try { await api('DELETE', '/api/users/' + encodeURIComponent(u.username)); loadUsers(); } catch (e) { $('usersErr').textContent = e.message; }
      };
      act.append(del);
    }
    tr.append(act);
    tb.append(tr);
  }
}
$('usersBtn').onclick = () => { $('usersErr').textContent = ''; $('newUserForm').reset(); loadUsers(); $('usersDialog').showModal(); };
$('newUserForm').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const f = ev.target;
  try {
    await api('POST', '/api/users', { username: f.elements.username.value.trim(), password: f.elements.password.value, admin: f.elements.admin.checked });
    f.reset(); $('usersErr').textContent = ''; loadUsers();
  } catch (e) { $('usersErr').textContent = e.message; }
});

boot();
