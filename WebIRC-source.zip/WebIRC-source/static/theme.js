// Applies the saved theme before the page is drawn (avoids a flash of the wrong colors).
(function () {
  var t = 'dark';
  try {
    var s = JSON.parse(localStorage.getItem('webirc.settings') || '{}');
    t = s.theme || localStorage.getItem('webirc.defaultTheme') || 'dark';
  } catch (e) {}
  document.documentElement.setAttribute('data-theme', t);
})();
