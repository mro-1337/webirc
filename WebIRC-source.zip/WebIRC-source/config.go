package main

import (
	"crypto/rand"
	"encoding/json"
	"errors"
	"fmt"
	"math/big"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
)

// ForcedServer is an IRC server every user is connected to automatically.
type ForcedServer struct {
	Name           string   `json:"name"`
	Host           string   `json:"host"`
	Port           int      `json:"port"`
	TLS            bool     `json:"tls"`
	SkipVerify     bool     `json:"skipVerify"`
	ServerPassword string   `json:"serverPassword"`
	Channels       []string `json:"channels"`
}

// ID is stable as long as host and port stay the same.
func (f ForcedServer) ID() string {
	h := regexp.MustCompile(`[^a-z0-9]+`).ReplaceAllString(strings.ToLower(f.Host), "-")
	return "f-" + strings.Trim(h, "-") + "-" + strconv.Itoa(f.port())
}

func (f ForcedServer) port() int {
	if f.Port > 0 && f.Port <= 65535 {
		return f.Port
	}
	if f.TLS {
		return 6697
	}
	return 6667
}

// Config is read from config.txt next to the program.
type Config struct {
	Port               int            `json:"port"`
	ListenAddress      string         `json:"listenAddress"`
	HTTPS              bool           `json:"https"`
	EntryPassword      string         `json:"entryPassword"`
	AllowSignup        bool           `json:"allowSignup"`
	AllowCustomServers bool           `json:"allowCustomServers"`
	Theme              string         `json:"theme"`
	ForcedServers      []ForcedServer `json:"forcedServers"`
}

func (c *Config) Listen() string {
	return fmt.Sprintf("%s:%d", c.ListenAddress, c.Port)
}

func (c *Config) Forced(id string) (ForcedServer, bool) {
	for _, f := range c.ForcedServers {
		if f.ID() == id {
			return f, true
		}
	}
	return ForcedServer{}, false
}

func defaultConfig() *Config {
	return &Config{
		Port:               9080,
		EntryPassword:      "kaboom",
		AllowSignup:        true,
		AllowCustomServers: true,
		Theme:              "dark",
		ForcedServers: []ForcedServer{{
			Name: "irc.BBSes.info", Host: "irc.bbses.info", Port: 16669, TLS: true, SkipVerify: true, Channels: []string{"#bbs"},
		}},
	}
}

// ---------------------------------------------------------------------------
// Writing config.txt
// ---------------------------------------------------------------------------

func yesNo(b bool) string {
	if b {
		return "yes"
	}
	return "no"
}

func renderConfig(c *Config) string {
	listen := c.ListenAddress
	switch listen {
	case "", "0.0.0.0", "::":
		listen = "all"
	case "127.0.0.1", "localhost":
		listen = "local"
	}
	var b strings.Builder
	w := func(s string, a ...any) { b.WriteString(strings.TrimRight(fmt.Sprintf(s, a...), " ") + "\n") }
	w("# ================================================================")
	w("#  WebIRC settings")
	w("#  Lines starting with # are notes. Restart WebIRC after changes.")
	w("#  Yes/no settings are written as:  yes  or  no")
	w("# ================================================================")
	w("")
	w("# ------------------------- Web page -------------------------")
	w("")
	w("# Port the web page runs on.  Open http://localhost:PORT/")
	w("webport: %d", c.Port)
	w("")
	w("# Who can open the web page:")
	w("#   all   = this computer and other devices on your network")
	w("#   local = only this computer")
	w("listen: %s", listen)
	w("")
	w("# Encrypted web page (HTTPS with a self-signed certificate).")
	w("# Turn on if you open WebIRC to the internet.")
	w("https: %s", yesNo(c.HTTPS))
	w("")
	w("# Password everyone must type BEFORE they can log in or")
	w("# create an account. Leave it empty to turn it off.")
	w("entrypassword: %s", c.EntryPassword)
	w("")
	w("# Can people create their own accounts?")
	w("# (no = only admins can, in the Users screen)")
	w("signup: %s", yesNo(c.AllowSignup))
	w("")
	w("# Can users add their own extra IRC servers?")
	w("customservers: %s", yesNo(c.AllowCustomServers))
	w("")
	w("# Default look for everyone (each person can change it in Settings):")
	w("#   auto  light  dark  midnight  bbs  terminal")
	w("#   solarized-dark  solarized-light  classic  high-contrast")
	w("#   (auto = follow the computer's light/dark mode)")
	w("theme: %s", firstNonEmpty(c.Theme, "dark"))
	w("")
	w("# ------------- IRC servers everyone is connected to -------------")
	w("#")
	w("# Each server starts with a  server:  line. The lines under it")
	w("# belong to that server, until the next  server:  line.")
	w("#")
	w("#   server:      address of the IRC server")
	w("#   port:        the IRC server's port")
	w("#   name:        name shown in the server list (optional)")
	w("#   encryption:  yes = encrypted (TLS/SSL)   no = plain")
	w("#   selfsigned:  yes = accept self-signed certificates")
	w("#   password:    server password (leave empty if none)")
	w("#   channel:     a channel everyone joins and can't leave.")
	w("#                Use one  channel:  line per channel.")
	w("#")
	w("# To add another server, copy a whole block and change it.")
	w("# To remove a server, delete its block.")
	for _, f := range c.ForcedServers {
		w("")
		w("server: %s", f.Host)
		w("port: %d", f.port())
		w("name: %s", f.Name)
		w("encryption: %s", yesNo(f.TLS))
		w("selfsigned: %s", yesNo(f.SkipVerify))
		w("password: %s", f.ServerPassword)
		for _, ch := range f.Channels {
			w("channel: %s", ch)
		}
	}
	return b.String()
}

// ---------------------------------------------------------------------------
// Reading config.txt
// ---------------------------------------------------------------------------

func normKey(k string) string {
	k = strings.ToLower(k)
	return strings.NewReplacer(" ", "", "_", "", "-", "").Replace(k)
}

func parseBool(v string) (bool, error) {
	switch strings.ToLower(v) {
	case "yes", "y", "true", "on", "1":
		return true, nil
	case "no", "n", "false", "off", "0", "":
		return false, nil
	}
	return false, fmt.Errorf("should be yes or no, not %q", v)
}

func parseConfig(text, fileName string) (*Config, error) {
	c := &Config{Port: 8080, AllowSignup: true, AllowCustomServers: true}
	var cur *ForcedServer
	fail := func(n int, format string, a ...any) error {
		return fmt.Errorf("%s line %d: %s", fileName, n, fmt.Sprintf(format, a...))
	}
	text = strings.TrimPrefix(text, "\ufeff") // Notepad's byte-order mark

	for i, raw := range strings.Split(text, "\n") {
		n := i + 1
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "//") || strings.HasPrefix(line, ";") {
			continue
		}
		k, v, ok := strings.Cut(line, ":")
		if !ok {
			k, v, ok = strings.Cut(line, "=")
		}
		if !ok {
			return nil, fail(n, "expected  setting: value  but found %q", line)
		}
		key := normKey(strings.TrimSpace(k))
		val := strings.TrimSpace(v)
		if len(val) >= 2 && val[0] == '"' && val[len(val)-1] == '"' {
			val = val[1 : len(val)-1]
		}

		// Server block settings
		switch key {
		case "server", "host", "ircserver":
			if val == "" {
				return nil, fail(n, "server: needs an address, e.g.  server: irc.example.net")
			}
			c.ForcedServers = append(c.ForcedServers, ForcedServer{Host: val})
			cur = &c.ForcedServers[len(c.ForcedServers)-1]
			continue
		case "port", "name", "encryption", "tls", "ssl", "encrypted", "selfsigned", "allowselfsigned",
			"skipverify", "password", "serverpassword", "pass", "channel", "channels":
			if cur == nil {
				if key == "port" {
					return nil, fail(n, "port: belongs under a server: line. For the web page's port use  webport:")
				}
				return nil, fail(n, "%s: must come after a  server:  line", key)
			}
			switch key {
			case "port":
				p, err := strconv.Atoi(val)
				if err != nil || p < 1 || p > 65535 {
					return nil, fail(n, "port must be a number from 1 to 65535")
				}
				cur.Port = p
			case "name":
				cur.Name = val
			case "encryption", "tls", "ssl", "encrypted":
				b, err := parseBool(val)
				if err != nil {
					return nil, fail(n, "encryption %v", err)
				}
				cur.TLS = b
			case "selfsigned", "allowselfsigned", "skipverify":
				b, err := parseBool(val)
				if err != nil {
					return nil, fail(n, "selfsigned %v", err)
				}
				cur.SkipVerify = b
			case "password", "serverpassword", "pass":
				cur.ServerPassword = val
			case "channel", "channels":
				for _, ch := range strings.FieldsFunc(val, func(r rune) bool { return r == ',' || r == ' ' || r == '\t' }) {
					cur.Channels = append(cur.Channels, ch)
				}
			}
			continue
		}

		// Global settings (must come before the first server)
		if cur != nil {
			return nil, fail(n, "%q is a web page setting — move it above the first  server:  line", strings.TrimSpace(k))
		}
		switch key {
		case "webport", "httpport", "webpageport":
			p, err := strconv.Atoi(val)
			if err != nil || p < 1 || p > 65535 {
				return nil, fail(n, "webport must be a number from 1 to 65535")
			}
			c.Port = p
		case "listen", "listenaddress":
			switch strings.ToLower(val) {
			case "", "all", "any", "everyone", "network":
				c.ListenAddress = ""
			case "local", "localhost", "thiscomputer", "me":
				c.ListenAddress = "127.0.0.1"
			default:
				c.ListenAddress = val
			}
		case "https":
			b, err := parseBool(val)
			if err != nil {
				return nil, fail(n, "https %v", err)
			}
			c.HTTPS = b
		case "entrypassword", "sitepassword", "entry":
			c.EntryPassword = val
		case "signup", "allowsignup":
			b, err := parseBool(val)
			if err != nil {
				return nil, fail(n, "signup %v", err)
			}
			c.AllowSignup = b
		case "theme", "defaulttheme":
			t := strings.ToLower(val)
			if t == "" {
				t = "dark"
			}
			if !validThemes[t] {
				return nil, fail(n, "unknown theme %q — use one of: auto light dark midnight bbs terminal solarized-dark solarized-light classic high-contrast", val)
			}
			c.Theme = t
		case "customservers", "allowcustomservers":
			b, err := parseBool(val)
			if err != nil {
				return nil, fail(n, "customservers %v", err)
			}
			c.AllowCustomServers = b
		default:
			return nil, fail(n, "unknown setting %q", strings.TrimSpace(k))
		}
	}

	for i, f := range c.ForcedServers {
		if f.Name == "" {
			f.Name = f.Host
		}
		f.Port = f.port()
		f.Channels = cleanChannels(f.Channels)
		c.ForcedServers[i] = f
	}
	return c, nil
}

// loadConfig reads config.txt, creating it on first run. An older
// config.json (or settings.json) is converted automatically.
// created is true when a new file with a new random entry password was written.
func loadConfig(path, dataDir string) (cfg *Config, created bool, err error) {
	b, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		var c *Config
		oldJSON := filepath.Join(filepath.Dir(path), "config.json")
		if old, e := os.ReadFile(oldJSON); e == nil {
			c = &Config{Port: 8080, AllowSignup: true, AllowCustomServers: true}
			if e := json.Unmarshal(stripComments(old), c); e != nil {
				return nil, false, fmt.Errorf("couldn't convert the old config.json: %v", e)
			}
			os.Rename(oldJSON, oldJSON+".old")
		} else {
			c = defaultConfig()
			created = true
			carryOverSettingsJSON(c, dataDir)
		}
		text := renderConfig(c)
		if runtime.GOOS == "windows" {
			text = strings.ReplaceAll(text, "\n", "\r\n") // for old Notepad
		}
		if err := os.WriteFile(path, []byte(text), 0600); err != nil {
			return nil, false, fmt.Errorf("can't create %s: %w", path, err)
		}
		b = []byte(text)
	} else if err != nil {
		return nil, false, err
	}
	cfg, err = parseConfig(string(b), filepath.Base(path))
	if err != nil {
		return nil, false, fmt.Errorf("%v\n(Fix that line, or delete %s to get a fresh one.)", err, filepath.Base(path))
	}
	return cfg, created, nil
}

// carryOverSettingsJSON reads the port from the very first version's settings.json.
func carryOverSettingsJSON(c *Config, dataDir string) {
	old, err := os.ReadFile(filepath.Join(dataDir, "settings.json"))
	if err != nil {
		return
	}
	var s struct {
		Listen string `json:"listen"`
		HTTPS  bool   `json:"https"`
	}
	if json.Unmarshal(old, &s) != nil {
		return
	}
	if i := strings.LastIndex(s.Listen, ":"); i >= 0 {
		c.ListenAddress = s.Listen[:i]
		if p, e := strconv.Atoi(s.Listen[i+1:]); e == nil {
			c.Port = p
		}
	}
	c.HTTPS = s.HTTPS
}

func stripComments(b []byte) []byte {
	var out []string
	for _, line := range strings.Split(string(b), "\n") {
		if strings.HasPrefix(strings.TrimSpace(line), "//") {
			continue
		}
		out = append(out, line)
	}
	return []byte(strings.Join(out, "\n"))
}

func randomPassword(n int) string {
	const chars = "abcdefghjkmnpqrstuvwxyz23456789"
	b := make([]byte, n)
	for i := range b {
		x, _ := rand.Int(rand.Reader, big.NewInt(int64(len(chars))))
		b[i] = chars[x.Int64()]
	}
	return string(b)
}

var validThemes = map[string]bool{
	"auto": true, "light": true, "dark": true, "midnight": true, "bbs": true, "terminal": true,
	"solarized-dark": true, "solarized-light": true, "classic": true, "high-contrast": true,
}
