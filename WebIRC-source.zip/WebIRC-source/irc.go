package main

import (
	"bufio"
	"crypto/tls"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
	"unicode/utf8"
)

const maxLines = 1000

// ---------------------------------------------------------------------------
// Data sent to the browser
// ---------------------------------------------------------------------------

type Line struct {
	Time int64  `json:"t"`
	Kind string `json:"k"` // msg action notice join part quit kick nick topic mode info error
	Nick string `json:"n,omitempty"`
	Text string `json:"m"`
	Self bool   `json:"s,omitempty"`
}

type BufState struct {
	Name   string   `json:"name"`
	Kind   string   `json:"kind"` // server channel query
	Topic  string   `json:"topic"`
	Joined bool     `json:"joined"`
	Users  []string `json:"users"`
	Lines  []Line   `json:"lines,omitempty"`
}

type NetState struct {
	ID      string     `json:"id"`
	Name    string     `json:"name"`
	Status  string     `json:"status"` // disconnected connecting registering connected waiting
	Nick    string     `json:"nick"`
	Error   string     `json:"error"`
	Config  Network    `json:"config"`
	Buffers []BufState `json:"buffers"`
}

// ---------------------------------------------------------------------------
// Manager / Hub: one Hub per logged-in user, holding their IRC connections
// ---------------------------------------------------------------------------

type Manager struct {
	store *Store
	cfg   *Config
	mu    sync.Mutex
	hubs  map[string]*Hub
}

func NewManager(store *Store, cfg *Config) *Manager {
	return &Manager{store: store, cfg: cfg, hubs: map[string]*Hub{}}
}

var badNickChars = regexp.MustCompile(`[^A-Za-z0-9_\-\[\]\\^{}|` + "`" + `]`)

// defaultNick turns an account name into a valid IRC nickname.
func defaultNick(user string) string {
	n := badNickChars.ReplaceAllString(user, "_")
	if n == "" || (n[0] >= '0' && n[0] <= '9') || n[0] == '-' {
		n = "_" + n
	}
	return n
}

// applyForced overlays the config.txt settings onto a user's copy of a forced server.
func applyForced(f ForcedServer, n Network, user string) Network {
	n.ID = f.ID()
	n.Name, n.Host, n.Port = f.Name, f.Host, f.Port
	n.TLS, n.SkipVerify, n.ServerPass = f.TLS, f.SkipVerify, f.ServerPassword
	if strings.TrimSpace(n.Nick) == "" {
		n.Nick = defaultNick(user)
	}
	if strings.TrimSpace(n.Username) == "" {
		n.Username = n.Nick
	}
	if strings.TrimSpace(n.Realname) == "" {
		n.Realname = n.Nick
	}
	n.Channels = cleanChannels(append(append([]string(nil), f.Channels...), n.Channels...))
	n.AutoConnect = true
	n.Forced = true
	n.ForcedChannels = append([]string(nil), f.Channels...)
	return n
}

// effectiveNetworks = forced servers from config.txt + the user's own servers.
func (m *Manager) effectiveNetworks(user string) []Network {
	stored := m.store.Networks(user)
	byID := map[string]Network{}
	for _, n := range stored {
		byID[n.ID] = n
	}
	out := []Network{}
	for _, f := range m.cfg.ForcedServers {
		n, ok := byID[f.ID()]
		if !ok {
			n = Network{ID: f.ID(), Nick: defaultNick(user)}
			m.store.EnsureNetwork(user, applyForcedForStore(f, n, user))
		}
		out = append(out, applyForced(f, n, user))
	}
	for _, n := range stored {
		if strings.HasPrefix(n.ID, "f-") {
			continue // forced server that was removed from config.txt
		}
		out = append(out, n)
	}
	return out
}

// applyForcedForStore is what gets saved for a forced server: the user's own
// choices only (nick etc. and extra channels), without the forced channels.
func applyForcedForStore(f ForcedServer, n Network, user string) Network {
	full := applyForced(f, n, user)
	full.Channels = withoutChannels(full.Channels, f.Channels)
	full.Forced, full.ForcedChannels = false, nil
	return full
}

func withoutChannels(list, remove []string) []string {
	out := []string{}
	for _, c := range list {
		name := strings.Fields(c)[0]
		skip := false
		for _, r := range remove {
			if strings.EqualFold(strings.Fields(r)[0], name) {
				skip = true
			}
		}
		if !skip {
			out = append(out, c)
		}
	}
	return out
}

func (m *Manager) Hub(user string) *Hub {
	m.mu.Lock()
	defer m.mu.Unlock()
	key := strings.ToLower(user)
	h, ok := m.hubs[key]
	if !ok {
		h = &Hub{mgr: m, user: user, conns: map[string]*Conn{}, subs: map[chan []byte]struct{}{}}
		for _, n := range m.effectiveNetworks(user) {
			c := h.addConn(n)
			if n.AutoConnect {
				c.Connect()
			}
		}
		m.hubs[key] = h
	}
	return h
}

// StartAutoConnect connects every network marked "connect on startup".
func (m *Manager) StartAutoConnect() {
	for _, u := range m.store.ListUsers() {
		m.Hub(u.Username) // creating the hub connects its auto-connect servers
	}
}

func (m *Manager) RemoveUser(user string) {
	m.mu.Lock()
	h, ok := m.hubs[strings.ToLower(user)]
	delete(m.hubs, strings.ToLower(user))
	m.mu.Unlock()
	if ok {
		h.mu.Lock()
		conns := h.orderedConns()
		for ch := range h.subs {
			close(ch)
		}
		h.subs = map[chan []byte]struct{}{}
		h.mu.Unlock()
		for _, c := range conns {
			c.Disconnect("Account removed")
		}
	}
}

func (m *Manager) ShutdownAll() {
	m.mu.Lock()
	hubs := []*Hub{}
	for _, h := range m.hubs {
		hubs = append(hubs, h)
	}
	m.mu.Unlock()
	for _, h := range hubs {
		h.mu.Lock()
		conns := h.orderedConns()
		h.mu.Unlock()
		for _, c := range conns {
			c.Disconnect("Server shutting down")
		}
	}
}

type Hub struct {
	mgr   *Manager
	user  string
	mu    sync.Mutex
	conns map[string]*Conn
	order []string
	subs  map[chan []byte]struct{}
}

// addConn must be called with h.mu held (or during construction).
func (h *Hub) addConn(n Network) *Conn {
	c := &Conn{
		hub:       h,
		cfg:       n,
		status:    "disconnected",
		nick:      n.Nick,
		wake:      make(chan struct{}, 1),
		buffers:   map[string]*Buffer{},
		prefModes: "ov",
		prefSyms:  "@+",
		chanTypes: "#&",
		names:     map[string]bool{},
	}
	c.buffers["*"] = &Buffer{Name: "*", Kind: "server", Users: map[string]*Member{}}
	h.conns[n.ID] = c
	h.order = append(h.order, n.ID)
	return c
}

func (h *Hub) orderedConns() []*Conn {
	out := []*Conn{}
	for _, id := range h.order {
		if c, ok := h.conns[id]; ok {
			out = append(out, c)
		}
	}
	return out
}

func (h *Hub) Conn(id string) *Conn {
	h.mu.Lock()
	defer h.mu.Unlock()
	return h.conns[id]
}

func (h *Hub) Subscribe() chan []byte {
	ch := make(chan []byte, 2048)
	h.mu.Lock()
	h.subs[ch] = struct{}{}
	h.mu.Unlock()
	return ch
}

func (h *Hub) Unsubscribe(ch chan []byte) {
	h.mu.Lock()
	if _, ok := h.subs[ch]; ok {
		delete(h.subs, ch)
		close(ch)
	}
	h.mu.Unlock()
}

func (h *Hub) publish(v any) {
	b, err := json.Marshal(v)
	if err != nil {
		return
	}
	h.mu.Lock()
	defer h.mu.Unlock()
	for ch := range h.subs {
		select {
		case ch <- b:
		default:
			// Browser can't keep up; drop it and it will reconnect + reload.
			delete(h.subs, ch)
			close(ch)
		}
	}
}

func (h *Hub) State() []NetState {
	h.mu.Lock()
	conns := h.orderedConns()
	h.mu.Unlock()
	out := []NetState{}
	for _, c := range conns {
		out = append(out, c.State(true))
	}
	return out
}

func (h *Hub) SaveNetwork(n Network) (Network, error) {
	isNew := n.ID == ""
	forced, isForced := h.mgr.cfg.Forced(n.ID)
	if isNew && !h.mgr.cfg.AllowCustomServers {
		return n, errors.New("adding your own IRC servers is turned off on this WebIRC")
	}
	if !isForced && strings.HasPrefix(n.ID, "f-") {
		return n, errors.New("no such network")
	}
	if isForced {
		n = applyForcedForStore(forced, n, h.user)
	}
	saved, err := h.mgr.store.SaveNetwork(h.user, n)
	if err != nil {
		return saved, err
	}
	if isForced {
		saved = applyForced(forced, saved, h.user)
	}
	h.mu.Lock()
	c, exists := h.conns[saved.ID]
	if isNew || !exists {
		c = h.addConn(saved)
		h.mu.Unlock()
		h.publish(map[string]any{"type": "net", "net": c.State(false)})
		if saved.AutoConnect {
			c.Connect()
		}
		return saved, nil
	}
	h.mu.Unlock()

	c.mu.Lock()
	old := c.cfg
	c.cfg = saved
	active := c.want
	c.mu.Unlock()
	needReconnect := old.Host != saved.Host || old.Port != saved.Port || old.TLS != saved.TLS ||
		old.SkipVerify != saved.SkipVerify || old.ServerPass != saved.ServerPass || old.ServerUser != saved.ServerUser ||
		old.Username != saved.Username || old.Realname != saved.Realname
	if active && needReconnect {
		c.Disconnect("Reconnecting with new settings")
		go func() {
			time.Sleep(1500 * time.Millisecond)
			c.Connect()
		}()
	} else if active {
		// Apply a new nickname / new channels right away.
		c.mu.Lock()
		online := c.registered
		curNick := c.nick
		c.mu.Unlock()
		if online {
			if saved.Nick != old.Nick && !strings.EqualFold(saved.Nick, curNick) {
				c.writeLine("NICK " + saved.Nick)
			}
			for _, ch := range saved.Channels {
				if len(withoutChannels([]string{ch}, old.Channels)) > 0 {
					c.writeLine("JOIN " + ch)
				}
			}
		}
	}
	c.pubNet()
	return saved, nil
}

func (h *Hub) DeleteNetwork(id string) error {
	if _, forced := h.mgr.cfg.Forced(id); forced {
		return errors.New("this server is required by the WebIRC admin and can't be removed")
	}
	if err := h.mgr.store.DeleteNetwork(h.user, id); err != nil {
		return err
	}
	h.mu.Lock()
	c, ok := h.conns[id]
	delete(h.conns, id)
	for i, x := range h.order {
		if x == id {
			h.order = append(h.order[:i], h.order[i+1:]...)
			break
		}
	}
	h.mu.Unlock()
	if ok {
		c.Disconnect("Network removed")
	}
	h.publish(map[string]any{"type": "netdel", "id": id})
	return nil
}

// ---------------------------------------------------------------------------
// Conn: a single IRC connection
// ---------------------------------------------------------------------------

type Member struct {
	Nick  string
	Modes string // prefix symbols, e.g. "@+"
}

type Buffer struct {
	Name   string
	Kind   string
	Topic  string
	Joined bool
	Users  map[string]*Member
	Lines  []Line
}

type Conn struct {
	hub *Hub

	mu         sync.Mutex
	cfg        Network
	status     string
	lastErr    string
	nick       string
	want       bool
	running    bool
	registered bool
	nickTry    int
	sock       net.Conn
	wake       chan struct{}
	buffers    map[string]*Buffer
	prefModes  string
	prefSyms   string
	chanTypes  string
	names      map[string]bool // channels currently receiving a NAMES list

	wmu sync.Mutex
	w   net.Conn
}

func (c *Conn) Connect() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.want = true
	if !c.running {
		c.running = true
		go c.run()
	} else {
		select {
		case c.wake <- struct{}{}:
		default:
		}
	}
}

func (c *Conn) Disconnect(reason string) {
	c.mu.Lock()
	c.want = false
	sock := c.sock
	c.mu.Unlock()
	if sock != nil {
		if reason == "" {
			reason = "Leaving"
		}
		c.writeLine("QUIT :" + reason)
		go func() {
			time.Sleep(800 * time.Millisecond)
			sock.Close()
		}()
	}
	select {
	case c.wake <- struct{}{}:
	default:
	}
}

func (c *Conn) run() {
	delay := 10 * time.Second
	for {
		c.mu.Lock()
		if !c.want {
			c.running = false
			c.status = "disconnected"
			c.mu.Unlock()
			c.pubNet()
			return
		}
		c.mu.Unlock()

		started := time.Now()
		err := c.session()

		c.mu.Lock()
		c.sock = nil
		c.registered = false
		for _, b := range c.buffers {
			if b.Kind == "channel" {
				b.Joined = false
				b.Users = map[string]*Member{}
			}
		}
		want := c.want
		msg := "Disconnected"
		if err != nil {
			msg = "Disconnected: " + err.Error()
			c.lastErr = err.Error()
		}
		if want {
			c.status = "waiting"
			msg += fmt.Sprintf(" — reconnecting in %d seconds", int(delay.Seconds()))
		} else {
			c.status = "disconnected"
		}
		kind := "info"
		if err != nil {
			kind = "error"
		}
		for _, b := range c.buffers {
			if b.Kind != "query" {
				c.addLineLocked(b, Line{Kind: kind, Text: msg})
			}
		}
		c.mu.Unlock()
		c.pubNet()
		c.pubAllBufs()

		if !want {
			continue
		}
		if time.Since(started) > 2*time.Minute {
			delay = 10 * time.Second
		}
		select {
		case <-time.After(delay):
		case <-c.wake:
		}
		delay *= 2
		if delay > 3*time.Minute {
			delay = 3 * time.Minute
		}
	}
}

func (c *Conn) session() error {
	c.mu.Lock()
	cfg := c.cfg
	c.status = "connecting"
	c.lastErr = ""
	mode := "plain (not encrypted)"
	if cfg.TLS {
		mode = "TLS (encrypted)"
	}
	c.addLineLocked(c.buffers["*"], Line{Kind: "info", Text: fmt.Sprintf("Connecting to %s port %d using %s…", cfg.Host, cfg.Port, mode)})
	c.mu.Unlock()
	c.pubNet()

	addr := net.JoinHostPort(cfg.Host, strconv.Itoa(cfg.Port))
	d := &net.Dialer{Timeout: 20 * time.Second, KeepAlive: 60 * time.Second}
	var sock net.Conn
	var err error
	tlsInfo := ""
	if cfg.TLS {
		var tc *tls.Conn
		tc, err = tls.DialWithDialer(d, "tcp", addr, ircTLSConfig(cfg.Host, cfg.SkipVerify))
		if err != nil {
			if _, isNet := err.(*net.OpError); isNet && !strings.Contains(err.Error(), "reset") {
				return err // couldn't reach the server at all
			}
			return explainTLSError(err)
		}
		sock = tc
		st := tc.ConnectionState()
		tlsInfo = fmt.Sprintf("Encrypted with %s (%s)", tls.VersionName(st.Version), tls.CipherSuiteName(st.CipherSuite))
		if len(st.PeerCertificates) > 0 {
			cert := st.PeerCertificates[0]
			kind := "certificate from " + firstNonEmpty(cert.Issuer.CommonName, strings.Join(cert.Issuer.Organization, " "), "unknown issuer")
			if cert.Subject.String() == cert.Issuer.String() {
				kind = "self-signed certificate"
			}
			tlsInfo += fmt.Sprintf(", %s for %q", kind, firstNonEmpty(cert.Subject.CommonName, cfg.Host))
		}
	} else {
		sock, err = d.Dial("tcp", addr)
	}
	if err != nil {
		return err
	}
	defer sock.Close()

	c.mu.Lock()
	if !c.want {
		c.mu.Unlock()
		return nil
	}
	c.sock = sock
	c.status = "registering"
	c.nick = cfg.Nick
	c.nickTry = 0
	c.names = map[string]bool{}
	if tlsInfo != "" {
		c.addLineLocked(c.buffers["*"], Line{Kind: "info", Text: "🔒 " + tlsInfo})
	}
	c.addLineLocked(c.buffers["*"], Line{Kind: "info", Text: "Connected. Logging in…"})
	c.mu.Unlock()
	c.pubNet()

	c.wmu.Lock()
	c.w = sock
	c.wmu.Unlock()

	if pass := cfg.ServerPass; pass != "" || strings.TrimSpace(cfg.ServerUser) != "" {
		if u := strings.TrimSpace(cfg.ServerUser); u != "" {
			pass = u + ":" + pass // ZNC / bouncer login: user:password (user may be user/network)
		}
		c.writeLine("PASS " + trailing(pass))
	}
	c.writeLine("NICK " + cfg.Nick)
	c.writeLine("USER " + cfg.Username + " 0 * :" + cfg.Realname)

	done := make(chan struct{})
	defer close(done)
	go func() {
		t := time.NewTicker(90 * time.Second)
		defer t.Stop()
		for {
			select {
			case <-done:
				return
			case <-t.C:
				c.writeLine("PING :webirc")
			}
		}
	}()

	r := bufio.NewReaderSize(sock, 16*1024)
	gotAny := false
	for {
		sock.SetReadDeadline(time.Now().Add(5 * time.Minute))
		line, err := readIRCLine(r)
		if err == nil && !gotAny && !cfg.TLS && looksLikeTLS(line) {
			return errors.New("this port expects an ENCRYPTED connection — turn encryption on (encryption: yes)")
		}
		if err == nil {
			gotAny = true
		}
		if err != nil {
			if errors.Is(err, io.EOF) {
				if !gotAny && !cfg.TLS {
					return errors.New("server closed the connection without answering — if this port uses encryption, turn encryption on")
				}
				return errors.New("server closed the connection")
			}
			c.mu.Lock()
			quitting := !c.want
			c.mu.Unlock()
			if quitting {
				return nil
			}
			return err
		}
		if line == "" {
			continue
		}
		c.handle(parseMsg(line))
	}
}

func readIRCLine(r *bufio.Reader) (string, error) {
	var buf []byte
	for {
		part, isPrefix, err := r.ReadLine()
		if err != nil {
			return "", err
		}
		if len(buf) < 8192 {
			buf = append(buf, part...)
		}
		if !isPrefix {
			break
		}
	}
	if utf8.Valid(buf) {
		return string(buf), nil
	}
	// Not UTF-8: treat as Latin-1 (common on older networks).
	rs := make([]rune, len(buf))
	for i, b := range buf {
		rs[i] = rune(b)
	}
	return string(rs), nil
}

func (c *Conn) writeLine(s string) error {
	s = strings.NewReplacer("\r", "", "\n", "").Replace(s)
	c.wmu.Lock()
	defer c.wmu.Unlock()
	if c.w == nil {
		return errors.New("not connected")
	}
	c.w.SetWriteDeadline(time.Now().Add(30 * time.Second))
	_, err := io.WriteString(c.w, s+"\r\n")
	return err
}

func trailing(s string) string {
	if s == "" || strings.ContainsAny(s, " :") {
		return ":" + s
	}
	return s
}

// ---------------------------------------------------------------------------
// Parsing and handling server messages
// ---------------------------------------------------------------------------

type Msg struct {
	Prefix string
	Cmd    string
	Params []string
}

func (m Msg) Nick() string {
	if i := strings.IndexByte(m.Prefix, '!'); i >= 0 {
		return m.Prefix[:i]
	}
	return m.Prefix
}

func (m Msg) P(i int) string {
	if i < len(m.Params) {
		return m.Params[i]
	}
	return ""
}

func parseMsg(line string) Msg {
	var m Msg
	if strings.HasPrefix(line, "@") { // IRCv3 tags, ignored
		if i := strings.IndexByte(line, ' '); i >= 0 {
			line = strings.TrimLeft(line[i+1:], " ")
		} else {
			return m
		}
	}
	if strings.HasPrefix(line, ":") {
		if i := strings.IndexByte(line, ' '); i >= 0 {
			m.Prefix = line[1:i]
			line = strings.TrimLeft(line[i+1:], " ")
		} else {
			m.Prefix = line[1:]
			return m
		}
	}
	for line != "" {
		if strings.HasPrefix(line, ":") {
			m.Params = append(m.Params, line[1:])
			break
		}
		i := strings.IndexByte(line, ' ')
		if i < 0 {
			m.Params = append(m.Params, line)
			break
		}
		m.Params = append(m.Params, line[:i])
		line = strings.TrimLeft(line[i+1:], " ")
	}
	if len(m.Params) > 0 {
		m.Cmd = strings.ToUpper(m.Params[0])
		m.Params = m.Params[1:]
	}
	return m
}

func (c *Conn) isChannel(name string) bool {
	return name != "" && strings.ContainsRune(c.chanTypes, rune(name[0]))
}

func (c *Conn) isForcedChan(name string) bool {
	for _, f := range c.cfg.ForcedChannels {
		if strings.EqualFold(strings.Fields(f)[0], name) {
			return true
		}
	}
	return false
}

func (c *Conn) isMe(nick string) bool {
	return strings.EqualFold(nick, c.nick)
}

// getBuf finds or creates a buffer (caller holds c.mu).
func (c *Conn) getBuf(name, kind string, create bool) *Buffer {
	key := strings.ToLower(name)
	if b, ok := c.buffers[key]; ok {
		return b
	}
	if !create {
		return nil
	}
	b := &Buffer{Name: name, Kind: kind, Users: map[string]*Member{}}
	c.buffers[key] = b
	go c.pubNet()
	return b
}

func (c *Conn) addLineLocked(b *Buffer, l Line) {
	if l.Time == 0 {
		l.Time = time.Now().UnixMilli()
	}
	b.Lines = append(b.Lines, l)
	if len(b.Lines) > maxLines {
		b.Lines = append([]Line(nil), b.Lines[len(b.Lines)-maxLines:]...)
	}
	c.hub.publish(map[string]any{"type": "line", "net": c.cfg.ID, "buf": b.Name, "line": l})
}

func (c *Conn) serverLine(kind, text string) {
	c.addLineLocked(c.buffers["*"], Line{Kind: kind, Text: text})
}

func (c *Conn) handle(m Msg) {
	c.mu.Lock()
	defer c.mu.Unlock()
	from := m.Nick()

	switch m.Cmd {
	case "PING":
		c.writeLine("PONG " + trailing(m.P(len(m.Params)-1)))
	case "PONG", "CAP", "333":
	case "001":
		c.registered = true
		c.status = "connected"
		c.nick = m.P(0)
		c.serverLine("info", m.P(1))
		if c.cfg.NickServPass != "" {
			c.writeLine("PRIVMSG NickServ :IDENTIFY " + c.cfg.NickServPass)
		}
		cmds := append([]string(nil), c.cfg.Commands...)
		chans := append([]string(nil), c.cfg.Channels...)
		if len(cmds) == 0 {
			for _, ch := range chans {
				c.writeLine("JOIN " + ch)
			}
		} else {
			c.serverLine("info", fmt.Sprintf("Running your %d connect command(s)…", len(cmds)))
			go c.runConnectCommands(cmds, chans)
		}
		go c.pubNet()
	case "005":
		for _, tok := range m.Params[1:] {
			if strings.HasPrefix(tok, "PREFIX=(") {
				v := tok[len("PREFIX=("):]
				if i := strings.IndexByte(v, ')'); i > 0 && len(v[i+1:]) == i {
					c.prefModes, c.prefSyms = v[:i], v[i+1:]
				}
			} else if strings.HasPrefix(tok, "CHANTYPES=") {
				c.chanTypes = tok[len("CHANTYPES="):]
			}
		}
	case "433", "432", "437":
		if !c.registered {
			c.nickTry++
			next := ""
			switch {
			case c.nickTry == 1 && c.cfg.AltNick != "":
				next = c.cfg.AltNick
			case c.nickTry <= 3:
				next = c.cfg.Nick + strings.Repeat("_", c.nickTry)
			default:
				next = fmt.Sprintf("%s%d", c.cfg.Nick, 100+int(time.Now().UnixNano()%900))
			}
			c.serverLine("error", fmt.Sprintf("Nickname %s is not available, trying %s", m.P(1), next))
			c.nick = next
			c.writeLine("NICK " + next)
		} else {
			c.serverLine("error", strings.Join(m.Params[1:], " "))
		}
	case "JOIN":
		ch := m.P(0)
		b := c.getBuf(ch, "channel", c.isMe(from))
		if b == nil {
			return
		}
		if c.isMe(from) {
			b.Name = ch
			b.Joined = true
			b.Users = map[string]*Member{}
			c.addLineLocked(b, Line{Kind: "join", Nick: from, Text: "You joined " + ch, Self: true})
			c.rememberChannel(ch, true)
			go c.pubNet()
		} else {
			b.Users[strings.ToLower(from)] = &Member{Nick: from}
			c.addLineLocked(b, Line{Kind: "join", Nick: from, Text: from + " joined"})
		}
		c.pubBufLocked(b)
	case "PART":
		ch := m.P(0)
		b := c.getBuf(ch, "channel", false)
		if b == nil {
			return
		}
		reason := ""
		if m.P(1) != "" {
			reason = " (" + m.P(1) + ")"
		}
		if c.isMe(from) {
			b.Joined = false
			b.Users = map[string]*Member{}
			c.addLineLocked(b, Line{Kind: "part", Nick: from, Text: "You left " + ch + reason, Self: true})
			c.rememberChannel(ch, false)
		} else {
			delete(b.Users, strings.ToLower(from))
			c.addLineLocked(b, Line{Kind: "part", Nick: from, Text: from + " left" + reason})
		}
		c.pubBufLocked(b)
	case "KICK":
		ch, victim := m.P(0), m.P(1)
		b := c.getBuf(ch, "channel", false)
		if b == nil {
			return
		}
		if c.isMe(victim) {
			b.Joined = false
			b.Users = map[string]*Member{}
			if c.isForcedChan(ch) {
				go func() { time.Sleep(5 * time.Second); c.writeLine("JOIN " + ch) }()
			}
			c.addLineLocked(b, Line{Kind: "kick", Nick: from, Text: fmt.Sprintf("You were kicked by %s (%s)", from, m.P(2))})
		} else {
			delete(b.Users, strings.ToLower(victim))
			c.addLineLocked(b, Line{Kind: "kick", Nick: from, Text: fmt.Sprintf("%s was kicked by %s (%s)", victim, from, m.P(2))})
		}
		c.pubBufLocked(b)
	case "QUIT":
		key := strings.ToLower(from)
		for _, b := range c.buffers {
			if _, ok := b.Users[key]; ok && b.Kind == "channel" {
				delete(b.Users, key)
				c.addLineLocked(b, Line{Kind: "quit", Nick: from, Text: from + " quit (" + m.P(0) + ")"})
				c.pubBufLocked(b)
			} else if b.Kind == "query" && strings.EqualFold(b.Name, from) {
				c.addLineLocked(b, Line{Kind: "quit", Nick: from, Text: from + " quit (" + m.P(0) + ")"})
			}
		}
	case "NICK":
		newNick := m.P(0)
		oldKey := strings.ToLower(from)
		if c.isMe(from) {
			c.nick = newNick
			c.serverLine("nick", "You are now known as "+newNick)
			go c.pubNet()
		}
		for _, b := range c.buffers {
			if mem, ok := b.Users[oldKey]; ok && b.Kind == "channel" {
				delete(b.Users, oldKey)
				mem.Nick = newNick
				b.Users[strings.ToLower(newNick)] = mem
				c.addLineLocked(b, Line{Kind: "nick", Nick: from, Text: from + " is now known as " + newNick})
				c.pubBufLocked(b)
			}
		}
		if qb, ok := c.buffers[oldKey]; ok && qb.Kind == "query" {
			if _, taken := c.buffers[strings.ToLower(newNick)]; !taken {
				delete(c.buffers, oldKey)
				qb.Name = newNick
				c.buffers[strings.ToLower(newNick)] = qb
				c.addLineLocked(qb, Line{Kind: "nick", Nick: from, Text: from + " is now known as " + newNick})
				go c.pubNet()
			}
		}
	case "PRIVMSG", "NOTICE":
		c.handleMessage(m, from)
	case "TOPIC":
		b := c.getBuf(m.P(0), "channel", false)
		if b != nil {
			b.Topic = m.P(1)
			c.addLineLocked(b, Line{Kind: "topic", Nick: from, Text: from + " changed the topic to: " + m.P(1)})
			c.pubBufLocked(b)
		}
	case "332":
		b := c.getBuf(m.P(1), "channel", false)
		if b != nil {
			b.Topic = m.P(2)
			c.addLineLocked(b, Line{Kind: "topic", Text: "Topic: " + m.P(2)})
			c.pubBufLocked(b)
		}
	case "331":
	case "353":
		ch := m.P(2)
		b := c.getBuf(ch, "channel", false)
		if b == nil {
			c.serverLine("info", "Users in "+ch+": "+m.P(3))
			return
		}
		key := strings.ToLower(ch)
		if !c.names[key] {
			c.names[key] = true
			b.Users = map[string]*Member{}
		}
		for _, n := range strings.Fields(m.P(3)) {
			modes := ""
			for n != "" && strings.IndexByte(c.prefSyms, n[0]) >= 0 {
				modes += n[:1]
				n = n[1:]
			}
			if i := strings.IndexByte(n, '!'); i >= 0 {
				n = n[:i]
			}
			if n != "" {
				b.Users[strings.ToLower(n)] = &Member{Nick: n, Modes: modes}
			}
		}
	case "366":
		key := strings.ToLower(m.P(1))
		delete(c.names, key)
		if b := c.getBuf(m.P(1), "channel", false); b != nil {
			c.pubBufLocked(b)
		}
	case "MODE":
		target := m.P(0)
		text := strings.Join(m.Params[1:], " ")
		if c.isChannel(target) {
			b := c.getBuf(target, "channel", false)
			if b != nil {
				c.addLineLocked(b, Line{Kind: "mode", Nick: from, Text: from + " sets mode " + text})
				if strings.ContainsAny(m.P(1), c.prefModes) {
					c.writeLine("NAMES " + target)
				}
			}
		} else {
			c.serverLine("mode", "Mode for "+target+": "+text)
		}
	case "INVITE":
		c.serverLine("info", fmt.Sprintf("%s invited you to %s (type /join %s)", from, m.P(1), m.P(1)))
	case "ERROR":
		c.serverLine("error", "Server error: "+m.P(0))
	default:
		if len(m.Cmd) == 3 && m.Cmd[0] >= '0' && m.Cmd[0] <= '9' {
			c.handleNumeric(m)
		} else {
			c.serverLine("info", m.Cmd+" "+strings.Join(m.Params, " "))
		}
	}
}

func (c *Conn) handleNumeric(m Msg) {
	switch m.Cmd {
	case "004", "005", "375", "376": // noisy, nothing useful to show
		return
	}
	kind := "info"
	if m.Cmd[0] == '4' || m.Cmd[0] == '5' {
		kind = "error"
	}
	params := m.Params
	if len(params) > 0 {
		params = params[1:] // drop our own nick
	}
	// Channel-related errors go into that channel's window if it's open.
	if len(params) > 1 && c.isChannel(params[0]) {
		if b := c.getBuf(params[0], "channel", false); b != nil {
			c.addLineLocked(b, Line{Kind: kind, Text: strings.Join(params[1:], " ")})
			return
		}
	}
	c.serverLine(kind, strings.Join(params, " "))
}

func (c *Conn) handleMessage(m Msg, from string) {
	target, text := m.P(0), m.P(1)
	kind := "msg"
	if m.Cmd == "NOTICE" {
		kind = "notice"
	}
	// CTCP
	if strings.HasPrefix(text, "\x01") {
		inner := strings.Trim(text, "\x01")
		cmd, rest, _ := strings.Cut(inner, " ")
		cmd = strings.ToUpper(cmd)
		if cmd == "ACTION" {
			kind, text = "action", rest
		} else {
			if m.Cmd == "PRIVMSG" {
				switch cmd {
				case "VERSION":
					c.writeLine("NOTICE " + from + " :\x01VERSION WebIRC (Go)\x01")
				case "PING":
					c.writeLine("NOTICE " + from + " :\x01PING " + rest + "\x01")
				case "TIME":
					c.writeLine("NOTICE " + from + " :\x01TIME " + time.Now().Format(time.RFC1123) + "\x01")
				}
				c.serverLine("info", fmt.Sprintf("CTCP %s request from %s", cmd, from))
			} else {
				c.serverLine("info", fmt.Sprintf("CTCP %s reply from %s: %s", cmd, from, rest))
			}
			return
		}
	}
	// "@#channel" style targets (STATUSMSG)
	t := target
	for len(t) > 1 && strings.IndexByte(c.prefSyms, t[0]) >= 0 && c.isChannel(t[1:]) {
		t = t[1:]
	}
	var b *Buffer
	switch {
	case c.isChannel(t):
		b = c.getBuf(t, "channel", true)
	case !strings.Contains(m.Prefix, "!") || from == "" || !c.registered:
		b = c.buffers["*"] // server notices
	case kind == "notice":
		b = c.getBuf(from, "query", false)
		if b == nil {
			b = c.buffers["*"]
		}
	default:
		b = c.getBuf(from, "query", true)
		if b.Kind == "query" {
			b.Name = from
		}
	}
	c.addLineLocked(b, Line{Kind: kind, Nick: from, Text: text, Self: c.isMe(from)})
}

// rememberChannel keeps the saved auto-join list in sync. Caller holds c.mu.
func (c *Conn) rememberChannel(ch string, add bool) {
	list := []string{}
	found := false
	for _, x := range c.cfg.Channels {
		name := strings.Fields(x)[0]
		if strings.EqualFold(name, ch) {
			found = true
			if !add {
				continue
			}
		}
		list = append(list, x)
	}
	if add && !found {
		list = append(list, ch)
	}
	if add && found {
		return
	}
	if !add && !found {
		return
	}
	if !add && c.isForcedChan(ch) {
		return
	}
	c.cfg.Channels = list
	user, id := c.hub.user, c.cfg.ID
	go c.hub.mgr.store.SetChannels(user, id, withoutChannels(list, c.cfg.ForcedChannels))
}

// ---------------------------------------------------------------------------
// State snapshots / publishing
// ---------------------------------------------------------------------------

func (c *Conn) bufStateLocked(b *Buffer, withLines bool) BufState {
	bs := BufState{Name: b.Name, Kind: b.Kind, Topic: b.Topic, Joined: b.Joined, Users: []string{}}
	if b.Kind == "server" {
		bs.Name = "*"
	}
	ms := make([]*Member, 0, len(b.Users))
	for _, m := range b.Users {
		ms = append(ms, m)
	}
	rank := func(m *Member) int {
		best := len(c.prefSyms)
		for _, r := range m.Modes {
			if i := strings.IndexRune(c.prefSyms, r); i >= 0 && i < best {
				best = i
			}
		}
		return best
	}
	sort.Slice(ms, func(i, j int) bool {
		ri, rj := rank(ms[i]), rank(ms[j])
		if ri != rj {
			return ri < rj
		}
		return strings.ToLower(ms[i].Nick) < strings.ToLower(ms[j].Nick)
	})
	for _, m := range ms {
		p := ""
		if r := rank(m); r < len(c.prefSyms) {
			p = c.prefSyms[r : r+1]
		}
		bs.Users = append(bs.Users, p+m.Nick)
	}
	if withLines {
		bs.Lines = append([]Line(nil), b.Lines...)
	}
	return bs
}

func (c *Conn) State(withLines bool) NetState {
	c.mu.Lock()
	defer c.mu.Unlock()
	ns := NetState{ID: c.cfg.ID, Name: c.cfg.Name, Status: c.status, Nick: c.nick, Error: c.lastErr, Config: c.cfg}
	ns.Config.ServerPass = maskSecret(ns.Config.ServerPass)
	ns.Config.NickServPass = maskSecret(ns.Config.NickServPass)
	ns.Buffers = append(ns.Buffers, c.bufStateLocked(c.buffers["*"], withLines))
	keys := []string{}
	for k, b := range c.buffers {
		if b.Kind != "server" {
			keys = append(keys, k)
		}
	}
	sort.Slice(keys, func(i, j int) bool {
		bi, bj := c.buffers[keys[i]], c.buffers[keys[j]]
		if bi.Kind != bj.Kind {
			return bi.Kind == "channel"
		}
		return keys[i] < keys[j]
	})
	for _, k := range keys {
		ns.Buffers = append(ns.Buffers, c.bufStateLocked(c.buffers[k], withLines))
	}
	return ns
}

const secretMask = "••••••••"

func maskSecret(s string) string {
	if s == "" {
		return ""
	}
	return secretMask
}

func (c *Conn) pubNet() {
	st := c.State(false)
	for i := range st.Buffers {
		st.Buffers[i].Users = nil
	}
	c.hub.publish(map[string]any{"type": "net", "net": st})
}

func (c *Conn) pubBufLocked(b *Buffer) {
	if c.names[strings.ToLower(b.Name)] {
		return // wait until the NAMES list is complete
	}
	c.hub.publish(map[string]any{"type": "buf", "net": c.cfg.ID, "buf": c.bufStateLocked(b, false)})
}

func (c *Conn) pubAllBufs() {
	c.mu.Lock()
	defer c.mu.Unlock()
	for _, b := range c.buffers {
		if b.Kind == "channel" {
			c.pubBufLocked(b)
		}
	}
}

// ---------------------------------------------------------------------------
// Input from the browser (/commands and messages)
// ---------------------------------------------------------------------------

// Input handles a line typed by the user into buffer `target`.
// It returns the name of a buffer the browser should switch to (if any).
func (c *Conn) Input(target, text string) (string, error) {
	text = strings.TrimRight(text, "\r\n")
	if text == "" {
		return "", nil
	}
	if strings.HasPrefix(text, "/") && !strings.HasPrefix(text, "//") {
		return c.command(target, text[1:])
	}
	if strings.HasPrefix(text, "//") {
		text = text[1:]
	}
	if target == "*" || target == "" {
		return "", errors.New("this is the server window — use /join #channel or /msg nick text")
	}
	for _, l := range strings.Split(text, "\n") {
		if err := c.say(target, "msg", l); err != nil {
			return "", err
		}
	}
	return "", nil
}

func (c *Conn) requireConn() error {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.sock == nil || !c.registered {
		return errors.New("not connected — click Connect first")
	}
	return nil
}

func (c *Conn) say(target, kind, text string) error {
	if strings.TrimSpace(text) == "" {
		return nil
	}
	if err := c.requireConn(); err != nil {
		return err
	}
	verb := "PRIVMSG"
	if kind == "notice" {
		verb = "NOTICE"
	}
	limit := 400 - len(target)
	if kind == "action" {
		limit -= 9
	}
	for _, chunk := range splitText(text, limit) {
		payload := chunk
		if kind == "action" {
			payload = "\x01ACTION " + chunk + "\x01"
		}
		if err := c.writeLine(verb + " " + target + " :" + payload); err != nil {
			return err
		}
		c.mu.Lock()
		bt := "query"
		if c.isChannel(target) {
			bt = "channel"
		}
		var b *Buffer
		if kind == "notice" {
			b = c.getBuf(target, bt, false)
			if b == nil {
				b = c.buffers["*"]
			}
			chunk = "→ " + target + ": " + chunk
		} else {
			b = c.getBuf(target, bt, true)
		}
		c.addLineLocked(b, Line{Kind: kind, Nick: c.nick, Text: chunk, Self: true})
		c.mu.Unlock()
	}
	return nil
}

func splitText(s string, limit int) []string {
	if limit < 50 {
		limit = 50
	}
	var out []string
	for len(s) > limit {
		cut := limit
		for cut > 0 && !utf8.RuneStart(s[cut]) {
			cut--
		}
		if sp := strings.LastIndexByte(s[:cut], ' '); sp > limit/2 {
			cut = sp
		}
		out = append(out, s[:cut])
		s = strings.TrimLeft(s[cut:], " ")
	}
	if s != "" {
		out = append(out, s)
	}
	return out
}

func (c *Conn) command(target, line string) (string, error) {
	cmd, rest, _ := strings.Cut(line, " ")
	cmd = strings.ToLower(cmd)
	rest = strings.TrimSpace(rest)
	arg1, arg2, _ := strings.Cut(rest, " ")
	arg2 = strings.TrimSpace(arg2)

	switch cmd {
	case "connect", "server", "reconnect":
		c.Connect()
		return "", nil
	case "disconnect", "quit":
		c.Disconnect(rest)
		return "", nil
	}
	if err := c.requireConn(); err != nil {
		return "", err
	}
	isChan := func(s string) bool {
		c.mu.Lock()
		defer c.mu.Unlock()
		return c.isChannel(s)
	}

	switch cmd {
	case "join", "j":
		if arg1 == "" {
			return "", errors.New("usage: /join #channel [key]")
		}
		if !isChan(arg1) {
			arg1 = "#" + arg1
		}
		if arg2 != "" {
			return arg1, c.writeLine("JOIN " + arg1 + " " + arg2)
		}
		return arg1, c.writeLine("JOIN " + arg1)
	case "part", "leave":
		ch, reason := target, rest
		if isChan(arg1) {
			ch, reason = arg1, arg2
		}
		if !isChan(ch) {
			return "", errors.New("usage: /part #channel [reason]")
		}
		c.mu.Lock()
		forced := c.isForcedChan(ch)
		c.mu.Unlock()
		if forced {
			return "", errors.New(ch + " is a required channel and can't be left")
		}
		if reason != "" {
			return "", c.writeLine("PART " + ch + " :" + reason)
		}
		return "", c.writeLine("PART " + ch)
	case "msg", "privmsg", "m":
		if arg1 == "" || arg2 == "" {
			return "", errors.New("usage: /msg nick message")
		}
		return arg1, c.say(arg1, "msg", arg2)
	case "query", "q":
		if arg1 == "" {
			return "", errors.New("usage: /query nick [message]")
		}
		c.mu.Lock()
		c.getBuf(arg1, "query", true)
		c.mu.Unlock()
		if arg2 != "" {
			c.say(arg1, "msg", arg2)
		}
		return arg1, nil
	case "me", "action":
		if target == "*" {
			return "", errors.New("/me only works in a channel or private chat")
		}
		return "", c.say(target, "action", rest)
	case "notice":
		if arg1 == "" || arg2 == "" {
			return "", errors.New("usage: /notice target message")
		}
		return "", c.say(arg1, "notice", arg2)
	case "nick":
		if arg1 == "" {
			return "", errors.New("usage: /nick newnick")
		}
		return "", c.writeLine("NICK " + arg1)
	case "topic", "t":
		ch := target
		if isChan(arg1) {
			ch, rest = arg1, arg2
		}
		if rest == "" {
			return "", c.writeLine("TOPIC " + ch)
		}
		return "", c.writeLine("TOPIC " + ch + " :" + rest)
	case "kick", "k":
		if arg1 == "" || !isChan(target) {
			return "", errors.New("usage (in a channel): /kick nick [reason]")
		}
		return "", c.writeLine("KICK " + target + " " + arg1 + " :" + arg2)
	case "op", "deop", "voice", "devoice":
		if arg1 == "" || !isChan(target) {
			return "", errors.New("usage (in a channel): /" + cmd + " nick")
		}
		m := map[string]string{"op": "+o", "deop": "-o", "voice": "+v", "devoice": "-v"}[cmd]
		return "", c.writeLine("MODE " + target + " " + m + " " + arg1)
	case "mode":
		return "", c.writeLine("MODE " + rest)
	case "whois", "w":
		return "", c.writeLine("WHOIS " + arg1)
	case "away":
		if rest == "" {
			return "", c.writeLine("AWAY")
		}
		return "", c.writeLine("AWAY :" + rest)
	case "invite":
		ch := target
		if isChan(arg2) {
			ch = arg2
		}
		return "", c.writeLine("INVITE " + arg1 + " " + ch)
	case "names":
		ch := target
		if arg1 != "" {
			ch = arg1
		}
		return "", c.writeLine("NAMES " + ch)
	case "ns", "nickserv":
		return "", c.writeLine("PRIVMSG NickServ :" + rest)
	case "cs", "chanserv":
		return "", c.writeLine("PRIVMSG ChanServ :" + rest)
	case "raw", "quote":
		if rest == "" {
			return "", errors.New("usage: /raw COMMAND params")
		}
		c.mu.Lock()
		c.serverLine("info", "→ "+rest)
		c.mu.Unlock()
		return "", c.writeLine(rest)
	default:
		// Unknown commands are sent to the server as-is (e.g. /list, /motd).
		return "", c.writeLine(strings.ToUpper(cmd) + " " + rest)
	}
}

// CloseBuffer removes a channel or private chat window.
func (c *Conn) CloseBuffer(name string) error {
	c.mu.Lock()
	key := strings.ToLower(name)
	b, ok := c.buffers[key]
	if !ok || b.Kind == "server" {
		c.mu.Unlock()
		return nil
	}
	if b.Kind == "channel" && c.isForcedChan(b.Name) {
		c.mu.Unlock()
		return errors.New(b.Name + " is a required channel and can't be closed")
	}
	joined := b.Joined && b.Kind == "channel" && c.sock != nil
	if b.Kind == "channel" {
		c.rememberChannel(b.Name, false)
	}
	delete(c.buffers, key)
	c.mu.Unlock()
	if joined {
		c.writeLine("PART " + b.Name)
	}
	c.pubNet()
	return nil
}

func firstNonEmpty(vals ...string) string {
	for _, v := range vals {
		if strings.TrimSpace(v) != "" {
			return v
		}
	}
	return ""
}

// runConnectCommands sends the user's saved commands, then joins channels
// (after a short pause so things like NickServ logins finish first).
// Lines starting with / work like typed commands (/msg, /mode, /join ...);
// other lines are sent to the server as-is. $me / $nick = your nickname.
func (c *Conn) runConnectCommands(cmds, chans []string) {
	for i, line := range cmds {
		c.mu.Lock()
		online, nick := c.registered && c.sock != nil, c.nick
		c.mu.Unlock()
		if !online {
			return
		}
		line = strings.NewReplacer("$me", nick, "$nick", nick).Replace(line)
		var err error
		lower := strings.ToLower(line)
		switch {
		case strings.HasPrefix(lower, "/wait ") || strings.HasPrefix(lower, "/sleep "):
			secs, _ := strconv.ParseFloat(strings.TrimSpace(strings.Fields(line)[1]), 64)
			if secs > 0 && secs <= 30 {
				time.Sleep(time.Duration(secs * float64(time.Second)))
			}
			continue
		case strings.HasPrefix(line, "/"):
			// /msg and /notice are sent quietly, so passwords don't show up in a window.
			f := strings.SplitN(line[1:], " ", 3)
			verb := strings.ToLower(f[0])
			if (verb == "msg" || verb == "m" || verb == "privmsg" || verb == "notice") && len(f) == 3 {
				irc := "PRIVMSG"
				if verb == "notice" {
					irc = "NOTICE"
				}
				err = c.writeLine(irc + " " + f[1] + " :" + f[2])
			} else {
				_, err = c.command("*", line[1:])
			}
		default:
			err = c.writeLine(line)
		}
		if err != nil {
			c.mu.Lock()
			c.serverLine("error", fmt.Sprintf("Connect command #%d failed: %v", i+1, err))
			c.mu.Unlock()
		}
		time.Sleep(400 * time.Millisecond) // don't flood the server
	}
	time.Sleep(1200 * time.Millisecond)
	for _, ch := range chans {
		c.writeLine("JOIN " + ch)
	}
}
