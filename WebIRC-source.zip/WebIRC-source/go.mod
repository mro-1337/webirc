module webirc

go 1.24.7
