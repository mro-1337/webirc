// WebIRC — a password-protected web IRC client server for Windows.
//
// Double-click the .exe, then open the address it prints in your browser.
// All settings and accounts are saved next to the .exe.
package main

import (
	"bufio"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"embed"
	"encoding/pem"
	"flag"
	"fmt"
	"io/fs"
	"log"
	"math/big"
	"net"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

//go:embed static
var staticFiles embed.FS

func main() {
	dataFlag := flag.String("data", "", "folder for saved data (default: webirc-data next to the program)")
	configFlag := flag.String("config", "", "path to config.txt (default: next to the program)")
	portFlag := flag.Int("port", 0, "web page port (overrides webport in config.txt)")
	httpsFlag := flag.Bool("https", false, "use HTTPS with a self-signed certificate")
	noBrowser := flag.Bool("nobrowser", false, "don't open the web browser on start")
	testFlag := flag.String("test", "", "test an IRC server and exit, e.g. -test irc.bbses.info:16669")
	flag.Parse()

	if *testFlag != "" {
		runDiagnostics(*testFlag)
		if runtime.GOOS == "windows" {
			fmt.Println("Press Enter to close.")
			bufio.NewReader(os.Stdin).ReadString('\n')
		}
		return
	}

	baseDir := programDir()
	dataDir := *dataFlag
	if dataDir == "" {
		dataDir = filepath.Join(baseDir, "webirc-data")
	}
	if err := os.MkdirAll(dataDir, 0700); err != nil {
		fatal("Can't create data folder %s: %v", dataDir, err)
	}
	configPath := *configFlag
	if configPath == "" {
		configPath = filepath.Join(baseDir, "config.txt")
	}

	cfg, created, err := loadConfig(configPath, dataDir)
	if err != nil {
		fatal("%v", err)
	}
	if *portFlag != 0 {
		cfg.Port = *portFlag
	}
	if *httpsFlag {
		cfg.HTTPS = true
	}

	store, err := OpenStore(filepath.Join(dataDir, "webirc-data.json"))
	if err != nil {
		fatal("Can't read saved data: %v", err)
	}
	secret, err := loadSecret(dataDir)
	if err != nil {
		fatal("Can't create secret key: %v", err)
	}

	static, _ := fs.Sub(staticFiles, "static")
	mgr := NewManager(store, cfg)
	srv := &Server{store: store, sess: NewSessions(), mgr: mgr, static: static, cfg: cfg, secret: secret}

	ln, err := net.Listen("tcp", cfg.Listen())
	if err != nil {
		fatal("Can't use port %d: %v\n(Is WebIRC already running? Change  webport:  in %s.)", cfg.Port, err, configPath)
	}

	httpServer := &http.Server{
		Handler:           srv.Routes(),
		ReadHeaderTimeout: 15 * time.Second,
		IdleTimeout:       120 * time.Second,
		ErrorLog:          log.New(discard{}, "", 0),
	}

	scheme := "http"
	if cfg.HTTPS {
		scheme = "https"
		cert, err := loadOrCreateCert(dataDir)
		if err != nil {
			fatal("HTTPS certificate problem: %v", err)
		}
		httpServer.TLSConfig = &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS12}
		ln = tls.NewListener(ln, httpServer.TLSConfig)
	}

	port := ln.Addr().(*net.TCPAddr).Port
	localURL := fmt.Sprintf("%s://localhost:%d/", scheme, port)

	fmt.Println("==============================================")
	fmt.Println("  WebIRC is running")
	fmt.Println("==============================================")
	fmt.Println("  Open in your browser:  " + localURL)
	if host := cfg.ListenAddress; host == "" || host == "0.0.0.0" || host == "::" {
		for _, ip := range lanIPs() {
			fmt.Printf("  From other devices:    %s://%s:%d/\n", scheme, ip, port)
		}
	}
	fmt.Println("  Config file:           " + configPath)
	fmt.Println("  Data folder:           " + dataDir)
	fmt.Println()
	if cfg.EntryPassword == "" {
		fmt.Println("  Entry password:        (off)")
	} else if created {
		fmt.Println("  Entry password:        " + cfg.EntryPassword + "   <- new! change it in config.txt")
	} else {
		fmt.Println("  Entry password:        set in config.txt")
	}
	fmt.Printf("  Self sign-up:          %v\n", onOff(cfg.AllowSignup))
	for _, f := range cfg.ForcedServers {
		fmt.Printf("  Forced server:         %s (%s:%d) %s\n", f.Name, f.Host, f.Port, strings.Join(f.Channels, " "))
	}
	if store.UserCount() == 0 {
		fmt.Println()
		fmt.Println("  First run: open the page and create your admin account.")
	}
	fmt.Println()
	fmt.Println("  Close this window (or press Ctrl+C) to stop the server.")
	fmt.Println("==============================================")

	mgr.StartAutoConnect()

	go func() {
		sig := make(chan os.Signal, 1)
		signal.Notify(sig, os.Interrupt)
		<-sig
		fmt.Println("Shutting down…")
		mgr.ShutdownAll()
		time.Sleep(1200 * time.Millisecond)
		os.Exit(0)
	}()

	if !*noBrowser {
		go func() {
			time.Sleep(600 * time.Millisecond)
			openBrowser(localURL)
		}()
	}

	if err := httpServer.Serve(ln); err != nil {
		fatal("Server stopped: %v", err)
	}
}

type discard struct{}

func (discard) Write(p []byte) (int, error) { return len(p), nil }

func onOff(b bool) string {
	if b {
		return "on"
	}
	return "off"
}

// programDir is the folder the .exe is in (or the current folder for "go run").
func programDir() string {
	exe, err := os.Executable()
	if err == nil {
		dir := filepath.Dir(exe)
		if !strings.HasPrefix(dir, os.TempDir()) {
			return dir
		}
	}
	wd, _ := os.Getwd()
	return wd
}

func loadSecret(dir string) ([]byte, error) {
	path := filepath.Join(dir, "secret.key")
	if b, err := os.ReadFile(path); err == nil && len(b) >= 32 {
		return b, nil
	}
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return nil, err
	}
	return b, os.WriteFile(path, b, 0600)
}

func fatal(format string, args ...any) {
	fmt.Printf("\nERROR: "+format+"\n", args...)
	if runtime.GOOS == "windows" {
		// Keep the console window open so the message can be read.
		fmt.Println("\nPress Enter to close.")
		bufio.NewReader(os.Stdin).ReadString('\n')
	}
	os.Exit(1)
}

func openBrowser(url string) {
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		cmd = exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
	case "darwin":
		cmd = exec.Command("open", url)
	default:
		cmd = exec.Command("xdg-open", url)
	}
	cmd.Start()
}

func lanIPs() []string {
	var out []string
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return out
	}
	for _, a := range addrs {
		if ipn, ok := a.(*net.IPNet); ok {
			ip := ipn.IP.To4()
			if ip != nil && !ip.IsLoopback() && !ip.IsLinkLocalUnicast() {
				out = append(out, ip.String())
			}
		}
	}
	return out
}

// loadOrCreateCert makes a self-signed certificate on first use.
func loadOrCreateCert(dir string) (tls.Certificate, error) {
	certPath, keyPath := filepath.Join(dir, "cert.pem"), filepath.Join(dir, "key.pem")
	if c, err := tls.LoadX509KeyPair(certPath, keyPath); err == nil {
		return c, nil
	}
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return tls.Certificate{}, err
	}
	serial, _ := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 120))
	hostname, _ := os.Hostname()
	tmpl := &x509.Certificate{
		SerialNumber:          serial,
		Subject:               pkix.Name{CommonName: "WebIRC"},
		NotBefore:             time.Now().Add(-time.Hour),
		NotAfter:              time.Now().AddDate(10, 0, 0),
		KeyUsage:              x509.KeyUsageDigitalSignature,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
		DNSNames:              []string{"localhost"},
		IPAddresses:           []net.IP{net.ParseIP("127.0.0.1")},
	}
	if hostname != "" {
		tmpl.DNSNames = append(tmpl.DNSNames, hostname)
	}
	for _, ip := range lanIPs() {
		tmpl.IPAddresses = append(tmpl.IPAddresses, net.ParseIP(ip))
	}
	der, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &key.PublicKey, key)
	if err != nil {
		return tls.Certificate{}, err
	}
	kb, err := x509.MarshalECPrivateKey(key)
	if err != nil {
		return tls.Certificate{}, err
	}
	os.WriteFile(certPath, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der}), 0600)
	os.WriteFile(keyPath, pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: kb}), 0600)
	return tls.LoadX509KeyPair(certPath, keyPath)
}
