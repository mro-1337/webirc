package main

import (
	"bufio"
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"net"
	"strconv"
	"strings"
	"time"
)

// runDiagnostics checks an IRC server both with and without encryption and
// prints what it finds. Usage:  WebIRC.exe -test irc.example.net:6697
func runDiagnostics(target string) {
	host, portStr, err := net.SplitHostPort(target)
	if err != nil {
		host, portStr = target, "6697"
	}
	port, _ := strconv.Atoi(portStr)
	addr := net.JoinHostPort(host, strconv.Itoa(port))
	fmt.Printf("\nTesting IRC server %s port %d\n", host, port)
	fmt.Println(strings.Repeat("=", 60))

	// 1. Encrypted
	fmt.Println("\n[1] Encrypted connection (TLS)")
	d := &net.Dialer{Timeout: 15 * time.Second}
	tc, err := tls.DialWithDialer(d, "tcp", addr, ircTLSConfig(host, true))
	tlsOK := false
	if err != nil {
		fmt.Println("    FAILED:", explainTLSError(err))
		fmt.Println("    (raw error:", err, ")")
	} else {
		tlsOK = true
		st := tc.ConnectionState()
		fmt.Printf("    OK: %s, cipher %s\n", tls.VersionName(st.Version), tls.CipherSuiteName(st.CipherSuite))
		if len(st.PeerCertificates) > 0 {
			c := st.PeerCertificates[0]
			fmt.Printf("    Certificate for:  %s\n", c.Subject)
			fmt.Printf("    Issued by:        %s\n", c.Issuer)
			fmt.Printf("    Valid until:      %s\n", c.NotAfter.Format("2006-01-02"))
			if len(c.DNSNames) > 0 {
				fmt.Printf("    Names:            %s\n", strings.Join(c.DNSNames, ", "))
			}
			pool := x509.NewCertPool()
			for _, ic := range st.PeerCertificates[1:] {
				pool.AddCert(ic)
			}
			if _, verr := c.Verify(x509.VerifyOptions{DNSName: host, Intermediates: pool}); verr != nil {
				fmt.Println("    Trusted:          NO —", explainTLSError(verr))
				fmt.Println("    => In WebIRC turn ON \"Allow self-signed\" (selfsigned: yes)")
			} else {
				fmt.Println("    Trusted:          yes (a normal, valid certificate)")
			}
		}
		talkIRC(tc)
		tc.Close()
	}

	// 2. Plain
	fmt.Println("\n[2] Plain connection (no encryption)")
	pc, err := d.Dial("tcp", addr)
	if err != nil {
		fmt.Println("    FAILED:", err)
	} else {
		talkIRC(pc)
		pc.Close()
	}

	fmt.Println("\n" + strings.Repeat("=", 60))
	if tlsOK {
		fmt.Println("Result: this port supports ENCRYPTION — use  encryption: yes")
	}
	fmt.Println()
}

// talkIRC sends a registration and prints the first few lines back.
func talkIRC(c net.Conn) {
	nick := fmt.Sprintf("wtest%d", time.Now().UnixNano()%100000)
	fmt.Fprintf(c, "NICK %s\r\nUSER wtest 0 * :WebIRC test\r\n", nick)
	c.SetReadDeadline(time.Now().Add(10 * time.Second))
	r := bufio.NewReader(c)
	got := 0
	for got < 6 {
		line, err := readIRCLine(r)
		if err != nil {
			if got == 0 {
				fmt.Println("    No IRC reply:", err)
			}
			break
		}
		if got == 0 && looksLikeTLS(line) {
			fmt.Println("    Server replied with ENCRYPTED data — this port needs  encryption: yes")
			return
		}
		if strings.HasPrefix(line, "PING ") {
			fmt.Fprintf(c, "PONG %s\r\n", strings.TrimPrefix(line, "PING "))
		}
		if len(line) > 110 {
			line = line[:110] + "…"
		}
		fmt.Println("    server says:", line)
		got++
	}
	if got > 0 {
		fmt.Println("    => IRC works over this connection")
	}
	fmt.Fprintf(c, "QUIT :test done\r\n")
}
