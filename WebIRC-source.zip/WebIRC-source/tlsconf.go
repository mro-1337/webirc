// Re-enable older TLS features that many IRC servers still use
// (RSA key exchange, 3DES, small RSA keys). Go turns these off by default.

//go:debug tlsrsakex=1
//go:debug tls3des=1
//go:debug rsa1024min=0
package main

import (
	"crypto/tls"
	"crypto/x509"
	"errors"
	"fmt"
	"io"
	"net"
	"strings"
	"syscall"
)

func allCipherSuites() []uint16 {
	var ids []uint16
	for _, s := range tls.CipherSuites() {
		ids = append(ids, s.ID)
	}
	for _, s := range tls.InsecureCipherSuites() {
		ids = append(ids, s.ID)
	}
	return ids
}

// ircTLSConfig is as compatible as possible: TLS 1.0 - 1.3 and old ciphers,
// because IRC servers are often old or use self-made certificates.
func ircTLSConfig(host string, allowSelfSigned bool) *tls.Config {
	return &tls.Config{
		ServerName:         host,
		InsecureSkipVerify: allowSelfSigned,
		MinVersion:         tls.VersionTLS10,
		CipherSuites:       allCipherSuites(),
	}
}

// explainTLSError turns a TLS error into advice a person can act on.
func explainTLSError(err error) error {
	if err == nil {
		return nil
	}
	var hdr tls.RecordHeaderError
	var unknown x509.UnknownAuthorityError
	var invalid x509.CertificateInvalidError
	var host x509.HostnameError
	var verr *tls.CertificateVerificationError
	msg := err.Error()
	switch {
	case errors.As(err, &hdr) || strings.Contains(msg, "does not look like a TLS handshake"):
		return fmt.Errorf("this port answered WITHOUT encryption — it's a plain IRC port. Turn encryption off, or use the server's encrypted port")
	case errors.As(err, &unknown) || strings.Contains(msg, "unknown authority"):
		return fmt.Errorf("the server's certificate is self-signed (not from a known authority). Turn on \"Allow self-signed / invalid certificate\" (selfsigned: yes in config.txt)")
	case errors.As(err, &host):
		return fmt.Errorf("the server's certificate is for a different name (%v). Turn on \"Allow self-signed / invalid certificate\" (selfsigned: yes in config.txt)", host.Host)
	case errors.As(err, &invalid):
		return fmt.Errorf("the server's certificate is invalid or expired (%v). Turn on \"Allow self-signed / invalid certificate\" (selfsigned: yes in config.txt)", invalid)
	case errors.As(err, &verr):
		return fmt.Errorf("the server's certificate could not be verified (%v). Turn on \"Allow self-signed / invalid certificate\" (selfsigned: yes in config.txt)", verr.Err)
	case errors.Is(err, io.EOF) || errors.Is(err, syscall.ECONNRESET) || strings.Contains(msg, "connection reset"):
		return fmt.Errorf("the server hung up during the encryption handshake — this port probably doesn't use encryption. Try turning encryption off, or check the port number (%v)", err)
	case strings.Contains(msg, "protocol version") || strings.Contains(msg, "handshake failure"):
		return fmt.Errorf("couldn't agree on encryption settings with the server (%v)", err)
	}
	var ne net.Error
	if errors.As(err, &ne) && ne.Timeout() {
		return fmt.Errorf("timed out during the encryption handshake — the port may be plain IRC (turn encryption off) or the server is busy")
	}
	return err
}

// looksLikeTLS reports whether text received on a plain connection is really
// a TLS record (meaning the port expects encryption).
func looksLikeTLS(line string) bool {
	return len(line) >= 2 && (line[0] == 0x15 || line[0] == 0x16) && line[1] == 0x03
}
