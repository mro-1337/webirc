package main

import (
	"crypto/hmac"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"net/http"
	"strings"
	"time"
)

type Server struct {
	store  *Store
	sess   *Sessions
	mgr    *Manager
	static fs.FS
	cfg    *Config
	secret []byte
}

const gateCookie = "webirc_entry"

// gateToken changes whenever the entry password in config.txt changes,
// so everyone has to type the new one.
func (s *Server) gateToken() string {
	m := hmac.New(sha256.New, s.secret)
	m.Write([]byte("entry:" + s.cfg.EntryPassword))
	return hex.EncodeToString(m.Sum(nil))
}

func (s *Server) gateOK(r *http.Request) bool {
	if s.cfg.EntryPassword == "" {
		return true
	}
	c, err := r.Cookie(gateCookie)
	return err == nil && hmac.Equal([]byte(c.Value), []byte(s.gateToken()))
}

// gate blocks every API call until the entry password has been given.
func (s *Server) gate(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		p := r.URL.Path
		needs := (strings.HasPrefix(p, "/api/") || strings.HasPrefix(p, "/media")) &&
			p != "/api/status" && p != "/api/gate"
		if needs && !s.gateOK(r) {
			writeErr(w, http.StatusForbidden, "entry password required")
			return
		}
		next.ServeHTTP(w, r)
	})
}

func (s *Server) handleGate(w http.ResponseWriter, r *http.Request) {
	key := "gate|" + clientIP(r)
	if s.sess.Blocked(key) {
		writeErr(w, 429, "too many wrong tries — wait 10 minutes and try again")
		return
	}
	var req struct {
		Password string `json:"password"`
	}
	if err := readJSON(r, &req); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	if s.cfg.EntryPassword != "" && subtle.ConstantTimeCompare([]byte(req.Password), []byte(s.cfg.EntryPassword)) != 1 {
		s.sess.Fail(key)
		time.Sleep(700 * time.Millisecond)
		writeErr(w, 401, "wrong entry password")
		return
	}
	s.sess.ClearFails(key)
	http.SetCookie(w, &http.Cookie{
		Name: gateCookie, Value: s.gateToken(), Path: "/", MaxAge: int(sessionLifetime.Seconds()),
		HttpOnly: true, Secure: r.TLS != nil, SameSite: http.SameSiteStrictMode,
	})
	writeJSON(w, map[string]bool{"ok": true})
}

type userHandler func(w http.ResponseWriter, r *http.Request, user string)

func (s *Server) Routes() http.Handler {
	mux := http.NewServeMux()

	files := http.FileServerFS(s.static)
	mux.Handle("GET /", files)

	mux.HandleFunc("GET /api/status", s.handleStatus)
	mux.HandleFunc("POST /api/gate", s.handleGate)
	mux.HandleFunc("POST /api/signup", s.handleSignup)
	mux.HandleFunc("POST /api/login", s.handleLogin)
	mux.HandleFunc("POST /api/logout", s.handleLogout)

	mux.HandleFunc("GET /api/state", s.auth(s.handleState))
	mux.HandleFunc("GET /api/events", s.auth(s.handleEvents))
	mux.HandleFunc("POST /api/send", s.auth(s.handleSend))
	mux.HandleFunc("POST /api/close", s.auth(s.handleClose))
	mux.HandleFunc("POST /api/password", s.auth(s.handleOwnPassword))

	mux.HandleFunc("POST /api/networks", s.auth(s.handleSaveNetwork))
	mux.HandleFunc("DELETE /api/networks/{id}", s.auth(s.handleDeleteNetwork))
	mux.HandleFunc("POST /api/networks/{id}/connect", s.auth(s.handleConnect))
	mux.HandleFunc("POST /api/networks/{id}/disconnect", s.auth(s.handleDisconnect))

	mux.HandleFunc("GET /api/users", s.admin(s.handleListUsers))
	mux.HandleFunc("POST /api/users", s.admin(s.handleCreateUser))
	mux.HandleFunc("DELETE /api/users/{name}", s.admin(s.handleDeleteUser))
	mux.HandleFunc("POST /api/users/{name}/password", s.admin(s.handleResetPassword))
	mux.HandleFunc("POST /api/users/{name}/admin", s.admin(s.handleSetAdmin))

	mux.HandleFunc("GET /media", s.auth(s.handleMedia))
	mux.HandleFunc("GET /api/probe", s.auth(s.handleProbe))

	return securityHeaders(s.gate(mux))
}

func securityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		if !strings.HasPrefix(r.URL.Path, "/media") {
			h.Set("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "+
				"img-src 'self' data: https: http:; media-src 'self' https: http:; "+
				"frame-src https://www.youtube-nocookie.com https://player.vimeo.com; connect-src 'self'; "+
				"object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")
		}
		h.Set("X-Frame-Options", "DENY")
		h.Set("X-Content-Type-Options", "nosniff")
		h.Set("Referrer-Policy", "no-referrer")
		// Block cross-site form posts: every state-changing API call must carry this header,
		// which browsers won't let other websites add.
		if r.Method != http.MethodGet && r.Method != http.MethodHead && r.Header.Get("X-WebIRC") != "1" {
			http.Error(w, "missing request header", http.StatusForbidden)
			return
		}
		next.ServeHTTP(w, r)
	})
}

func (s *Server) currentUser(r *http.Request) (string, bool) {
	c, err := r.Cookie(sessionCookie)
	if err != nil {
		return "", false
	}
	user, ok := s.sess.Get(c.Value)
	if !ok {
		return "", false
	}
	if _, exists := s.store.GetUser(user); !exists {
		s.sess.Delete(c.Value)
		return "", false
	}
	return user, true
}

func (s *Server) auth(h userHandler) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		user, ok := s.currentUser(r)
		if !ok {
			writeErr(w, http.StatusUnauthorized, "please log in")
			return
		}
		h(w, r, user)
	}
}

func (s *Server) admin(h userHandler) http.HandlerFunc {
	return s.auth(func(w http.ResponseWriter, r *http.Request, user string) {
		if u, _ := s.store.GetUser(user); !u.Admin {
			writeErr(w, http.StatusForbidden, "admins only")
			return
		}
		h(w, r, user)
	})
}

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, code int, msg string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(map[string]string{"error": msg})
}

func readJSON(r *http.Request, v any) error {
	r.Body = http.MaxBytesReader(nil, r.Body, 1<<20)
	if err := json.NewDecoder(r.Body).Decode(v); err != nil {
		return errors.New("bad request")
	}
	return nil
}

// ---- login / setup ----

func (s *Server) handleStatus(w http.ResponseWriter, r *http.Request) {
	theme := firstNonEmpty(s.cfg.Theme, "dark")
	if !s.gateOK(r) {
		writeJSON(w, map[string]any{"gate": true, "theme": theme})
		return
	}
	setup := s.store.UserCount() == 0
	resp := map[string]any{"setup": setup, "signup": setup || s.cfg.AllowSignup, "customServers": s.cfg.AllowCustomServers, "theme": theme}
	if user, ok := s.currentUser(r); ok {
		u, _ := s.store.GetUser(user)
		resp["user"] = u
	}
	writeJSON(w, resp)
}

type credentials struct {
	Username string `json:"username"`
	Password string `json:"password"`
	Admin    bool   `json:"admin"`
}

// handleSignup creates an account. The very first account becomes the admin.
func (s *Server) handleSignup(w http.ResponseWriter, r *http.Request) {
	var c credentials
	if err := readJSON(r, &c); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	first := s.store.UserCount() == 0
	if !first && !s.cfg.AllowSignup {
		writeErr(w, 403, "creating accounts is turned off — ask an admin for an account")
		return
	}
	if err := s.store.CreateUser(c.Username, c.Password, first); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	name, _ := s.store.CheckLogin(c.Username, c.Password)
	s.mgr.Hub(name) // connect them to the forced servers right away
	setSessionCookie(w, r, s.sess.Create(name), int(sessionLifetime.Seconds()))
	writeJSON(w, map[string]bool{"ok": true})
}

func (s *Server) handleLogin(w http.ResponseWriter, r *http.Request) {
	ip := clientIP(r)
	if s.sess.Blocked(ip) {
		writeErr(w, 429, "too many failed logins — wait 10 minutes and try again")
		return
	}
	var c credentials
	if err := readJSON(r, &c); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	name, ok := s.store.CheckLogin(c.Username, c.Password)
	if !ok {
		s.sess.Fail(ip)
		time.Sleep(700 * time.Millisecond)
		writeErr(w, 401, "wrong username or password")
		return
	}
	s.sess.ClearFails(ip)
	setSessionCookie(w, r, s.sess.Create(name), int(sessionLifetime.Seconds()))
	writeJSON(w, map[string]bool{"ok": true})
}

func (s *Server) handleLogout(w http.ResponseWriter, r *http.Request) {
	if c, err := r.Cookie(sessionCookie); err == nil {
		s.sess.Delete(c.Value)
	}
	setSessionCookie(w, r, "", -1)
	writeJSON(w, map[string]bool{"ok": true})
}

func (s *Server) handleOwnPassword(w http.ResponseWriter, r *http.Request, user string) {
	var req struct {
		Old string `json:"old"`
		New string `json:"new"`
	}
	if err := readJSON(r, &req); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	if _, ok := s.store.CheckLogin(user, req.Old); !ok {
		writeErr(w, 400, "current password is wrong")
		return
	}
	if err := s.store.SetPassword(user, req.New); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	cur := ""
	if c, err := r.Cookie(sessionCookie); err == nil {
		cur = c.Value
	}
	s.sess.DeleteUser(user, cur) // log out other devices
	writeJSON(w, map[string]bool{"ok": true})
}

// ---- chat ----

func (s *Server) handleState(w http.ResponseWriter, r *http.Request, user string) {
	u, _ := s.store.GetUser(user)
	writeJSON(w, map[string]any{"user": u, "customServers": s.cfg.AllowCustomServers, "networks": s.mgr.Hub(user).State()})
}

func (s *Server) handleEvents(w http.ResponseWriter, r *http.Request, user string) {
	fl, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "streaming unsupported", 500)
		return
	}
	hub := s.mgr.Hub(user)
	ch := hub.Subscribe()
	defer hub.Unsubscribe(ch)

	h := w.Header()
	h.Set("Content-Type", "text/event-stream")
	h.Set("Cache-Control", "no-store")
	h.Set("X-Accel-Buffering", "no")
	fmt.Fprint(w, "retry: 3000\n\n")
	fl.Flush()

	tick := time.NewTicker(25 * time.Second)
	defer tick.Stop()
	for {
		select {
		case b, ok := <-ch:
			if !ok {
				return
			}
			w.Write([]byte("data: "))
			w.Write(b)
			w.Write([]byte("\n\n"))
			// Send anything else that's already queued before flushing.
			for more := true; more; {
				select {
				case b2, ok2 := <-ch:
					if !ok2 {
						fl.Flush()
						return
					}
					w.Write([]byte("data: "))
					w.Write(b2)
					w.Write([]byte("\n\n"))
				default:
					more = false
				}
			}
			fl.Flush()
		case <-tick.C:
			if _, ok := s.currentUser(r); !ok {
				return
			}
			fmt.Fprint(w, ": ping\n\n")
			fl.Flush()
		case <-r.Context().Done():
			return
		}
	}
}

type bufRef struct {
	Net  string `json:"net"`
	Buf  string `json:"buf"`
	Text string `json:"text"`
}

func (s *Server) handleSend(w http.ResponseWriter, r *http.Request, user string) {
	var req bufRef
	if err := readJSON(r, &req); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	c := s.mgr.Hub(user).Conn(req.Net)
	if c == nil {
		writeErr(w, 404, "no such network")
		return
	}
	sw, err := c.Input(req.Buf, req.Text)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeJSON(w, map[string]string{"switch": sw})
}

func (s *Server) handleClose(w http.ResponseWriter, r *http.Request, user string) {
	var req bufRef
	if err := readJSON(r, &req); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	if c := s.mgr.Hub(user).Conn(req.Net); c != nil {
		if err := c.CloseBuffer(req.Buf); err != nil {
			writeErr(w, 400, err.Error())
			return
		}
	}
	writeJSON(w, map[string]bool{"ok": true})
}

// ---- networks ----

func (s *Server) handleSaveNetwork(w http.ResponseWriter, r *http.Request, user string) {
	var n Network
	if err := readJSON(r, &n); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	// Masked passwords sent back from the edit form mean "keep the old one".
	if n.ID != "" {
		if old, ok := s.store.Network(user, n.ID); ok {
			if n.ServerPass == secretMask {
				n.ServerPass = old.ServerPass
			}
			if n.NickServPass == secretMask {
				n.NickServPass = old.NickServPass
			}
		}
	}
	saved, err := s.mgr.Hub(user).SaveNetwork(n)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeJSON(w, map[string]string{"id": saved.ID})
}

func (s *Server) handleDeleteNetwork(w http.ResponseWriter, r *http.Request, user string) {
	if err := s.mgr.Hub(user).DeleteNetwork(r.PathValue("id")); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeJSON(w, map[string]bool{"ok": true})
}

func (s *Server) handleConnect(w http.ResponseWriter, r *http.Request, user string) {
	c := s.mgr.Hub(user).Conn(r.PathValue("id"))
	if c == nil {
		writeErr(w, 404, "no such network")
		return
	}
	c.Connect()
	writeJSON(w, map[string]bool{"ok": true})
}

func (s *Server) handleDisconnect(w http.ResponseWriter, r *http.Request, user string) {
	c := s.mgr.Hub(user).Conn(r.PathValue("id"))
	if c == nil {
		writeErr(w, 404, "no such network")
		return
	}
	c.Disconnect("Leaving")
	writeJSON(w, map[string]bool{"ok": true})
}

// ---- user administration ----

func (s *Server) handleListUsers(w http.ResponseWriter, r *http.Request, user string) {
	writeJSON(w, s.store.ListUsers())
}

func (s *Server) handleCreateUser(w http.ResponseWriter, r *http.Request, user string) {
	var c credentials
	if err := readJSON(r, &c); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	if err := s.store.CreateUser(c.Username, c.Password, c.Admin); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	if u, ok := s.store.GetUser(c.Username); ok {
		s.mgr.Hub(u.Username) // connect them to the forced servers right away
	}
	writeJSON(w, map[string]bool{"ok": true})
}

func (s *Server) handleDeleteUser(w http.ResponseWriter, r *http.Request, user string) {
	name := r.PathValue("name")
	if strings.EqualFold(name, user) {
		writeErr(w, 400, "you can't delete your own account")
		return
	}
	target, ok := s.store.GetUser(name)
	if !ok {
		writeErr(w, 404, "no such user")
		return
	}
	if err := s.store.DeleteUser(name); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	s.mgr.RemoveUser(target.Username)
	s.sess.DeleteUser(target.Username, "")
	writeJSON(w, map[string]bool{"ok": true})
}

func (s *Server) handleResetPassword(w http.ResponseWriter, r *http.Request, user string) {
	var req struct {
		Password string `json:"password"`
	}
	if err := readJSON(r, &req); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	target, ok := s.store.GetUser(r.PathValue("name"))
	if !ok {
		writeErr(w, 404, "no such user")
		return
	}
	if err := s.store.SetPassword(target.Username, req.Password); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	if !strings.EqualFold(target.Username, user) {
		s.sess.DeleteUser(target.Username, "")
	}
	writeJSON(w, map[string]bool{"ok": true})
}

func (s *Server) handleSetAdmin(w http.ResponseWriter, r *http.Request, user string) {
	var req struct {
		Admin bool `json:"admin"`
	}
	if err := readJSON(r, &req); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	name := r.PathValue("name")
	if !req.Admin && strings.EqualFold(name, user) {
		writeErr(w, 400, "you can't remove your own admin rights")
		return
	}
	if err := s.store.SetAdmin(name, req.Admin); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeJSON(w, map[string]bool{"ok": true})
}
