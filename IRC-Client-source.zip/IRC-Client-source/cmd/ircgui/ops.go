package main

// Name menu (private chat, whois, CTCP, DCC, op/voice, kick, ban with mask
// choice), channel settings (topic, modes, key, limit, bans) and DCC
// offers / transfers window.

import (
	"fmt"
	"strconv"
	"strings"
	"time"

	"ircclient/core"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/theme"
	"fyne.io/fyne/v2/widget"
)

// ---------------------------------------------------------------------------
// Clickable names in the people list
// ---------------------------------------------------------------------------

type nickItem struct {
	widget.BaseWidget
	g    *gui
	rt   *widget.RichText
	nick string
}

func newNickItem(g *gui) *nickItem {
	n := &nickItem{g: g, rt: widget.NewRichText(&widget.TextSegment{})}
	n.ExtendBaseWidget(n)
	return n
}

func (n *nickItem) CreateRenderer() fyne.WidgetRenderer { return widget.NewSimpleRenderer(n.rt) }
func (n *nickItem) Tapped(pe *fyne.PointEvent) {
	n.g.showNickMenu(n.nick, pe.AbsolutePosition)
}
func (n *nickItem) TappedSecondary(pe *fyne.PointEvent) {
	n.g.showNickMenu(n.nick, pe.AbsolutePosition)
}

func (g *gui) showNickMenu(nick string, pos fyne.Position) {
	if nick == "" {
		return
	}
	widget.ShowPopUpMenuAtPosition(fyne.NewMenu("", g.nickMenuItems(nick)...), g.win.Canvas(), pos)
}

// nickMenuItems are the actions for a person (used by the people list and
// the right-click menu on chat lines).
func (g *gui) nickMenuItems(nick string) []*fyne.MenuItem {
	c := g.cl.Conn(g.cur.conn)
	if c == nil {
		return nil
	}
	ch := ""
	if c.IsChannel(g.cur.buf) {
		ch = g.cur.buf
	}
	errNote := func(err error) {
		if err != nil {
			g.note("error", err.Error())
		}
	}
	ctcp := func(what string) func() { return func() { errNote(c.CTCP(nick, what, "")) } }
	items := []*fyne.MenuItem{
		fyne.NewMenuItem("Private chat with "+nick, func() { g.openQuery(nick) }),
		fyne.NewMenuItem("Whois (info about "+nick+")", func() { errNote(c.Whois(nick)); g.switchTo(c.ID(), "*") }),
	}
	ctcpItem := fyne.NewMenuItem("Check their client (CTCP)", nil)
	ctcpItem.ChildMenu = fyne.NewMenu("",
		fyne.NewMenuItem("Version", ctcp("VERSION")),
		fyne.NewMenuItem("Ping (lag)", ctcp("PING")),
		fyne.NewMenuItem("Time", ctcp("TIME")),
		fyne.NewMenuItem("Client info", ctcp("CLIENTINFO")),
	)
	items = append(items, ctcpItem,
		fyne.NewMenuItem("Direct chat (DCC)", func() {
			if _, err := c.OfferChat(nick); err != nil {
				g.note("error", "DCC: "+err.Error())
			}
		}),
		fyne.NewMenuItem("Send a file (DCC)…", func() { g.sendFileTo(c, nick) }),
	)
	if ch != "" {
		mode := func(m string) func() { return func() { errNote(c.UserMode(ch, m, nick)) } }
		items = append(items, fyne.NewMenuItemSeparator(),
			fyne.NewMenuItem("Give op (+o)", mode("+o")),
			fyne.NewMenuItem("Take op (-o)", mode("-o")),
			fyne.NewMenuItem("Give voice (+v)", mode("+v")),
			fyne.NewMenuItem("Take voice (-v)", mode("-v")),
			fyne.NewMenuItemSeparator(),
			fyne.NewMenuItem("Kick…", func() { g.kickDialog(c, ch, nick, -1) }),
		)
		banItem := fyne.NewMenuItem("Ban", nil)
		kbItem := fyne.NewMenuItem("Kick + ban", nil)
		var banSub, kbSub []*fyne.MenuItem
		for i := range core.BanMaskTypes {
			t := i
			label := fmt.Sprintf("%-14s  %s", core.BanMaskLabel(t), c.BanMaskPreview(t, nick))
			banSub = append(banSub, fyne.NewMenuItem(label, func() { errNote(c.Ban(ch, nick, t, false, "")) }))
			kbSub = append(kbSub, fyne.NewMenuItem(label, func() { g.kickDialog(c, ch, nick, t) }))
		}
		banItem.ChildMenu = fyne.NewMenu("", banSub...)
		kbItem.ChildMenu = fyne.NewMenu("", kbSub...)
		items = append(items, banItem, kbItem)
	}
	items = append(items, fyne.NewMenuItemSeparator(),
		fyne.NewMenuItem("Copy nickname", func() { g.app.Clipboard().SetContent(nick) }))
	return items
}

// kickDialog asks for a reason; with banType >= 0 it bans first (mask choice shown).
func (g *gui) kickDialog(c *core.Conn, ch, nick string, banType int) {
	reason := widget.NewEntry()
	reason.SetPlaceHolder("Reason (optional)")
	var maskSel *widget.Select
	items := []*widget.FormItem{widget.NewFormItem("Reason", reason)}
	if banType >= 0 {
		var opts []string
		for i := range core.BanMaskTypes {
			opts = append(opts, fmt.Sprintf("%s   →  %s", core.BanMaskLabel(i), c.BanMaskPreview(i, nick)))
		}
		maskSel = widget.NewSelect(opts, nil)
		maskSel.SetSelectedIndex(banType)
		items = append(items, widget.NewFormItem("Ban mask", maskSel))
	}
	title := "Kick " + nick + " from " + ch
	if banType >= 0 {
		title = "Kick + ban " + nick + " from " + ch
	}
	dialog.ShowForm(title, "Kick", "Cancel", items, func(ok bool) {
		if !ok {
			return
		}
		var err error
		if maskSel != nil {
			err = c.Ban(ch, nick, maskSel.SelectedIndex(), true, reason.Text)
		} else {
			err = c.Kick(ch, nick, reason.Text)
		}
		if err != nil {
			g.note("error", err.Error())
		}
	}, g.win)
}

// ---------------------------------------------------------------------------
// Channel settings
// ---------------------------------------------------------------------------

type chanDialog struct {
	ch      string
	bansBox *fyne.Container
	refresh func()
}

func (g *gui) chanSettingsDialog() {
	c := g.cl.Conn(g.cur.conn)
	if c == nil {
		return
	}
	ch := g.cur.buf
	ci, ok := c.ChannelInfo(ch)
	if !ok {
		g.note("error", "Channel settings only work in a channel window")
		return
	}
	topic := widget.NewMultiLineEntry()
	topic.Wrapping = fyne.TextWrapWord
	topic.SetMinRowsVisible(2)
	topic.SetText(ci.Topic)
	var checks []*widget.Check
	modeBox := container.NewVBox()
	for _, m := range core.SimpleModes {
		chk := widget.NewCheck(m.Label, nil)
		chk.SetChecked(strings.IndexByte(ci.Modes, m.Letter) >= 0)
		checks = append(checks, chk)
		modeBox.Add(chk)
	}
	key := widget.NewEntry()
	key.SetText(ci.Key)
	key.SetPlaceHolder("no password")
	limit := widget.NewEntry()
	if ci.Limit > 0 {
		limit.SetText(strconv.Itoa(ci.Limit))
	}
	limit.SetPlaceHolder("no limit")

	// ban list
	bansBox := container.NewVBox()
	newBan := widget.NewEntry()
	newBan.SetPlaceHolder("*!*@host.example.com")
	addBan := widget.NewButtonWithIcon("Add ban", theme.ContentAddIcon(), func() {
		if m := strings.TrimSpace(newBan.Text); m != "" {
			if err := c.SendRaw("MODE " + ch + " +b " + m); err != nil {
				g.note("error", err.Error())
			}
			newBan.SetText("")
		}
	})
	fillBans := func() {
		info, _ := c.ChannelInfo(ch)
		bansBox.Objects = nil
		if info.Bans == nil {
			bansBox.Add(widget.NewLabel("Loading ban list…"))
		} else if len(info.Bans) == 0 {
			bansBox.Add(widget.NewLabel("No bans."))
		}
		for _, b := range info.Bans {
			mask := b.Mask
			lbl := widget.NewLabel(mask)
			lbl.Truncation = fyne.TextTruncateEllipsis
			sub := "set by " + b.SetBy
			if !b.When.IsZero() {
				sub += ", " + b.When.Format("2006-01-02 15:04")
			}
			who := widget.NewLabel(sub)
			who.Importance = widget.LowImportance
			rm := widget.NewButtonWithIcon("Remove", theme.DeleteIcon(), func() {
				if err := c.Unban(ch, mask); err != nil {
					g.note("error", err.Error())
				}
			})
			bansBox.Add(container.NewBorder(nil, nil, nil, rm, container.NewVBox(lbl, who)))
		}
		bansBox.Refresh()
	}
	c.RequestBans(ch)
	fillBans()
	g.chanDlg = &chanDialog{ch: ch, bansBox: bansBox, refresh: fillBans}

	opNote := widget.NewLabel("")
	opNote.Wrapping = fyne.TextWrapWord
	opNote.Importance = widget.WarningImportance
	if !c.IsOp(ch) {
		opNote.SetText("You're not a channel operator here, so the server will probably refuse changes.")
	}
	form := widget.NewForm(
		widget.NewFormItem("Topic", topic),
		widget.NewFormItem("Modes", modeBox),
		widget.NewFormItem("Password (+k)", key),
		widget.NewFormItem("User limit (+l)", limit),
	)
	bansScroll := container.NewVScroll(bansBox)
	bansScroll.SetMinSize(fyne.NewSize(0, 150))
	bansPart := container.NewBorder(widget.NewLabelWithStyle("Bans", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		container.NewBorder(nil, nil, nil, addBan, newBan), nil, nil, bansScroll)

	var d dialog.Dialog
	errLbl := widget.NewLabel("")
	errLbl.Importance = widget.DangerImportance
	save := widget.NewButtonWithIcon("Apply", theme.ConfirmIcon(), func() {
		n := 0
		if t := strings.TrimSpace(limit.Text); t != "" {
			var err error
			if n, err = strconv.Atoi(t); err != nil || n < 0 {
				errLbl.SetText("User limit must be a number (or empty for no limit)")
				return
			}
		}
		modes := ""
		for i, m := range core.SimpleModes {
			if checks[i].Checked {
				modes += string(m.Letter)
			}
		}
		if t := strings.ReplaceAll(topic.Text, "\n", " "); t != ci.Topic {
			if err := c.SetTopic(ch, t); err != nil {
				errLbl.SetText(err.Error())
				return
			}
		}
		if err := c.ApplyChannelModes(ch, modes, key.Text, n); err != nil {
			errLbl.SetText(err.Error())
			return
		}
		d.Hide()
	})
	save.Importance = widget.HighImportance
	buttons := container.NewHBox(layout.NewSpacer(), widget.NewButton("Close", func() { d.Hide() }), save)
	content := container.NewBorder(container.NewVBox(opNote, form), container.NewVBox(errLbl, buttons), nil, nil, bansPart)
	d = dialog.NewCustomWithoutButtons("Channel settings — "+ch, content, g.win)
	d.SetOnClosed(func() { g.chanDlg = nil })
	d.Resize(fyne.NewSize(640, 720))
	d.Show()
}

// ---------------------------------------------------------------------------
// DCC: offers, sending files, transfers window
// ---------------------------------------------------------------------------

func (g *gui) showDCCOffer(id int) {
	d, ok := g.cl.DCCInfo(id)
	if !ok || !d.IsOffer {
		return
	}
	var msg string
	if d.Kind == "receive" {
		msg = fmt.Sprintf("%s wants to send you a file:\n\n%s  (%s)\n\nIt will be saved in:\n%s", d.Nick, d.File, core.HumanSize(d.Size), g.cl.DownloadsDir())
	} else {
		msg = fmt.Sprintf("%s wants a direct (DCC) chat with you.\n\nDirect chats go straight between your computers, not through the server.", d.Nick)
	}
	lbl := widget.NewLabel(msg)
	lbl.Wrapping = fyne.TextWrapWord
	title := "File offer from " + d.Nick
	if d.Kind != "receive" {
		title = "Chat request from " + d.Nick
	}
	dlg := dialog.NewCustomConfirm(title, "Accept", "Decline", lbl, func(ok bool) {
		if !ok {
			g.cl.DeclineDCC(id)
			return
		}
		if err := g.cl.AcceptDCC(id); err != nil {
			g.note("error", "DCC: "+err.Error())
			return
		}
		if d.ChatWin != "" {
			if c := g.cl.Conn(d.ConnID); c != nil {
				g.waitAndSwitch(c, d.ChatWin)
			}
		} else {
			g.transfersDialog()
		}
	}, g.win)
	dlg.Resize(fyne.NewSize(460, 260))
	dlg.Show()
}

func (g *gui) sendFileTo(c *core.Conn, nick string) {
	fd := dialog.NewFileOpen(func(r fyne.URIReadCloser, err error) {
		if err != nil || r == nil {
			return
		}
		path := r.URI().Path()
		r.Close()
		if _, err := c.OfferFile(nick, path); err != nil {
			g.note("error", "DCC: "+err.Error())
			return
		}
		g.transfersDialog()
	}, g.win)
	fd.Resize(fyne.NewSize(760, 540))
	fd.Show()
}

type transfersWin struct {
	box *fyne.Container
	d   dialog.Dialog
}

func (g *gui) transfersDialog() {
	if g.xfers != nil {
		g.refreshTransfers()
		return
	}
	box := container.NewVBox()
	scroll := container.NewVScroll(box)
	scroll.SetMinSize(fyne.NewSize(0, 300))
	var d dialog.Dialog
	clear := widget.NewButton("Clear finished", func() { g.cl.ClearFinishedDCC(); g.refreshTransfers() })
	folder := widget.NewButtonWithIcon("Open downloads folder", theme.FolderOpenIcon(), func() {
		dir := g.cl.DownloadsDir()
		core.OpenFolder(dir)
	})
	hint := widget.NewLabel("Send files or start direct chats from the people list (click a name). Ports and your public IP are in Settings.")
	hint.Wrapping = fyne.TextWrapWord
	hint.Importance = widget.LowImportance
	closeBtn := widget.NewButton("Close", func() { d.Hide() })
	content := container.NewBorder(hint, container.NewHBox(folder, clear, layout.NewSpacer(), closeBtn), nil, nil, scroll)
	d = dialog.NewCustomWithoutButtons("DCC chats & file transfers", content, g.win)
	g.xfers = &transfersWin{box: box, d: d}
	d.SetOnClosed(func() { g.xfers = nil })
	d.Resize(fyne.NewSize(680, 480))
	g.refreshTransfers()
	d.Show()
}

func (g *gui) refreshTransfers() {
	if g.xfers == nil {
		return
	}
	box := g.xfers.box
	box.Objects = nil
	list := g.cl.Transfers()
	if len(list) == 0 {
		box.Add(widget.NewLabel("No DCC chats or file transfers yet."))
	}
	for i := len(list) - 1; i >= 0; i-- {
		d := list[i]
		id := d.ID
		title := widget.NewLabelWithStyle(dccTitle(d), fyne.TextAlignLeading, fyne.TextStyle{Bold: true})
		title.Truncation = fyne.TextTruncateEllipsis
		status := widget.NewLabel(dccStatus(d))
		status.Importance = widget.LowImportance
		if d.State == "failed" {
			status.Importance = widget.DangerImportance
		}
		row := container.NewVBox(title)
		if !strings.HasPrefix(d.Kind, "chat") && d.Size > 0 {
			pb := widget.NewProgressBar()
			pb.SetValue(float64(d.Done) / float64(d.Size))
			row.Add(pb)
		}
		row.Add(status)
		btns := container.NewHBox()
		switch {
		case d.IsOffer:
			acc := widget.NewButton("Accept", func() {
				if err := g.cl.AcceptDCC(id); err != nil {
					g.note("error", "DCC: "+err.Error())
				}
				if d.ChatWin != "" {
					if c := g.cl.Conn(d.ConnID); c != nil {
						g.waitAndSwitch(c, d.ChatWin)
					}
				}
			})
			acc.Importance = widget.HighImportance
			btns.Add(acc)
			btns.Add(widget.NewButton("Decline", func() { g.cl.DeclineDCC(id) }))
		case !d.Finished:
			btns.Add(widget.NewButtonWithIcon("Cancel", theme.CancelIcon(), func() { g.cl.CancelDCC(id) }))
			if d.ChatWin != "" {
				btns.Add(widget.NewButton("Open chat", func() {
					if c := g.cl.Conn(d.ConnID); c != nil {
						g.switchTo(c.ID(), d.ChatWin)
					}
				}))
			}
		case d.State == "done" && d.Kind == "receive":
			path := d.Path
			btns.Add(widget.NewButtonWithIcon("Show file", theme.FolderOpenIcon(), func() { core.OpenFolder(dirOf(path)) }))
		}
		box.Add(container.NewBorder(nil, nil, nil, container.NewCenter(btns), row))
		box.Add(widget.NewSeparator())
	}
	box.Refresh()
}

func dirOf(p string) string {
	if i := strings.LastIndexAny(p, `/\`); i > 0 {
		return p[:i]
	}
	return p
}

func dccTitle(d core.DCCInfo) string {
	switch d.Kind {
	case "send":
		return fmt.Sprintf("↑ %s  to %s", d.File, d.Nick)
	case "receive":
		return fmt.Sprintf("↓ %s  from %s", d.File, d.Nick)
	}
	return "Direct chat with " + d.Nick
}

func dccStatus(d core.DCCInfo) string {
	state := map[string]string{"offered": "waiting for you to accept", "waiting": "waiting for them to accept",
		"connecting": "connecting…", "active": "in progress", "done": "finished", "failed": "failed",
		"declined": "declined", "cancelled": "cancelled", "closed": "closed"}[d.State]
	if state == "" {
		state = d.State
	}
	if strings.HasPrefix(d.Kind, "chat") {
		if d.Err != "" {
			state += " — " + d.Err
		}
		return state
	}
	s := fmt.Sprintf("%s · %s of %s", state, core.HumanSize(d.Done), core.HumanSize(d.Size))
	if d.Size > 0 {
		s += fmt.Sprintf(" (%d%%)", d.Done*100/d.Size)
	}
	if d.Speed > 0 {
		s += " · " + core.HumanSize(int64(d.Speed)) + "/s"
		if d.State == "active" && d.Size > d.Done {
			left := time.Duration(float64(d.Size-d.Done)/d.Speed) * time.Second
			s += " · " + left.Round(time.Second).String() + " left"
		}
	}
	if d.Err != "" {
		s += " — " + d.Err
	}
	return s
}
