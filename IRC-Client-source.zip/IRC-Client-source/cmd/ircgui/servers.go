package main

// Servers window (edit / connect / delete / add / import / export),
// channel list (/list) and mention notifications.

import (
	"fmt"
	"io"
	"strings"
	"time"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/theme"
	"fyne.io/fyne/v2/widget"

	"ircclient/core"
)

func splitList(text, sep string) []string {
	out := []string{}
	for _, w := range strings.Split(text, sep) {
		if w = strings.TrimSpace(w); w != "" {
			out = append(out, w)
		}
	}
	return out
}

// ---------------------------------------------------------------------------
// Servers window
// ---------------------------------------------------------------------------

func (g *gui) serversDialog() {
	rows := container.NewVBox()
	var d dialog.Dialog
	build := func() {
		rows.Objects = nil
		conns := g.cl.Conns()
		if len(conns) == 0 {
			l := widget.NewLabel("No servers yet. Click \"Add server\", or \"Import…\" to bring in\nservers from another IRC program or a settings file.")
			rows.Add(l)
		}
		for _, c := range conns {
			c := c
			cfg := c.Config()
			info := c.Info()
			status := info.Status
			if info.Error != "" && status != "connected" {
				status += " — " + info.Error
			}
			enc := "plain"
			if cfg.TLS {
				enc = "encrypted"
			}
			name := widget.NewLabelWithStyle(cfg.DisplayName(), fyne.TextAlignLeading, fyne.TextStyle{Bold: true})
			detail := widget.NewLabel(fmt.Sprintf("%s:%d · %s · %s", cfg.Host, cfg.EffectivePort(), enc, status))
			detail.Importance = widget.LowImportance
			detail.Truncation = fyne.TextTruncateEllipsis
			edit := widget.NewButtonWithIcon("Edit", theme.DocumentCreateIcon(), func() { g.serverDialog(c) })
			connLabel := "Connect"
			if status != "disconnected" && !strings.HasPrefix(status, "disconnected") {
				connLabel = "Disconnect"
			}
			conn := widget.NewButton(connLabel, func() {
				if connLabel == "Connect" {
					c.Connect()
				} else {
					c.Disconnect("Leaving")
				}
				time.AfterFunc(300*time.Millisecond, func() { fyne.Do(g.refreshAll) })
			})
			open := widget.NewButtonWithIcon("", theme.NavigateNextIcon(), func() {
				d.Hide()
				g.switchTo(c.ID(), "*")
			})
			del := widget.NewButtonWithIcon("", theme.DeleteIcon(), func() {
				dialog.ShowConfirm("Delete server", "Remove "+cfg.DisplayName()+" from your list?", func(ok bool) {
					if ok {
						g.cl.RemoveServer(cfg.ID)
						if g.cur.conn == cfg.ID {
							if cs := g.cl.Conns(); len(cs) > 0 {
								g.switchTo(cs[0].ID(), "*")
							} else {
								g.cur.conn = ""
							}
						}
						g.refreshAll()
					}
				}, g.win)
			})
			btns := container.NewHBox(edit, conn, del, open)
			rows.Add(container.NewBorder(nil, nil, nil, btns, container.NewVBox(name, detail)))
			rows.Add(widget.NewSeparator())
		}
		rows.Refresh()
	}
	build()
	add := widget.NewButtonWithIcon("Add server", theme.ContentAddIcon(), func() { g.serverDialog(nil) })
	add.Importance = widget.HighImportance
	imp := widget.NewButtonWithIcon("Import…", theme.DownloadIcon(), g.importDialog)
	exp := widget.NewButtonWithIcon("Export…", theme.UploadIcon(), g.exportDialog)
	closeBtn := widget.NewButton("Close", func() { d.Hide() })
	hint := widget.NewLabel("Import reads: this program's settings file, a WebIRC config, HexChat servlist.conf, mIRC servers.ini, or a text file with one server per line (e.g.  irc.libera.chat 6697 tls #linux).")
	hint.Wrapping = fyne.TextWrapWord
	hint.Importance = widget.LowImportance
	bottom := container.NewVBox(hint, container.NewHBox(add, imp, exp, layout.NewSpacer(), closeBtn))
	d = dialog.NewCustomWithoutButtons("Servers", container.NewBorder(nil, bottom, nil, nil, container.NewVScroll(rows)), g.win)
	d.SetOnClosed(func() { g.srvDlg = nil })
	g.srvDlg = build
	d.Resize(fyne.NewSize(680, 520))
	d.Show()
}

func (g *gui) importDialog() {
	fd := dialog.NewFileOpen(func(r fyne.URIReadCloser, err error) {
		if err != nil || r == nil {
			return
		}
		path := r.URI().Path()
		r.Close()
		all := widget.NewCheck("Also import nickname, theme and other settings", nil)
		msg := widget.NewLabel("Import servers from\n" + path + " ?\n\nServers you already have are updated (new channels are added).")
		msg.Wrapping = fyne.TextWrapWord
		dialog.ShowCustomConfirm("Import", "Import", "Cancel", container.NewVBox(msg, all), func(ok bool) {
			if !ok {
				return
			}
			res, err := g.cl.Import(path, all.Checked)
			if err != nil {
				dialog.ShowError(err, g.win)
				return
			}
			if res.Settings {
				g.glob = g.cl.Global()
				g.setTheme(g.glob.Theme)
			}
			g.refreshAll()
			l := widget.NewLabel(res.Summary() + "\n\nNew servers are not connected yet — use Connect in the Servers window.")
			l.Wrapping = fyne.TextWrapWord
			info := dialog.NewCustom("Import finished", "OK", l, g.win)
			info.Resize(fyne.NewSize(520, 220))
			info.Show()
		}, g.win)
	}, g.win)
	fd.Resize(fyne.NewSize(760, 540))
	fd.Show()
}

func (g *gui) exportDialog() {
	fd := dialog.NewFileSave(func(w fyne.URIWriteCloser, err error) {
		if err != nil || w == nil {
			return
		}
		_, err = io.WriteString(w, g.cl.ExportText())
		w.Close()
		if err != nil {
			dialog.ShowError(err, g.win)
			return
		}
		dialog.ShowInformation("Exported", "Saved your servers and settings to\n"+w.URI().Path()+"\n\nIt includes your passwords — keep it safe.", g.win)
	}, g.win)
	fd.SetFileName("irc-servers.txt")
	fd.Resize(fyne.NewSize(760, 540))
	fd.Show()
}

// ---------------------------------------------------------------------------
// Channel list
// ---------------------------------------------------------------------------

type listDialog struct {
	conn    string
	refresh func()
}

func (g *gui) listArrived(conn string) {
	if g.listDlg != nil && g.listDlg.conn == conn {
		g.listDlg.refresh()
		return
	}
	if c := g.cl.Conn(conn); c != nil {
		g.channelListDialog(c, false)
	}
}

func (g *gui) channelListDialog(c *core.Conn, ask bool) {
	if g.listDlg != nil {
		return
	}
	var items []core.ListEntry
	status := widget.NewLabel("")
	filter := widget.NewEntry()
	filter.SetPlaceHolder("search names and topics")
	list := widget.NewList(
		func() int { return len(items) },
		func() fyne.CanvasObject {
			l := widget.NewLabel("")
			l.Truncation = fyne.TextTruncateEllipsis
			return l
		},
		func(i widget.ListItemID, o fyne.CanvasObject) {
			if i < len(items) {
				e := items[i]
				o.(*widget.Label).SetText(fmt.Sprintf("%-22s %5d   %s", e.Channel, e.Users, e.Topic))
			}
		})
	var d dialog.Dialog
	refresh := func() {
		var busy bool
		var got int
		items, busy, got = c.ChannelList(filter.Text)
		if len(items) > 5000 {
			items = items[:5000]
		}
		if busy {
			status.SetText(fmt.Sprintf("Receiving the channel list… %d so far", got))
		} else {
			status.SetText(fmt.Sprintf("%d channels shown (biggest first). Click one to join.", len(items)))
		}
		list.UnselectAll()
		list.Refresh()
	}
	filter.OnChanged = func(string) { refresh() }
	list.OnSelected = func(i widget.ListItemID) {
		if i >= len(items) {
			return
		}
		ch := items[i].Channel
		d.Hide()
		if sw, err := c.Input("*", "/join "+ch); err != nil {
			g.note("error", err.Error())
		} else if sw != "" {
			g.waitAndSwitch(c, sw)
		}
	}
	reload := widget.NewButtonWithIcon("Reload", theme.ViewRefreshIcon(), func() {
		if err := c.RequestList(""); err != nil {
			dialog.ShowError(err, g.win)
		}
		refresh()
	})
	stop := make(chan struct{})
	go func() { // show progress while the server is still sending
		t := time.NewTicker(time.Second)
		defer t.Stop()
		for {
			select {
			case <-stop:
				return
			case <-t.C:
				if _, busy, _ := c.ChannelList("\x00"); busy {
					fyne.Do(refresh)
				}
			}
		}
	}()
	top := container.NewBorder(nil, nil, nil, reload, filter)
	cfg := c.Config()
	d = dialog.NewCustom("Channels on "+cfg.DisplayName(), "Close", container.NewBorder(top, status, nil, nil, list), g.win)
	g.listDlg = &listDialog{conn: c.ID(), refresh: refresh}
	d.SetOnClosed(func() { close(stop); g.listDlg = nil })
	d.Resize(fyne.NewSize(760, 560))
	d.Show()
	if existing, busy, _ := c.ChannelList(""); ask && len(existing) == 0 && !busy {
		if err := c.RequestList(""); err != nil {
			status.SetText(err.Error())
			return
		}
	}
	refresh()
}

// ---------------------------------------------------------------------------
// Notifications
// ---------------------------------------------------------------------------

func (g *gui) notifyMention(conn, buf string, l core.Line) {
	if !g.glob.Notify {
		return
	}
	if !g.inBack && conn == g.cur.conn && strings.EqualFold(buf, g.cur.buf) {
		return // you're looking at it
	}
	if time.Since(g.lastNote) < 3*time.Second {
		return
	}
	g.lastNote = time.Now()
	title := l.Nick
	if strings.HasPrefix(buf, "#") || strings.HasPrefix(buf, "&") {
		title = l.Nick + " in " + buf
	}
	text := core.StripFormatting(l.Text)
	if len(text) > 200 {
		text = text[:200] + "…"
	}
	g.app.SendNotification(fyne.NewNotification(title, text))
}

// ---------------------------------------------------------------------------
// Copy & paste
// ---------------------------------------------------------------------------

// pasteToInput pastes the clipboard into the typing box (from anywhere).
func (g *gui) pasteToInput() {
	g.win.Canvas().Focus(g.input)
	g.input.TypedShortcut(&fyne.ShortcutPaste{Clipboard: g.app.Clipboard()})
}

// copyTextDialog shows the window's text where any part can be selected
// with the mouse and copied (Ctrl+C or right-click → Copy).
func (g *gui) copyTextDialog() {
	text := g.windowText()
	e := widget.NewMultiLineEntry()
	e.SetText(text)
	e.Wrapping = fyne.TextWrapWord
	e.TextStyle = fyne.TextStyle{Monospace: true}
	hint := widget.NewLabel("Select text with the mouse, then Ctrl+C (or right-click → Copy).")
	hint.Importance = widget.LowImportance
	var d dialog.Dialog
	all := widget.NewButtonWithIcon("Copy all", theme.ContentCopyIcon(), func() {
		g.app.Clipboard().SetContent(text)
		d.Hide()
	})
	closeBtn := widget.NewButton("Close", func() { d.Hide() })
	bottom := container.NewHBox(hint, layout.NewSpacer(), all, closeBtn)
	d = dialog.NewCustomWithoutButtons("Copy text — "+g.cur.buf, container.NewBorder(nil, bottom, nil, nil, e), g.win)
	sz := g.win.Canvas().Size()
	d.Resize(fyne.NewSize(sz.Width*0.85, sz.Height*0.85))
	d.Show()
	g.win.Canvas().Focus(e)
	e.CursorRow = len(strings.Split(text, "\n"))
	e.Refresh()
}

// pasteLines: several pasted lines — send them as separate messages?
func (g *gui) pasteLines(text string) {
	var lines []string
	for _, l := range strings.Split(strings.ReplaceAll(text, "\r", ""), "\n") {
		if strings.TrimSpace(l) != "" {
			lines = append(lines, l)
		}
	}
	c := g.cl.Conn(g.cur.conn)
	buf := g.cur.buf
	oneLine := func() {
		g.input.SetText(g.input.Text + strings.Join(lines, " "))
		g.input.CursorColumn = len([]rune(g.input.Text))
		g.input.Refresh()
		g.win.Canvas().Focus(g.input)
	}
	if c == nil || buf == "*" || len(lines) < 2 {
		oneLine()
		return
	}
	msg := widget.NewLabel(fmt.Sprintf("You pasted %d lines. Send them to %s as %d separate messages?\n(They're sent at a safe speed so the server doesn't disconnect you.)", len(lines), buf, len(lines)))
	msg.Wrapping = fyne.TextWrapWord
	var d dialog.Dialog
	send := widget.NewButton(fmt.Sprintf("Send %d messages", len(lines)), func() {
		d.Hide()
		for _, l := range lines {
			if strings.HasPrefix(l, "/") {
				l = "/" + l // as text, not a command
			}
			if _, err := c.Input(buf, l); err != nil {
				g.note("error", err.Error())
				return
			}
		}
	})
	send.Importance = widget.HighImportance
	one := widget.NewButton("Put on one line", func() { d.Hide(); oneLine() })
	cancel := widget.NewButton("Cancel", func() { d.Hide() })
	d = dialog.NewCustomWithoutButtons("Paste", container.NewVBox(msg, container.NewHBox(layout.NewSpacer(), cancel, one, send)), g.win)
	d.Resize(fyne.NewSize(520, 180))
	d.Show()
	g.win.Canvas().Focus(send) // Enter or Space sends
}
