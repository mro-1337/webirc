//go:build windows

package main

import (
	"syscall"

	"fyne.io/fyne/v2/driver"
)

var (
	user32                     = syscall.NewLazyDLL("user32.dll")
	procGetWindowLongPtrW      = user32.NewProc("GetWindowLongPtrW")
	procSetWindowLongPtrW      = user32.NewProc("SetWindowLongPtrW")
	procGetWindowLongW         = user32.NewProc("GetWindowLongW")
	procSetWindowLongW         = user32.NewProc("SetWindowLongW")
	procSetLayeredWindowAttrib = user32.NewProc("SetLayeredWindowAttributes")
)

const (
	gwlExStyle  = ^uintptr(19) // GWL_EXSTYLE (-20)
	wsExLayered = 0x00080000
	lwaAlpha    = 0x2
)

// setNativeOpacity makes the whole window see-through (percent 20..100).
func setNativeOpacity(ctx any, percent int) bool {
	c, ok := ctx.(driver.WindowsWindowContext)
	if !ok || c.HWND == 0 {
		return false
	}
	get, set := procGetWindowLongPtrW, procSetWindowLongPtrW
	if get.Find() != nil { // 32-bit Windows
		get, set = procGetWindowLongW, procSetWindowLongW
	}
	style, _, _ := get.Call(c.HWND, gwlExStyle)
	if percent >= 100 {
		set.Call(c.HWND, gwlExStyle, style&^wsExLayered)
		return true
	}
	set.Call(c.HWND, gwlExStyle, style|wsExLayered)
	alpha := uintptr(percent * 255 / 100)
	r, _, _ := procSetLayeredWindowAttrib.Call(c.HWND, 0, alpha, lwaAlpha)
	return r != 0
}
