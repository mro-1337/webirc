//go:build !windows && !linux

package main

func setNativeOpacity(ctx any, percent int) bool { return false }
