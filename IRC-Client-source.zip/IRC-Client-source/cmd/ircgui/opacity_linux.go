//go:build linux

package main

/*
#cgo LDFLAGS: -lX11
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <stdlib.h>

static int set_opacity(unsigned long win, unsigned long value, int clear) {
	Display *d = XOpenDisplay(NULL);
	if (!d) return 0;
	Atom a = XInternAtom(d, "_NET_WM_WINDOW_OPACITY", False);
	if (clear) {
		XDeleteProperty(d, (Window)win, a);
	} else {
		unsigned long v = value;
		XChangeProperty(d, (Window)win, a, XA_CARDINAL, 32, PropModeReplace, (unsigned char *)&v, 1);
	}
	XFlush(d);
	XCloseDisplay(d);
	return 1;
}
*/
import "C"

import "fyne.io/fyne/v2/driver"

// setNativeOpacity asks the desktop to draw the window see-through
// (needs a desktop with a compositor, which almost all have).
func setNativeOpacity(ctx any, percent int) bool {
	c, ok := ctx.(driver.X11WindowContext)
	if !ok || c.WindowHandle == 0 {
		return false
	}
	if percent >= 100 {
		return C.set_opacity(C.ulong(c.WindowHandle), 0, 1) == 1
	}
	v := uint64(percent) * 0xffffffff / 100
	return C.set_opacity(C.ulong(c.WindowHandle), C.ulong(v), 0) == 1
}
