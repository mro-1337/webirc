package main

import (
	"fmt"
	"hash/fnv"
	"image/color"
	"math"
	"strconv"
	"strings"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/theme"
)

type palette struct {
	bg, panel, panel2, fg, muted, accent, accentText, hover, sel, event, err, hl, link string
	dark, mono                                                                         bool
	nickS, nickL                                                                       float64
}

var palettes = map[string]palette{
	"dark":            {"#0f1216", "#161a20", "#1c212a", "#e6e9ef", "#8a93a3", "#3b82f6", "#ffffff", "#222833", "#26324a", "#7d8698", "#ef4444", "#3a2f12", "#60a5fa", true, false, .65, .68},
	"light":           {"#ffffff", "#f5f6f8", "#eceef2", "#1b1f27", "#697386", "#3b82f6", "#ffffff", "#e7eaf0", "#dce6fb", "#7a8290", "#dc2626", "#fdf0d5", "#2563eb", false, false, .65, .36},
	"midnight":        {"#0b1020", "#0f1630", "#16204a", "#dbe4ff", "#8592c0", "#7c5cff", "#ffffff", "#18224d", "#24306b", "#7783b3", "#ef4444", "#2a2050", "#a5b4fc", true, false, .65, .72},
	"bbs":             {"#000000", "#00002a", "#000060", "#c0c0c0", "#55ffff", "#0000a8", "#ffff55", "#000080", "#0000a8", "#55ff55", "#ff5555", "#3a0a3a", "#ffff55", true, true, 1, .66},
	"terminal":        {"#000000", "#050d05", "#0a1a0a", "#33ff66", "#1fae45", "#33ff66", "#000000", "#0b2a0b", "#114411", "#1d9e3f", "#ff5555", "#0b3a14", "#a3ffbf", true, true, .7, .62},
	"solarized-dark":  {"#002b36", "#073642", "#0b4251", "#93a1a1", "#657b83", "#268bd2", "#ffffff", "#0a4050", "#124b5c", "#586e75", "#dc322f", "#3a3a10", "#2aa198", true, false, .6, .6},
	"solarized-light": {"#fdf6e3", "#eee8d5", "#e6dfc8", "#586e75", "#839496", "#268bd2", "#ffffff", "#e4ddc6", "#d8e4ec", "#93a1a1", "#dc322f", "#f5e6b0", "#268bd2", false, false, .6, .38},
	"classic":         {"#ffffff", "#ece9d8", "#d4d0c8", "#000000", "#555555", "#000080", "#ffffff", "#dcdcdc", "#c0c0ff", "#009300", "#ff0000", "#ffff80", "#0000ff", false, true, 1, .3},
	"high-contrast":   {"#000000", "#000000", "#111111", "#ffffff", "#dddddd", "#ffd600", "#000000", "#222222", "#333333", "#cccccc", "#ff5555", "#504000", "#66ccff", true, false, 1, .75},
	"dracula":         {"#282a36", "#21222c", "#343746", "#f8f8f2", "#8a8fb0", "#bd93f9", "#282a36", "#343746", "#44475a", "#6272a4", "#ff5555", "#4a3f1a", "#8be9fd", true, false, 0.75, 0.72},
	"nord":            {"#2e3440", "#3b4252", "#434c5e", "#eceff4", "#9aa5b8", "#88c0d0", "#2e3440", "#434c5e", "#4c566a", "#81a1c1", "#bf616a", "#4a4430", "#8fbcbb", true, false, 0.45, 0.7},
	"gruvbox-dark":    {"#282828", "#32302f", "#3c3836", "#ebdbb2", "#a89984", "#fabd2f", "#282828", "#3c3836", "#504945", "#928374", "#fb4934", "#4a3a12", "#83a598", true, false, 0.6, 0.62},
	"gruvbox-light":   {"#fbf1c7", "#f2e5bc", "#ebdbb2", "#3c3836", "#7c6f64", "#b57614", "#fbf1c7", "#ebdbb2", "#d5c4a1", "#928374", "#9d0006", "#f5d78e", "#076678", false, false, 0.6, 0.35},
	"monokai":         {"#272822", "#1e1f1c", "#3e3d32", "#f8f8f2", "#90908a", "#a6e22e", "#272822", "#3e3d32", "#49483e", "#75715e", "#f92672", "#4a4520", "#66d9ef", true, false, 0.8, 0.65},
	"ocean":           {"#0f1c2e", "#13253b", "#1a3150", "#d6e6ff", "#7f9cc0", "#22d3ee", "#0f1c2e", "#1a3150", "#21406a", "#6a8cb8", "#f87171", "#3a3315", "#7dd3fc", true, false, 0.6, 0.7},
	"amber":           {"#0d0800", "#140c00", "#221500", "#ffb000", "#b07a00", "#ffb000", "#0d0800", "#2a1a00", "#3a2400", "#c88a00", "#ff5f3f", "#3a2600", "#ffd27a", true, true, 0.9, 0.58},
	"sepia":           {"#f4ecd8", "#eadfc6", "#e0d2b4", "#4a3b2a", "#86735c", "#9c5b2e", "#ffffff", "#e3d6ba", "#d9c8a4", "#8f7c63", "#b0352b", "#f0d79b", "#7a4a1e", false, false, 0.5, 0.34},
}

var themeOrder = []string{"dark", "light", "midnight", "bbs", "terminal", "solarized-dark", "solarized-light", "classic", "high-contrast", "dracula", "nord", "gruvbox-dark", "gruvbox-light", "monokai", "ocean", "amber", "sepia"}

var themeLabels = map[string]string{
	"dark": "Dark", "light": "Light", "midnight": "Midnight", "bbs": "BBS (ANSI)", "terminal": "Green terminal",
	"solarized-dark": "Solarized dark", "solarized-light": "Solarized light", "classic": "Classic (mIRC)", "high-contrast": "High contrast",
	"dracula": "Dracula", "nord": "Nord", "gruvbox-dark": "Gruvbox dark", "gruvbox-light": "Gruvbox light", "monokai": "Monokai", "ocean": "Ocean", "amber": "Amber terminal", "sepia": "Sepia",
}

func hexColor(s string) color.NRGBA {
	s = strings.TrimPrefix(s, "#")
	v, _ := strconv.ParseUint(s, 16, 32)
	return color.NRGBA{uint8(v >> 16), uint8(v >> 8), uint8(v), 255}
}

// ircTheme implements fyne.Theme. Color names that start with "#" are used
// as literal colors, so rich text can show nick colors and mIRC colors.
type ircTheme struct {
	name string
	p    palette

	size                        float32 // text size
	mono                        bool    // use the built-in monospace font
	reg, bold, italic, boldItal fyne.Resource
}

// setFont picks the text font and size ("" / Default = built-in font).
func (t *ircTheme) setFont(name string, size int) {
	t.size = defaultSize
	if size >= 6 && size <= 72 {
		t.size = float32(size)
	}
	t.mono, t.reg, t.bold, t.italic, t.boldItal = false, nil, nil, nil, nil
	switch {
	case name == "" || strings.EqualFold(name, fontDefault):
	case strings.EqualFold(name, fontMonospace):
		t.mono = true
	default:
		if f := findFont(name); f != nil {
			t.reg = loadFontFile(f.Regular)
			t.bold = loadFontFile(f.Bold)
			t.italic = loadFontFile(f.Italic)
			t.boldItal = loadFontFile(f.BoldItalic)
		}
	}
}

func newTheme(name string) *ircTheme {
	p, ok := palettes[name]
	if !ok {
		name, p = "dark", palettes["dark"]
	}
	return &ircTheme{name: name, p: p, size: defaultSize}
}

func (t *ircTheme) variant() fyne.ThemeVariant {
	if t.p.dark {
		return theme.VariantDark
	}
	return theme.VariantLight
}

func (t *ircTheme) Color(n fyne.ThemeColorName, _ fyne.ThemeVariant) color.Color {
	if strings.HasPrefix(string(n), "#") {
		return hexColor(string(n))
	}
	p := t.p
	switch n {
	case theme.ColorNameBackground:
		return hexColor(p.bg)
	case theme.ColorNameForeground:
		return hexColor(p.fg)
	case theme.ColorNamePrimary, theme.ColorNameFocus:
		return hexColor(p.accent)
	case theme.ColorNameForegroundOnPrimary:
		return hexColor(p.accentText)
	case theme.ColorNameButton:
		return hexColor(p.panel2)
	case theme.ColorNameInputBackground:
		return hexColor(p.panel)
	case theme.ColorNameInputBorder, theme.ColorNameSeparator:
		return hexColor(p.panel2)
	case theme.ColorNameHover:
		return hexColor(p.hover)
	case theme.ColorNameSelection:
		return hexColor(p.sel)
	case theme.ColorNamePlaceHolder, theme.ColorNameDisabled:
		return hexColor(p.muted)
	case theme.ColorNameHyperlink:
		return hexColor(p.link)
	case theme.ColorNameHeaderBackground, theme.ColorNameMenuBackground, theme.ColorNameOverlayBackground:
		return hexColor(p.panel)
	case theme.ColorNameError:
		return hexColor(p.err)
	case theme.ColorNameScrollBar:
		c := hexColor(p.muted)
		c.A = 140
		return c
	}
	return theme.DefaultTheme().Color(n, t.variant())
}

func (t *ircTheme) Font(s fyne.TextStyle) fyne.Resource {
	if s.Symbol {
		return theme.DefaultTheme().Font(s)
	}
	if t.reg != nil && !s.Monospace {
		pick := t.reg
		switch {
		case s.Bold && s.Italic:
			pick = firstRes(t.boldItal, t.bold, t.italic, t.reg)
		case s.Bold:
			pick = firstRes(t.bold, t.reg)
		case s.Italic:
			pick = firstRes(t.italic, t.reg)
		}
		return pick
	}
	if t.p.mono || t.mono {
		s.Monospace = true
	}
	return theme.DefaultTheme().Font(s)
}

func firstRes(rs ...fyne.Resource) fyne.Resource {
	for _, r := range rs {
		if r != nil {
			return r
		}
	}
	return nil
}

func (t *ircTheme) Icon(n fyne.ThemeIconName) fyne.Resource { return theme.DefaultTheme().Icon(n) }
func (t *ircTheme) Size(n fyne.ThemeSizeName) float32 {
	switch n {
	case theme.SizeNameText:
		if t.size > 0 {
			return t.size
		}
		return defaultSize
	case theme.SizeNameInnerPadding:
		return 5
	case theme.SizeNameLineSpacing:
		return 3
	}
	return theme.DefaultTheme().Size(n)
}

// nickColor gives each nickname its own color (as a "#rrggbb" color name).
func (t *ircTheme) nickColor(nick string) fyne.ThemeColorName {
	h := fnv.New32a()
	h.Write([]byte(strings.ToLower(nick)))
	return fyne.ThemeColorName(hsl(float64(h.Sum32()%360), t.p.nickS, t.p.nickL))
}

func hsl(h, s, l float64) string {
	c := (1 - math.Abs(2*l-1)) * s
	x := c * (1 - math.Abs(math.Mod(h/60, 2)-1))
	m := l - c/2
	var r, g, b float64
	switch {
	case h < 60:
		r, g, b = c, x, 0
	case h < 120:
		r, g, b = x, c, 0
	case h < 180:
		r, g, b = 0, c, x
	case h < 240:
		r, g, b = 0, x, c
	case h < 300:
		r, g, b = x, 0, c
	default:
		r, g, b = c, 0, x
	}
	return fmt.Sprintf("#%02x%02x%02x", int((r+m)*255), int((g+m)*255), int((b+m)*255))
}
