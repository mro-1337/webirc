package main

// Font choices for the desktop client: the built-in fonts plus any TrueType /
// OpenType fonts installed on the computer, or put in a "fonts" folder next to
// the program (keeps it portable).

import (
	"io/fs"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"sync"

	"ircclient/core"

	"fyne.io/fyne/v2"
	"golang.org/x/image/font/sfnt"
)

const (
	fontDefault   = "Default"
	fontMonospace = "Monospace"
	defaultSize   = 14
)

type fontFamily struct {
	Name                              string
	Regular, Bold, Italic, BoldItalic string // file paths
}

var fontScan struct {
	once sync.Once
	fams []*fontFamily
	by   map[string]*fontFamily
}

func fontDirs() []string {
	dirs := []string{filepath.Join(core.ProgramDir(), "fonts")}
	home, _ := os.UserHomeDir()
	if runtime.GOOS == "windows" {
		win := os.Getenv("WINDIR")
		if win == "" {
			win = `C:\Windows`
		}
		dirs = append(dirs, filepath.Join(win, "Fonts"))
		if la := os.Getenv("LOCALAPPDATA"); la != "" {
			dirs = append(dirs, filepath.Join(la, "Microsoft", "Windows", "Fonts"))
		}
	} else {
		dirs = append(dirs, "/usr/share/fonts", "/usr/local/share/fonts")
		if home != "" {
			dirs = append(dirs, filepath.Join(home, ".local", "share", "fonts"), filepath.Join(home, ".fonts"))
		}
	}
	return dirs
}

// installedFonts lists font families found on this computer (scanned once).
func installedFonts() []*fontFamily {
	fontScan.once.Do(func() {
		fontScan.by = map[string]*fontFamily{}
		var buf sfnt.Buffer
		count := 0
		for _, dir := range fontDirs() {
			filepath.WalkDir(dir, func(p string, d fs.DirEntry, err error) error {
				if err != nil || d.IsDir() || count > 4000 {
					return nil
				}
				ext := strings.ToLower(filepath.Ext(p))
				if ext != ".ttf" && ext != ".otf" {
					return nil
				}
				count++
				f, err := os.Open(p)
				if err != nil {
					return nil
				}
				defer f.Close()
				font, err := sfnt.ParseReaderAt(f)
				if err != nil {
					return nil
				}
				fam, _ := font.Name(&buf, sfnt.NameIDTypographicFamily)
				sub, _ := font.Name(&buf, sfnt.NameIDTypographicSubfamily)
				if fam == "" {
					fam, _ = font.Name(&buf, sfnt.NameIDFamily)
					sub, _ = font.Name(&buf, sfnt.NameIDSubfamily)
				}
				fam = strings.TrimSpace(fam)
				if fam == "" {
					return nil
				}
				ff := fontScan.by[strings.ToLower(fam)]
				if ff == nil {
					ff = &fontFamily{Name: fam}
					fontScan.by[strings.ToLower(fam)] = ff
				}
				s := strings.ToLower(sub)
				bold := strings.Contains(s, "bold") && !strings.Contains(s, "semi") && !strings.Contains(s, "extra") && !strings.Contains(s, "ultra") && !strings.Contains(s, "demi")
				italic := strings.Contains(s, "italic") || strings.Contains(s, "oblique")
				switch {
				case bold && italic && ff.BoldItalic == "":
					ff.BoldItalic = p
				case bold && !italic && ff.Bold == "":
					ff.Bold = p
				case italic && !bold && (s == "italic" || s == "oblique") && ff.Italic == "":
					ff.Italic = p
				case s == "regular" || s == "book" || s == "normal" || s == "roman" || s == "":
					if ff.Regular == "" {
						ff.Regular = p
					}
				}
				return nil
			})
		}
		for _, ff := range fontScan.by {
			if ff.Regular != "" {
				fontScan.fams = append(fontScan.fams, ff)
			}
		}
		sort.Slice(fontScan.fams, func(i, j int) bool {
			return strings.ToLower(fontScan.fams[i].Name) < strings.ToLower(fontScan.fams[j].Name)
		})
	})
	return fontScan.fams
}

func findFont(name string) *fontFamily {
	installedFonts()
	return fontScan.by[strings.ToLower(strings.TrimSpace(name))]
}

// fontNames is the list shown in Settings.
func fontNames() []string {
	out := []string{fontDefault, fontMonospace}
	for _, f := range installedFonts() {
		out = append(out, f.Name)
	}
	return out
}

var fontFiles = struct {
	sync.Mutex
	m map[string]fyne.Resource
}{m: map[string]fyne.Resource{}}

func loadFontFile(p string) fyne.Resource {
	if p == "" {
		return nil
	}
	fontFiles.Lock()
	defer fontFiles.Unlock()
	if r, ok := fontFiles.m[p]; ok {
		return r
	}
	b, err := os.ReadFile(p)
	var r fyne.Resource
	if err == nil {
		r = fyne.NewStaticResource(filepath.Base(p), b)
	}
	fontFiles.m[p] = r
	return r
}
