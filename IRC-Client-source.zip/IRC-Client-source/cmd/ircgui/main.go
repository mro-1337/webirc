// Desktop IRC client (Windows and Linux) — same IRC engine as the terminal client.

//go:debug tlsrsakex=1
//go:debug tls3des=1
//go:debug rsa1024min=0
package main

import (
	_ "embed"
	"fmt"
	"image"
	"image/color"
	"net/url"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"ircclient/core"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/driver"
	"fyne.io/fyne/v2/driver/desktop"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/theme"
	"fyne.io/fyne/v2/widget"
)

//go:embed icon.png
var iconPNG []byte

const maxShown = 400 // lines kept on screen per window

type sideItem struct {
	conn, buf, label string
	kind             string
	status           string
	unread           int
	hl, joined       bool
}

type unread struct {
	n  int
	hl bool
}

type gui struct {
	cl   *core.Client
	app  fyne.App
	win  fyne.Window
	th   *ircTheme
	glob core.Settings
	imgs *core.ImageCache

	side      *widget.List
	sideItems []sideItem
	selecting bool

	title    *widget.Label
	topic    *widget.Label
	connBtn  *widget.Button
	chanBtn  *widget.Button
	dccBtn   *widget.Button
	chanDlg  *chanDialog
	srvDlg   func() // refreshes the Servers window while it's open
	listDlg  *listDialog
	inBack   bool // window is not in front (for notifications)
	lastNote time.Time
	xfers    *transfersWin
	themeBtn *widget.Button

	msgBox *fyne.Container
	scroll *container.Scroll

	nickList  *widget.List
	nicks     []string
	nickPane  *fyne.Container
	nickTitle *widget.Label
	showNicks bool

	input *inputEntry
	nickL *widget.Label

	sideBg, nickBg *canvas.Rectangle
	leftPane       fyne.CanvasObject // servers & channels pane
	rightPane      fyne.CanvasObject // people pane
	centerPane     fyne.CanvasObject
	tabRow         *fyne.Container // tab buttons (top/bottom layout)
	tabScroll      *container.Scroll
	tabBar         fyne.CanvasObject // tabs + menu buttons
	tabBg          *canvas.Rectangle
	leftBtn        *widget.Button
	leftSplit      *container.Split // left pane | rest
	rightSplit     *container.Split // chat | people
	rightShown     bool
	hasTray        bool

	mu        sync.Mutex
	cur       struct{ conn, buf string }
	unread    map[string]*unread
	rendered  int
	shown     int
	pending   map[string][]*fyne.Container // picture url -> placeholders
	anims     []*anim                      // animated GIFs on screen
	bigImgs   *core.ImageCache             // larger pictures for the viewer
	player    *core.VideoPlayer            // video playing in the chat
	curViewer *viewer
	viewAnim  *anim
	playerID  int
	probing   map[string][]*fyne.Container // link url -> placeholders
	history   []string
	histPos   int
	tab       *tabState
	dirty     chan struct{}
	newMu     sync.Mutex
	newLines  []newLine
}

type tabState struct {
	start   int
	nicks   []string
	i       int
	atStart bool
}

func key(conn, buf string) string { return conn + "\x00" + strings.ToLower(buf) }

func main() {
	a := app.NewWithID("portable.ircclient")
	icon := fyne.NewStaticResource("icon.png", iconPNG)
	a.SetIcon(icon)

	path := core.SettingsPath("irc-client.txt")
	settings, err := core.LoadSettings(path)
	g := &gui{app: a, unread: map[string]*unread{}, pending: map[string][]*fyne.Container{},
		probing: map[string][]*fyne.Container{}, histPos: -1, dirty: make(chan struct{}, 1), showNicks: true}
	a.Lifecycle().SetOnExitedForeground(func() { g.inBack = true })
	a.Lifecycle().SetOnEnteredForeground(func() { g.inBack = false })
	g.win = a.NewWindow("IRC Client")
	g.win.SetIcon(icon)
	g.win.Resize(fyne.NewSize(1180, 740))
	if err != nil {
		g.th = newTheme("dark")
		a.Settings().SetTheme(g.th)
		g.win.SetContent(container.NewPadded(widget.NewLabel("Problem with your settings file:\n\n" + err.Error() +
			"\n\nFix that line, or delete\n" + path + "\nto start fresh.")))
		g.win.ShowAndRun()
		os.Exit(1)
	}
	g.cl = core.NewClient(path, settings)
	g.glob = g.cl.Global()
	g.th = g.makeTheme(g.glob.Theme)
	g.showNicks = !g.glob.HidePeople
	a.Settings().SetTheme(g.th)
	g.imgs = core.NewImageCache(420, 280)
	g.imgs.OnReady = func(u string) { fyne.Do(func() { g.mediaReady(u) }) }
	g.cl.OnEvent = g.onEvent

	g.build()
	g.bigImgs = core.NewImageCache(1600, 1100)
	g.bigImgs.OnReady = func(u string) { fyne.Do(func() { g.viewerReady(u) }) }
	go g.refreshLoop()
	go func() {
		for range time.Tick(40 * time.Millisecond) {
			fyne.Do(g.stepAnims)
		}
	}()
	g.cl.Start()
	if conns := g.cl.Conns(); len(conns) > 0 {
		g.cur.conn, g.cur.buf = conns[0].ID(), "*"
	}
	g.rendered = -1
	g.refreshAll()
	quit := func() {
		g.saveSplits()
		g.win.Hide()
		g.cl.Shutdown("Leaving")
		a.Quit()
	}
	g.win.SetCloseIntercept(func() {
		if g.glob.TrayOnClose && g.hasTray {
			g.saveSplits()
			g.win.Hide() // still connected; click the tray icon to show it again
			return
		}
		quit()
	})
	if desk, ok := a.(desktop.App); ok { // system tray icon
		g.hasTray = true
		desk.SetSystemTrayIcon(icon)
		desk.SetSystemTrayMenu(fyne.NewMenu("IRC Client",
			fyne.NewMenuItem("Show", func() { g.win.Show(); g.win.RequestFocus() }),
			fyne.NewMenuItem("Hide", func() { g.saveSplits(); g.win.Hide() }),
			fyne.NewMenuItemSeparator(),
			fyne.NewMenuItem("Quit", quit),
		))
	}
	go func() { // window opacity needs the window to exist first
		time.Sleep(700 * time.Millisecond)
		fyne.Do(func() { g.applyOpacity(g.glob.Opacity) })
	}()
	g.win.Canvas().Focus(g.input)
	g.win.ShowAndRun()
}

// ---------------------------------------------------------------------------
// Events from the IRC engine (any goroutine)
// ---------------------------------------------------------------------------

// onEvent runs inside the IRC engine (which holds its own lock), so it
// must not take g.mu — it just queues what happened for the screen.
func (g *gui) onEvent(ev core.Event) {
	if ev.Kind == core.EvDCCOffer {
		id := ev.DCC
		fyne.Do(func() { g.showDCCOffer(id) })
	}
	if ev.Kind == core.EvBuffer && ev.Buf == "*list" {
		id := ev.Conn.ID()
		fyne.Do(func() { g.listArrived(id) })
	}
	if ev.Kind == core.EvLine && ev.Line.Highlight && ev.Line.IsChat() && !ev.Line.Self {
		id, buf, l := ev.Conn.ID(), ev.Buf, ev.Line
		fyne.Do(func() { g.notifyMention(id, buf, l) })
	}
	if ev.Kind == core.EvLine && ev.Line.IsChat() && !ev.Line.Self {
		g.newMu.Lock()
		if len(g.newLines) < 10000 {
			g.newLines = append(g.newLines, newLine{key(ev.Conn.ID(), ev.Buf), ev.Line.Highlight})
		}
		g.newMu.Unlock()
	}
	select {
	case g.dirty <- struct{}{}:
	default:
	}
}

// takeNewLines counts queued messages as unread (on the screen's side).
func (g *gui) takeNewLines() {
	g.newMu.Lock()
	list := g.newLines
	g.newLines = nil
	g.newMu.Unlock()
	if len(list) == 0 {
		return
	}
	g.mu.Lock()
	cur := key(g.cur.conn, g.cur.buf)
	for _, nl := range list {
		if nl.k == cur {
			continue
		}
		un := g.unread[nl.k]
		if un == nil {
			un = &unread{}
			g.unread[nl.k] = un
		}
		un.n++
		un.hl = un.hl || nl.hl
	}
	g.mu.Unlock()
}

func (g *gui) refreshLoop() {
	for range g.dirty {
		time.Sleep(50 * time.Millisecond)
		fyne.DoAndWait(g.refreshAll)
	}
}

// ---------------------------------------------------------------------------
// Layout
// ---------------------------------------------------------------------------

func (g *gui) build() {
	// Left: servers and channels
	g.side = widget.NewList(
		func() int { return len(g.sideItems) },
		func() fyne.CanvasObject {
			name := widget.NewLabel("")
			name.Truncation = fyne.TextTruncateEllipsis
			badge := widget.NewLabel("")
			dot := canvas.NewCircle(color.Transparent)
			dotBox := container.NewGridWrap(fyne.NewSize(10, 10), dot)
			return container.NewBorder(nil, nil, container.NewCenter(dotBox), badge, name)
		},
		func(i widget.ListItemID, o fyne.CanvasObject) {
			if i >= len(g.sideItems) {
				return
			}
			it := g.sideItems[i]
			c := o.(*fyne.Container)
			name := c.Objects[0].(*widget.Label)
			dot := c.Objects[1].(*fyne.Container).Objects[0].(*fyne.Container).Objects[0].(*canvas.Circle)
			badge := c.Objects[2].(*widget.Label)
			name.SetText(it.label)
			name.TextStyle = fyne.TextStyle{Bold: it.kind == "server" || it.unread > 0, Italic: it.kind == "channel" && !it.joined}
			name.Importance = widget.MediumImportance
			if it.kind == "channel" && !it.joined {
				name.Importance = widget.LowImportance
			}
			name.Refresh()
			dot.FillColor = color.Transparent
			if it.kind == "server" {
				dot.FillColor = map[string]color.Color{"connected": hexColor("#22c55e"), "waiting": hexColor("#ef4444"),
					"disconnected": hexColor(g.th.p.muted)}[it.status]
				if dot.FillColor == nil {
					dot.FillColor = hexColor("#f59e0b")
				}
			}
			dot.Refresh()
			badge.SetText("")
			if it.unread > 0 {
				badge.SetText(strconv.Itoa(it.unread))
				badge.Importance = widget.HighImportance
				if it.hl {
					badge.Importance = widget.DangerImportance
				}
				badge.TextStyle = fyne.TextStyle{Bold: true}
				badge.Refresh()
			}
		})
	g.side.OnSelected = func(i widget.ListItemID) {
		if g.selecting || i >= len(g.sideItems) {
			return
		}
		it := g.sideItems[i]
		g.switchTo(it.conn, it.buf)
	}
	addBtn := widget.NewButtonWithIcon("Servers", theme.StorageIcon(), g.serversDialog)
	settingsBtn := widget.NewButtonWithIcon("Settings", theme.SettingsIcon(), g.settingsDialog)
	helpBtn := widget.NewButtonWithIcon("", theme.HelpIcon(), g.showHelp)
	sideTop := widget.NewLabelWithStyle("  # IRC Client", fyne.TextAlignLeading, fyne.TextStyle{Bold: true})
	sideBottom := container.NewVBox(addBtn, container.NewBorder(nil, nil, nil, helpBtn, settingsBtn))
	sideSize := canvas.NewRectangle(color.Transparent)
	sideSize.SetMinSize(fyne.NewSize(150, 0))
	sidePanel := container.NewStack(sideSize, container.NewBorder(sideTop, container.NewPadded(sideBottom), nil, nil, g.side))

	// Top bar
	g.title = widget.NewLabelWithStyle("", fyne.TextAlignLeading, fyne.TextStyle{Bold: true})
	g.topic = widget.NewLabel("")
	g.topic.Truncation = fyne.TextTruncateEllipsis
	g.topic.Importance = widget.LowImportance
	g.connBtn = widget.NewButton("Connect", g.toggleConnect)
	serverBtn := widget.NewButtonWithIcon("Server", theme.SettingsIcon(), func() {
		if c := g.cl.Conn(g.cur.conn); c != nil {
			g.serverDialog(c)
		} else {
			g.serversDialog()
		}
	})
	g.themeBtn = widget.NewButton("", g.toggleLightDark)
	nickBtn := widget.NewButtonWithIcon("", theme.AccountIcon(), func() {
		g.showNicks = !g.showNicks
		g.cl.SetGlobal(func(st *core.Settings) { st.HidePeople = !g.showNicks })
		g.glob = g.cl.Global()
		g.refreshNicks()
	})
	g.leftBtn = widget.NewButtonWithIcon("", theme.MenuIcon(), func() {
		g.saveSplits()
		g.cl.SetGlobal(func(st *core.Settings) { st.HideLeft = !st.HideLeft })
		g.glob = g.cl.Global()
		g.relayout()
	})
	g.chanBtn = widget.NewButtonWithIcon("Channel", theme.ListIcon(), func() {
		if g.cur.buf == "*" {
			if c := g.cl.Conn(g.cur.conn); c != nil {
				g.channelListDialog(c, true)
			}
			return
		}
		g.chanSettingsDialog()
	})
	g.dccBtn = widget.NewButtonWithIcon("", theme.DownloadIcon(), g.transfersDialog)
	topBar := container.NewBorder(nil, nil, g.leftBtn,
		container.NewHBox(g.connBtn, g.chanBtn, serverBtn, g.dccBtn, g.themeBtn, nickBtn),
		container.NewVBox(g.title, g.topic))

	// Messages
	g.msgBox = container.New(&tightVBox{})
	g.scroll = container.NewVScroll(g.msgBox)

	// Input
	g.input = newInputEntry(g)
	g.input.SetPlaceHolder("Type a message, or /help")
	g.input.OnSubmitted = func(string) { g.submit() }
	g.nickL = widget.NewLabelWithStyle("", fyne.TextAlignLeading, fyne.TextStyle{Bold: true})
	sendBtn := widget.NewButtonWithIcon("Send", theme.MailSendIcon(), g.submit)
	sendBtn.Importance = widget.HighImportance
	inputBar := container.NewBorder(nil, nil, g.nickL, sendBtn, g.input)

	center := container.NewBorder(container.NewVBox(container.NewPadded(topBar), widget.NewSeparator()), container.NewPadded(inputBar), nil, nil, g.scroll)

	// Right: people in the channel
	g.nickTitle = widget.NewLabelWithStyle("", fyne.TextAlignLeading, fyne.TextStyle{Bold: true})
	g.nickList = widget.NewList(
		func() int { return len(g.nicks) },
		func() fyne.CanvasObject { return newNickItem(g) },
		func(i widget.ListItemID, o fyne.CanvasObject) {
			if i >= len(g.nicks) {
				return
			}
			n := g.nicks[i]
			pfx, name := "", n
			if strings.ContainsAny(n[:1], "~&@%+!") {
				pfx, name = n[:1], n[1:]
			}
			ni := o.(*nickItem)
			ni.nick = name
			rt := ni.rt
			rt.Segments = []widget.RichTextSegment{
				&widget.TextSegment{Text: pfx + " ", Style: widget.RichTextStyle{Inline: true, ColorName: fyne.ThemeColorName(g.th.p.muted), TextStyle: fyne.TextStyle{Monospace: true}}},
				&widget.TextSegment{Text: name, Style: widget.RichTextStyle{Inline: true, ColorName: g.th.nickColor(name), TextStyle: fyne.TextStyle{Bold: pfx != ""}}},
			}
			rt.Refresh()
		})
	g.nickList.OnSelected = func(i widget.ListItemID) { g.nickList.UnselectAll() } // clicking a name opens its menu
	nickSize := canvas.NewRectangle(color.Transparent)
	nickSize.SetMinSize(fyne.NewSize(110, 0))
	g.nickPane = container.NewStack(nickSize, container.NewBorder(container.NewPadded(g.nickTitle), nil, nil, nil, g.nickList))

	sideBg := canvas.NewRectangle(color.Transparent)
	nickBg := canvas.NewRectangle(color.Transparent)
	g.sideBg, g.nickBg = sideBg, nickBg
	g.leftPane = container.NewStack(sideBg, sidePanel)
	g.rightPane = container.NewStack(nickBg, g.nickPane)
	g.centerPane = center

	// Tab bar (used when "Channel list" is set to top or bottom tabs)
	g.tabRow = container.NewHBox()
	g.tabScroll = container.NewHScroll(g.tabRow)
	tabAdd := widget.NewButtonWithIcon("", theme.StorageIcon(), g.serversDialog)
	tabSettings := widget.NewButtonWithIcon("", theme.SettingsIcon(), g.settingsDialog)
	tabHelp := widget.NewButtonWithIcon("", theme.HelpIcon(), g.showHelp)
	tabBg := canvas.NewRectangle(color.Transparent)
	g.tabBg = tabBg
	g.tabBar = container.NewStack(tabBg, container.NewBorder(nil, nil, nil, container.NewHBox(tabAdd, tabSettings, tabHelp), g.tabScroll))
	g.relayout()
	g.applyThemeColors()

	g.win.Canvas().AddShortcut(&desktop.CustomShortcut{KeyName: fyne.KeyTab, Modifier: fyne.KeyModifierControl}, func(fyne.Shortcut) { g.moveWindow(1) })
	for k, d := range map[fyne.KeyName]int{fyne.KeyLeft: -1, fyne.KeyUp: -1, fyne.KeyRight: 1, fyne.KeyDown: 1} {
		delta := d
		g.win.Canvas().AddShortcut(&desktop.CustomShortcut{KeyName: k, Modifier: fyne.KeyModifierAlt}, func(fyne.Shortcut) { g.moveWindow(delta) })
	}
	for k, d := range map[fyne.KeyName]int{fyne.KeyEqual: 1, fyne.KeyMinus: -1, fyne.Key0: 0} {
		delta := d
		g.win.Canvas().AddShortcut(&desktop.CustomShortcut{KeyName: k, Modifier: fyne.KeyModifierControl}, func(fyne.Shortcut) { g.changeSize(delta) })
		g.win.Canvas().AddShortcut(&desktop.CustomShortcut{KeyName: k, Modifier: fyne.KeyModifierControl | fyne.KeyModifierShift}, func(fyne.Shortcut) { g.changeSize(delta) })
	}
	g.win.Canvas().AddShortcut(&desktop.CustomShortcut{KeyName: fyne.KeyTab, Modifier: fyne.KeyModifierControl | fyne.KeyModifierShift}, func(fyne.Shortcut) { g.moveWindow(-1) })
	// Copy & paste when the typing box doesn't have the focus
	g.win.Canvas().AddShortcut(&fyne.ShortcutPaste{}, func(fyne.Shortcut) { g.pasteToInput() })
	g.win.Canvas().AddShortcut(&fyne.ShortcutCopy{}, func(fyne.Shortcut) { g.copyTextDialog() })
	g.win.Canvas().AddShortcut(&desktop.CustomShortcut{KeyName: fyne.KeyC, Modifier: fyne.KeyModifierControl | fyne.KeyModifierShift}, func(fyne.Shortcut) { g.copyTextDialog() })
	g.win.Canvas().SetOnTypedKey(func(k *fyne.KeyEvent) {
		g.win.Canvas().Focus(g.input)
		g.input.TypedKey(k)
	})
}

// extra fields used for theme switching
func (g *gui) applyThemeColors() {
	if g.tabBg != nil {
		g.tabBg.FillColor = hexColor(g.th.p.panel)
		g.tabBg.Refresh()
	}
	if g.sideBg != nil {
		g.sideBg.FillColor = hexColor(g.th.p.panel)
		g.sideBg.Refresh()
		g.nickBg.FillColor = hexColor(g.th.p.panel)
		g.nickBg.Refresh()
	}
	if g.th.p.dark {
		g.themeBtn.SetText("Light mode")
	} else {
		g.themeBtn.SetText("Dark mode")
	}
}

// ---------------------------------------------------------------------------
// Refreshing
// ---------------------------------------------------------------------------

func (g *gui) refreshAll() {
	g.takeNewLines()
	g.refreshSide()
	g.refreshHeader()
	g.refreshMessages()
	g.refreshNicks()
	g.refreshTransfers()
	if g.srvDlg != nil {
		g.srvDlg()
	}
	if g.chanDlg != nil {
		g.chanDlg.refresh()
	}
}

func (g *gui) refreshSide() {
	g.mu.Lock()
	items := []sideItem{}
	sel := -1
	total, hl := 0, false
	for _, c := range g.cl.Conns() {
		info := c.Info()
		for _, b := range c.Buffers() {
			it := sideItem{conn: info.ID, buf: b.Name, kind: b.Kind, status: info.Status, joined: b.Joined}
			switch b.Kind {
			case "server":
				it.label = info.Name
			case "channel":
				it.label = "   " + b.Name
			case "dcc":
				it.label = "   " + b.Name + " (direct)"
			default:
				it.label = "   @" + b.Name
			}
			if un := g.unread[key(info.ID, b.Name)]; un != nil {
				it.unread, it.hl = un.n, un.hl
				total += un.n
				hl = hl || un.hl
			}
			if info.ID == g.cur.conn && strings.EqualFold(b.Name, g.cur.buf) {
				sel = len(items)
			}
			items = append(items, it)
		}
	}
	g.sideItems = items
	g.mu.Unlock()
	g.side.Refresh()
	g.refreshTabs(sel)
	if sel >= 0 {
		g.selecting = true
		g.side.Select(sel)
		g.selecting = false
	}
	title := "IRC Client"
	if g.cur.buf != "" && g.cur.buf != "*" {
		title = g.cur.buf + " — IRC Client"
	}
	if total > 0 {
		mark := ""
		if hl {
			mark = "!"
		}
		title = fmt.Sprintf("(%s%d) %s", mark, total, title)
	}
	g.win.SetTitle(title)
}

func (g *gui) refreshHeader() {
	c := g.cl.Conn(g.cur.conn)
	if c == nil {
		g.title.SetText("No servers yet")
		g.topic.SetText("Click \"Add server\" to get started.")
		g.connBtn.Hide()
		g.nickL.SetText("")
		return
	}
	g.connBtn.Show()
	switch {
	case c.IsChannel(g.cur.buf):
		g.chanBtn.SetText("Channel")
		g.chanBtn.Show()
	case g.cur.buf == "*":
		g.chanBtn.SetText("Channel list")
		g.chanBtn.Show()
	default:
		g.chanBtn.Hide()
	}
	info := c.Info()
	if info.Status == "disconnected" {
		g.connBtn.SetText("Connect")
		g.connBtn.Importance = widget.HighImportance
	} else {
		g.connBtn.SetText("Disconnect")
		g.connBtn.Importance = widget.MediumImportance
	}
	g.connBtn.Refresh()
	g.nickL.SetText(info.Nick)
	if g.cur.buf == "*" {
		sc := c.Config()
		enc := "not encrypted"
		if sc.TLS {
			enc = "encrypted"
		}
		g.title.SetText(info.Name)
		t := fmt.Sprintf("%s:%d · %s · %s", sc.Host, sc.Port, enc, statusWord(info.Status))
		if info.Error != "" && info.Status != "connected" {
			t += " · " + info.Error
		}
		g.topic.SetText(t)
		return
	}
	b, _ := c.Buffer(g.cur.buf)
	title := b.Name
	if b.Kind == "channel" && !b.Joined {
		title += "  (not joined)"
	}
	g.title.SetText(title)
	g.topic.SetText(core.StripFormatting(b.Topic))
}

func statusWord(s string) string {
	return map[string]string{"connected": "connected", "connecting": "connecting…", "registering": "logging in…",
		"waiting": "reconnecting…", "disconnected": "disconnected"}[s]
}

func (g *gui) refreshNicks() {
	c := g.cl.Conn(g.cur.conn)
	show := false
	if c != nil {
		if b, ok := c.Buffer(g.cur.buf); ok && b.Kind == "channel" && g.showNicks {
			show = true
			g.nicks = c.Users(g.cur.buf)
		}
	}
	if show != g.rightShown {
		g.saveSplits()
		g.rightShown = show
		g.relayout()
	}
	if !show {
		g.nicks = nil
		return
	}
	n := len(g.nicks)
	if n == 1 {
		g.nickTitle.SetText("1 person")
	} else {
		g.nickTitle.SetText(fmt.Sprintf("%d people", n))
	}
	g.nickList.Refresh()
}

func (g *gui) atBottom() bool {
	return g.scroll.Offset.Y >= g.msgBox.MinSize().Height-g.scroll.Size().Height-40
}

func (g *gui) refreshMessages() {
	c := g.cl.Conn(g.cur.conn)
	if c == nil {
		g.msgBox.Objects = nil
		g.msgBox.Refresh()
		return
	}
	lines := c.Lines(g.cur.buf)
	start := g.rendered
	full := start < 0 || start > len(lines)
	if full {
		g.msgBox.Objects = nil
		g.mu.Lock()
		g.pending = map[string][]*fyne.Container{}
		g.anims = nil
		g.stopVideo()
		g.probing = map[string][]*fyne.Container{}
		g.mu.Unlock()
		start = 0
		if len(lines) > maxShown {
			start = len(lines) - maxShown
		}
	}
	if start == len(lines) && !full {
		return
	}
	was := full || g.atBottom()
	for _, l := range lines[start:] {
		if obj := g.lineObject(l); obj != nil {
			g.msgBox.Objects = append(g.msgBox.Objects, obj)
		}
	}
	if extra := len(g.msgBox.Objects) - maxShown; extra > 0 {
		g.msgBox.Objects = g.msgBox.Objects[extra:]
	}
	g.rendered = len(lines)
	g.msgBox.Refresh()
	if was {
		g.stickBottom()
	}
}

// stickBottom scrolls to the newest line once the layout has caught up.
func (g *gui) stickBottom() {
	g.scroll.Refresh()
	g.scroll.ScrollToBottom()
	go func() {
		time.Sleep(60 * time.Millisecond)
		fyne.Do(func() { g.scroll.Refresh(); g.scroll.ScrollToBottom() })
	}()
}

// tightVBox stacks chat lines with only a small gap between them.
type tightVBox struct{}

func (tightVBox) MinSize(objs []fyne.CanvasObject) fyne.Size {
	w, h := float32(0), float32(0)
	for _, o := range objs {
		if !o.Visible() {
			continue
		}
		ms := o.MinSize()
		if ms.Width > w {
			w = ms.Width
		}
		h += ms.Height + 1
	}
	return fyne.NewSize(w, h)
}

func (tightVBox) Layout(objs []fyne.CanvasObject, size fyne.Size) {
	y := float32(0)
	for _, o := range objs {
		if !o.Visible() {
			continue
		}
		o.Resize(fyne.NewSize(size.Width, o.MinSize().Height))
		h := o.MinSize().Height // height can change once the width is known (text wrapping)
		o.Resize(fyne.NewSize(size.Width, h))
		o.Move(fyne.NewPos(0, y))
		y += h + 1
	}
}

// ---------------------------------------------------------------------------
// One chat line
// ---------------------------------------------------------------------------

func seg(text string, colorName fyne.ThemeColorName, st fyne.TextStyle) *widget.TextSegment {
	return &widget.TextSegment{Text: text, Style: widget.RichTextStyle{Inline: true, ColorName: colorName, TextStyle: st}}
}

func (g *gui) lineObject(l core.Line) fyne.CanvasObject {
	if !g.glob.ShowJoins && (l.Kind == "join" || l.Kind == "part" || l.Kind == "quit") && !l.Self {
		return nil
	}
	p := g.th.p
	muted := fyne.ThemeColorName(p.muted)
	segs := []widget.RichTextSegment{seg(l.Time.Format("15:04")+"   ", muted, fyne.TextStyle{Monospace: true})}
	switch l.Kind {
	case "msg":
		segs = append(segs, seg(l.Nick+"  ", g.th.nickColor(l.Nick), fyne.TextStyle{Bold: true}))
		segs = append(segs, g.formatted(l.Text, "", fyne.TextStyle{})...)
	case "action":
		segs = append(segs, seg("* "+l.Nick+" ", g.th.nickColor(l.Nick), fyne.TextStyle{Bold: true, Italic: true}))
		segs = append(segs, g.formatted(l.Text, "", fyne.TextStyle{Italic: true})...)
	case "notice":
		segs = append(segs, seg("-"+l.Nick+"-  ", g.th.nickColor(l.Nick), fyne.TextStyle{Bold: true}))
		segs = append(segs, g.formatted(l.Text, muted, fyne.TextStyle{})...)
	case "error":
		segs = append(segs, seg("!  "+l.Text, fyne.ThemeColorName(p.err), fyne.TextStyle{}))
	default:
		sym := map[string]string{"join": "»", "part": "«", "quit": "«", "kick": "×", "nick": "~", "topic": "¶", "mode": "*", "info": "•"}[l.Kind]
		segs = append(segs, seg(sym+"  ", fyne.ThemeColorName(p.event), fyne.TextStyle{}))
		segs = append(segs, g.formatted(l.Text, fyne.ThemeColorName(p.event), fyne.TextStyle{})...)
	}
	rt := widget.NewRichText(segs...)
	rt.Wrapping = fyne.TextWrapWord
	var obj fyne.CanvasObject = rt
	if l.IsChat() && g.glob.ShowMedia {
		if media := g.mediaFor(l.Text); media != nil {
			obj = container.NewVBox(rt, container.NewBorder(nil, nil, spacer(64), nil, media))
		}
	}
	if l.Highlight {
		bg := canvas.NewRectangle(hexColor(p.hl))
		bar := canvas.NewRectangle(hexColor("#f59e0b"))
		bar.SetMinSize(fyne.NewSize(3, 0))
		obj = container.NewStack(bg, container.NewBorder(nil, nil, bar, nil, obj))
	}
	return newLineWrap(g, obj, l)
}

func spacer(w float32) fyne.CanvasObject {
	r := canvas.NewRectangle(color.Transparent)
	r.SetMinSize(fyne.NewSize(w, 1))
	return r
}

// formatted turns IRC formatting codes into rich-text pieces with clickable links.
func (g *gui) formatted(text string, base fyne.ThemeColorName, baseStyle fyne.TextStyle) []widget.RichTextSegment {
	var out []widget.RichTextSegment
	for _, sp := range core.ParseFormatting(text) {
		col := base
		if sp.FG >= 0 {
			col = fyne.ThemeColorName(fmt.Sprintf("#%06x", core.MIRCColors[sp.FG]))
		}
		st := baseStyle
		st.Bold = st.Bold || sp.Bold
		st.Italic = st.Italic || sp.Italic
		st.Monospace = st.Monospace || sp.Mono
		st.Underline = sp.Underline
		for _, piece := range core.SplitLinks(sp.Text) {
			if piece.URL != "" {
				if u, err := url.Parse(piece.URL); err == nil {
					link := piece.URL
					out = append(out, &widget.HyperlinkSegment{Text: piece.Text, URL: u, OnTapped: func() { core.OpenURL(link) }})
					continue
				}
			}
			out = append(out, seg(piece.Text, col, st))
		}
	}
	return out
}

// ---------------------------------------------------------------------------
// Pictures and videos
// ---------------------------------------------------------------------------

func (g *gui) mediaFor(text string) fyne.CanvasObject {
	urls := core.FindURLs(core.StripFormatting(text))
	if len(urls) == 0 {
		return nil
	}
	row := container.NewHBox()
	for i, u := range urls {
		if i >= 4 {
			break
		}
		if obj := g.mediaObject(u); obj != nil {
			row.Add(obj)
		}
	}
	if len(row.Objects) == 0 {
		return nil
	}
	return row
}

func (g *gui) mediaObject(link string) fyne.CanvasObject {
	kind := core.LinkKind(link)
	if kind == "" {
		k, done := g.imgs.Probe(link)
		if !done {
			box := container.NewStack()
			g.mu.Lock()
			g.probing[link] = append(g.probing[link], box)
			g.mu.Unlock()
			return box
		}
		kind = k
	}
	switch kind {
	case "image", "youtube":
		thumb := core.ThumbnailURL(link)
		if thumb == "" {
			thumb = link
		}
		box := container.NewStack()
		g.fillPicture(box, link, thumb, kind == "youtube")
		return box
	case "video":
		box := container.NewStack()
		g.fillVideo(box, link)
		return box
	case "audio":
		return widget.NewButtonWithIcon("Play audio", theme.MediaPlayIcon(), func() { core.OpenURL(link) })
	}
	return nil
}

// ---- animated GIFs ----

type anim struct {
	img    *canvas.Image
	frames []image.Image
	delays []time.Duration
	i      int
	next   time.Time
}

func (g *gui) addAnim(img *canvas.Image, ci *core.CachedImage) {
	if len(ci.Frames) < 2 {
		return
	}
	if len(g.anims) >= 40 { // keep the oldest from using CPU forever
		g.anims = g.anims[1:]
	}
	g.anims = append(g.anims, &anim{img: img, frames: ci.Frames, delays: ci.Delays, next: time.Now().Add(ci.Delays[0])})
}

func (g *gui) stepAnims() {
	now := time.Now()
	all := g.anims
	if g.viewAnim != nil {
		all = append(append([]*anim(nil), all...), g.viewAnim)
	}
	for _, a := range all {
		if now.Before(a.next) {
			continue
		}
		a.i = (a.i + 1) % len(a.frames)
		a.img.Image = a.frames[a.i]
		a.img.Refresh()
		a.next = now.Add(a.delays[a.i])
	}
}

// ---- videos ----

func (g *gui) fillVideo(box *fyne.Container, link string) {
	if !core.HaveFFmpeg() {
		b := widget.NewButtonWithIcon("Play video", theme.MediaPlayIcon(), func() { core.OpenURL(link) })
		hint := widget.NewLabel("(put ffmpeg next to the program to preview videos here)")
		hint.Importance = widget.LowImportance
		box.Objects = []fyne.CanvasObject{container.NewHBox(b, hint)}
		box.Refresh()
		return
	}
	k := core.VideoKey(link)
	ci := g.imgs.GetVideoFrame(link)
	switch ci.State {
	case core.ImgLoading:
		lbl := widget.NewLabelWithStyle("Loading video preview…", fyne.TextAlignLeading, fyne.TextStyle{Italic: true})
		lbl.Importance = widget.LowImportance
		box.Objects = []fyne.CanvasObject{lbl}
		g.mu.Lock()
		g.pending[k] = append(g.pending[k], box)
		g.mu.Unlock()
	case core.ImgReady:
		b := ci.Img.Bounds()
		img := canvas.NewImageFromImage(ci.Img)
		img.FillMode = canvas.ImageFillContain
		img.SetMinSize(fyne.NewSize(float32(b.Dx()), float32(b.Dy())))
		box.Objects = []fyne.CanvasObject{img, playBadge("Play"),
			newClickArea(func() { g.startVideo(box, link, b.Dx(), b.Dy()) })}
	case core.ImgFailed:
		b := widget.NewButtonWithIcon("Play video", theme.MediaPlayIcon(), func() { core.OpenURL(link) })
		box.Objects = []fyne.CanvasObject{b}
	}
	box.Refresh()
}

func playBadge(text string) fyne.CanvasObject {
	t := canvas.NewText(text+"  ", color.White)
	t.TextStyle = fyne.TextStyle{Bold: true}
	bg := canvas.NewRectangle(color.NRGBA{0, 0, 0, 170})
	bg.CornerRadius = 10
	icon := canvas.NewImageFromResource(theme.NewColoredResource(theme.MediaPlayIcon(), "#ffffff"))
	icon.SetMinSize(fyne.NewSize(26, 26))
	return container.NewCenter(container.NewStack(bg, container.NewPadded(container.NewHBox(icon, t))))
}

func (g *gui) stopVideo() {
	if g.player != nil {
		g.player.Stop()
		g.player = nil
	}
}

// startVideo plays a video inside the chat (pictures only; "Open with sound"
// opens it in your normal player).
func (g *gui) startVideo(box *fyne.Container, link string, w, h int) {
	g.stopVideo()
	g.playerID++
	id := g.playerID
	screen := canvas.NewImageFromImage(image.NewRGBA(image.Rect(0, 0, w, h)))
	screen.FillMode = canvas.ImageFillContain
	screen.SetMinSize(fyne.NewSize(float32(w), float32(h)))
	status := widget.NewLabel("Starting…")
	status.Importance = widget.LowImportance
	stop := widget.NewButtonWithIcon("Stop", theme.MediaStopIcon(), func() {
		if id == g.playerID {
			g.stopVideo()
		}
	})
	sound := widget.NewButtonWithIcon("Open with sound", theme.VolumeUpIcon(), func() {
		if id == g.playerID {
			g.stopVideo()
		}
		core.OpenURL(link)
	})
	was := g.atBottom()
	box.Objects = []fyne.CanvasObject{container.NewVBox(screen, container.NewHBox(stop, sound, status))}
	box.Refresh()
	g.msgBox.Refresh()
	if was {
		g.stickBottom()
	}

	var mu sync.Mutex
	var latest *image.RGBA
	scheduled := false
	p, err := core.PlayVideo(link, w, h, func(f *image.RGBA) {
		mu.Lock()
		latest = f
		if scheduled {
			mu.Unlock()
			return // the screen hasn't caught up yet; show the newest frame only
		}
		scheduled = true
		mu.Unlock()
		fyne.Do(func() {
			mu.Lock()
			f := latest
			scheduled = false
			mu.Unlock()
			if id != g.playerID {
				return
			}
			if status.Text != "Playing (no sound)" {
				status.SetText("Playing (no sound)")
			}
			screen.Image = f
			screen.Refresh()
		})
	}, func(err error) {
		fyne.Do(func() {
			if id == g.playerID {
				g.player = nil
			}
			g.fillVideo(box, link) // back to the preview picture
			if err != nil {
				g.note("error", "Video: "+err.Error())
			}
		})
	})
	if err != nil {
		g.note("error", "Video: "+err.Error())
		g.fillVideo(box, link)
		return
	}
	g.player = p
}

// ---- picture viewer (bigger, inside the program) ----

type viewer struct {
	link, key string
	box       *fyne.Container
	d         dialog.Dialog
}

func (g *gui) openViewer(link, picURL string) {
	box := container.NewStack()
	open := widget.NewButtonWithIcon("Open in browser", theme.ComputerIcon(), func() { core.OpenURL(link) })
	var d dialog.Dialog
	closeBtn := widget.NewButtonWithIcon("Close", theme.CancelIcon(), func() { d.Hide() })
	content := container.NewBorder(nil, container.NewHBox(layout.NewSpacer(), open, closeBtn), nil, nil, container.NewCenter(box))
	d = dialog.NewCustomWithoutButtons(shortURL(link), content, g.win)
	sz := g.win.Canvas().Size()
	d.Resize(fyne.NewSize(sz.Width*0.9, sz.Height*0.9))
	g.curViewer = &viewer{link: link, key: picURL, box: box, d: d}
	g.fillViewer()
	d.SetOnClosed(func() { g.curViewer = nil; g.viewAnim = nil })
	d.Show()
}

func shortURL(u string) string {
	if len(u) > 70 {
		return u[:67] + "…"
	}
	return u
}

func (g *gui) fillViewer() {
	v := g.curViewer
	if v == nil {
		return
	}
	ci := g.bigImgs.Get(v.key)
	switch ci.State {
	case core.ImgLoading:
		v.box.Objects = []fyne.CanvasObject{widget.NewLabel("Loading full picture…")}
	case core.ImgFailed:
		v.box.Objects = []fyne.CanvasObject{widget.NewLabel("Couldn't load the picture. Use \"Open in browser\".")}
	case core.ImgReady:
		img := canvas.NewImageFromImage(ci.Img)
		img.FillMode = canvas.ImageFillContain
		img.ScaleMode = canvas.ImageScaleSmooth
		sz := g.win.Canvas().Size()
		b := ci.Img.Bounds()
		w, h := float32(b.Dx()), float32(b.Dy())
		maxW, maxH := sz.Width*0.85, sz.Height*0.75
		if w > maxW {
			h, w = h*maxW/w, maxW
		}
		if h > maxH {
			w, h = w*maxH/h, maxH
		}
		img.SetMinSize(fyne.NewSize(w, h))
		v.box.Objects = []fyne.CanvasObject{img}
		g.viewAnim = nil
		if len(ci.Frames) > 1 {
			g.viewAnim = &anim{img: img, frames: ci.Frames, delays: ci.Delays, next: time.Now().Add(ci.Delays[0])}
		}
	}
	v.box.Refresh()
}

func (g *gui) viewerReady(u string) {
	if g.curViewer != nil && g.curViewer.key == u {
		g.fillViewer()
	}
}

func (g *gui) fillPicture(box *fyne.Container, link, thumb string, youtube bool) {
	ci := g.imgs.Get(thumb)
	switch ci.State {
	case core.ImgLoading:
		lbl := widget.NewLabelWithStyle("Loading picture…", fyne.TextAlignLeading, fyne.TextStyle{Italic: true})
		lbl.Importance = widget.LowImportance
		box.Objects = []fyne.CanvasObject{lbl}
		box.Refresh()
		g.mu.Lock()
		g.pending[thumb] = append(g.pending[thumb], box)
		g.mu.Unlock()
		g.pendingLinks(thumb, link, youtube)
	case core.ImgReady:
		b := ci.Img.Bounds()
		img := canvas.NewImageFromImage(ci.Img)
		img.FillMode = canvas.ImageFillContain
		img.ScaleMode = canvas.ImageScaleSmooth
		img.SetMinSize(fyne.NewSize(float32(b.Dx()), float32(b.Dy())))
		objs := []fyne.CanvasObject{img}
		g.addAnim(img, ci)
		if youtube {
			play := canvas.NewText("YouTube  ", color.White)
			play.TextStyle = fyne.TextStyle{Bold: true}
			playBg := canvas.NewRectangle(hexColor("#e62117"))
			playBg.CornerRadius = 8
			icon := canvas.NewImageFromResource(theme.NewColoredResource(theme.MediaPlayIcon(), "#ffffff"))
			icon.SetMinSize(fyne.NewSize(22, 22))
			objs = append(objs, container.NewCenter(container.NewStack(playBg, container.NewPadded(container.NewHBox(icon, play)))))
		}
		if youtube {
			objs = append(objs, newClickArea(func() { core.OpenURL(link) }))
		} else {
			objs = append(objs, newClickArea(func() { g.openViewer(link, thumb) }))
		}
		box.Objects = objs
		box.Refresh()
	case core.ImgFailed:
		box.Objects = nil
		box.Refresh()
	}
}

// remember which page link belongs to a picture, so a click opens the page.
var linkFor = struct {
	sync.Mutex
	m map[string]struct {
		link string
		yt   bool
	}
}{m: map[string]struct {
	link string
	yt   bool
}{}}

func (g *gui) pendingLinks(thumb, link string, yt bool) {
	linkFor.Lock()
	linkFor.m[thumb] = struct {
		link string
		yt   bool
	}{link, yt}
	linkFor.Unlock()
}

// mediaReady runs on the UI thread when a picture finished downloading
// (or a link check finished).
func (g *gui) mediaReady(u string) {
	was := g.atBottom()
	g.mu.Lock()
	boxes := g.pending[u]
	delete(g.pending, u)
	probes := g.probing[u]
	delete(g.probing, u)
	g.mu.Unlock()
	linkFor.Lock()
	info := linkFor.m[u]
	linkFor.Unlock()
	for _, box := range boxes {
		if strings.HasPrefix(u, "video:") {
			g.fillVideo(box, strings.TrimPrefix(u, "video:"))
			continue
		}
		g.fillPicture(box, firstNonEmpty(info.link, u), u, info.yt)
	}
	for _, box := range probes {
		if obj := g.mediaObject(u); obj != nil {
			box.Objects = []fyne.CanvasObject{obj}
			box.Refresh()
		}
	}
	if len(boxes)+len(probes) > 0 {
		g.msgBox.Refresh()
		if was {
			g.stickBottom()
		}
	}
}

func firstNonEmpty(a, b string) string {
	if a != "" {
		return a
	}
	return b
}

// clickArea is an invisible widget that opens a link when clicked.
type clickArea struct {
	widget.BaseWidget
	onTap func()
}

func newClickArea(f func()) *clickArea {
	c := &clickArea{onTap: f}
	c.ExtendBaseWidget(c)
	return c
}

func (c *clickArea) Tapped(*fyne.PointEvent) { c.onTap() }
func (c *clickArea) Cursor() desktop.Cursor  { return desktop.PointerCursor }
func (c *clickArea) CreateRenderer() fyne.WidgetRenderer {
	return widget.NewSimpleRenderer(canvas.NewRectangle(color.Transparent))
}

// ---------------------------------------------------------------------------
// Switching windows / buttons
// ---------------------------------------------------------------------------

func (g *gui) switchTo(conn, buf string) {
	g.mu.Lock()
	g.cur.conn, g.cur.buf = conn, buf
	delete(g.unread, key(conn, buf))
	g.tab = nil
	g.mu.Unlock()
	g.rendered = -1
	g.stopVideo()
	g.refreshAll()
	g.win.Canvas().Focus(g.input)
}

func (g *gui) waitAndSwitch(c *core.Conn, buf string) {
	go func() {
		for i := 0; i < 25; i++ {
			if _, ok := c.Buffer(buf); ok {
				fyne.Do(func() { g.switchTo(c.ID(), buf) })
				return
			}
			time.Sleep(200 * time.Millisecond)
		}
	}()
}

func (g *gui) openQuery(nick string) {
	if c := g.cl.Conn(g.cur.conn); c != nil && nick != "" {
		g.switchTo(c.ID(), c.OpenQuery(nick))
	}
}

func (g *gui) toggleConnect() {
	c := g.cl.Conn(g.cur.conn)
	if c == nil {
		return
	}
	if c.Info().Status == "disconnected" {
		c.Connect()
	} else {
		c.Disconnect("Leaving")
	}
}

func (g *gui) setTheme(name string) {
	g.cl.SetGlobal(func(s *core.Settings) { s.Theme = name })
	g.glob = g.cl.Global()
	g.th = g.makeTheme(name)
	g.app.Settings().SetTheme(g.th)
	g.applyThemeColors()
	g.rendered = -1
	g.refreshAll()
}

func (g *gui) toggleLightDark() {
	if g.th.p.dark {
		g.setTheme("light")
	} else {
		g.setTheme("dark")
	}
}

// ---------------------------------------------------------------------------
// Typing
// ---------------------------------------------------------------------------

var helpText = `Keys
  Enter  send          Tab  complete a nickname        Up/Down  previous messages
  Alt+Left/Right (or Ctrl+Tab / Ctrl+Shift+Tab)  next / previous window or tab
  Ctrl +  /  Ctrl -  /  Ctrl 0   bigger / smaller / normal text
  F11  full screen on/off
  Ctrl+V  paste (works even after clicking in the chat)
  Ctrl+Shift+C (or right-click a line → Select text to copy…)  select & copy chat text
  Right-click a line: copy message / line / link / nickname / whole window

People: click a name (or right-click a line) for private chat, whois,
  CTCP version/ping/time, direct (DCC) chat, send a file, op/voice,
  kick, ban and kick + ban (choose the ban mask).
Channel button (top): topic, modes, password, user limit and bans.
Download button (top): DCC chats and file transfers.
Server button (top): edit this server (address, port, passwords, SASL
  account login, nickname, channels, connect commands).
Servers button (left, or the box icon in tab mode): all your servers —
  edit, connect/disconnect, delete, add, Import… and Export….
Channel list button (in a server window): browse/search the server's
  channels and click one to join.

Commands
  /join #chan [key]   /part [reason]   /msg nick text   /query nick   /me does something
  /nick newname   /topic text   /whois nick   /notice target text   /away [message]
  /kick nick   /op /deop /voice /devoice nick   /raw LINE   /connect   /disconnect
  /close  (leave channel / close chat)   /clear   /theme name   /quit
  /dcc chat nick   /dcc send nick file   /dcc accept N   /dcc decline N   /dcc list
  /ctcp nick version|ping|time   /version nick   /ping nick
  /ban nick [1-6]   /kickban nick [1-6] [reason]   /unban mask   /bans
  /ignore nick (or *!*@host)   /unignore nick   /ignore  (shows the list)
  /highlight add word   /highlight del word   /list   /cycle   /back   /motd
  /import file [all]   /export file   (all = also nick, theme, settings)

Pictures and animated GIFs show in the chat — click one to see it bigger.
Videos show a preview — click to play it in the chat (needs ffmpeg next to
the program). YouTube links show a picture — click to open in your browser.
Click a name in the people list to chat privately.`

func (g *gui) note(kind, text string) {
	obj := g.lineObject(core.Line{Time: time.Now(), Kind: kind, Text: text})
	g.msgBox.Add(obj)
	g.stickBottom()
}

func (g *gui) submit() {
	text := g.input.Text
	if strings.TrimSpace(text) == "" {
		return
	}
	g.input.SetText("")
	g.history = append([]string{text}, g.history...)
	if len(g.history) > 100 {
		g.history = g.history[:100]
	}
	g.histPos = -1
	fields := strings.Fields(text)
	cmd := strings.ToLower(fields[0])
	c := g.cl.Conn(g.cur.conn)
	switch cmd {
	case "/help":
		g.showHelp()
		return
	case "/quit", "/exit":
		g.win.Close()
		return
	case "/clear":
		if c != nil {
			c.ClearLines(g.cur.buf)
		}
		g.rendered = -1
		g.refreshMessages()
		return
	case "/close":
		if c != nil && g.cur.buf != "*" {
			c.CloseBuffer(g.cur.buf)
			g.switchTo(g.cur.conn, "*")
		}
		return
	case "/theme":
		if len(fields) > 1 {
			if _, ok := palettes[strings.ToLower(fields[1])]; ok {
				g.setTheme(strings.ToLower(fields[1]))
				return
			}
		}
		g.note("info", "Themes: "+strings.Join(themeOrder, ", ")+"  — e.g. /theme light")
		return
	}
	if handled, out, err := g.cl.GlobalCommand(text); handled {
		if err != nil {
			g.note("error", err.Error())
		} else {
			g.note("info", out)
		}
		g.glob = g.cl.Global()
		g.refreshAll()
		return
	}
	if c == nil {
		g.note("error", "No server yet — click \"Servers\" → Add server.")
		return
	}
	sw, err := c.Input(g.cur.buf, text)
	if err != nil {
		g.note("error", err.Error())
		return
	}
	if sw != "" {
		g.waitAndSwitch(c, sw)
	}
}

// inputEntry adds history (Up/Down) and nick completion (Tab) to an Entry.
type inputEntry struct {
	widget.Entry
	g *gui
}

func newInputEntry(g *gui) *inputEntry {
	e := &inputEntry{g: g}
	e.ExtendBaseWidget(e)
	return e
}

func (e *inputEntry) AcceptsTab() bool { return true }

func (e *inputEntry) TypedKey(k *fyne.KeyEvent) {
	g := e.g
	switch k.Name {
	case fyne.KeyF11:
		g.win.SetFullScreen(!g.win.FullScreen())
		return
	case fyne.KeyTab:
		g.complete()
		return
	case fyne.KeyUp:
		if len(g.history) > 0 {
			if g.histPos < len(g.history)-1 {
				g.histPos++
			}
			e.SetText(g.history[g.histPos])
			e.CursorColumn = len([]rune(e.Text))
			e.Refresh()
		}
		return
	case fyne.KeyDown:
		if g.histPos > 0 {
			g.histPos--
			e.SetText(g.history[g.histPos])
		} else {
			g.histPos = -1
			e.SetText("")
		}
		e.CursorColumn = len([]rune(e.Text))
		e.Refresh()
		return
	case fyne.KeyPageUp:
		g.scroll.Offset.Y -= g.scroll.Size().Height * 0.9
		if g.scroll.Offset.Y < 0 {
			g.scroll.Offset.Y = 0
		}
		g.scroll.Refresh()
		return
	case fyne.KeyPageDown:
		g.scroll.Offset.Y += g.scroll.Size().Height * 0.9
		g.scroll.Refresh()
		return
	}
	g.tab = nil
	e.Entry.TypedKey(k)
}

func (e *inputEntry) TypedShortcut(s fyne.Shortcut) {
	if _, ok := s.(*fyne.ShortcutPaste); ok {
		if t := e.g.app.Clipboard().Content(); strings.Contains(strings.Trim(strings.ReplaceAll(t, "\r", ""), "\n"), "\n") {
			e.g.pasteLines(t)
			return
		}
	}
	if cs, ok := s.(*desktop.CustomShortcut); ok && cs.KeyName == fyne.KeyC && cs.Modifier == fyne.KeyModifierControl|fyne.KeyModifierShift {
		e.g.copyTextDialog()
		return
	}
	if cs, ok := s.(*desktop.CustomShortcut); ok && cs.Modifier&fyne.KeyModifierControl != 0 &&
		(cs.KeyName == fyne.KeyEqual || cs.KeyName == fyne.KeyMinus || cs.KeyName == fyne.Key0) {
		e.g.changeSize(map[fyne.KeyName]int{fyne.KeyEqual: 1, fyne.KeyMinus: -1, fyne.Key0: 0}[cs.KeyName])
		return
	}
	if cs, ok := s.(*desktop.CustomShortcut); ok && cs.Modifier == fyne.KeyModifierAlt {
		switch cs.KeyName {
		case fyne.KeyLeft, fyne.KeyUp:
			e.g.moveWindow(-1)
			return
		case fyne.KeyRight, fyne.KeyDown:
			e.g.moveWindow(1)
			return
		}
	}
	if cs, ok := s.(*desktop.CustomShortcut); ok && cs.KeyName == fyne.KeyTab {
		if cs.Modifier&fyne.KeyModifierShift != 0 {
			e.g.moveWindow(-1)
		} else {
			e.g.moveWindow(1)
		}
		return
	}
	e.Entry.TypedShortcut(s)
}

func (g *gui) moveWindow(delta int) {
	if len(g.sideItems) == 0 {
		return
	}
	idx := 0
	for i, it := range g.sideItems {
		if it.conn == g.cur.conn && strings.EqualFold(it.buf, g.cur.buf) {
			idx = i
		}
	}
	idx = (idx + delta + len(g.sideItems)) % len(g.sideItems)
	g.switchTo(g.sideItems[idx].conn, g.sideItems[idx].buf)
}

func (g *gui) complete() {
	c := g.cl.Conn(g.cur.conn)
	if c == nil {
		return
	}
	text := g.input.Text
	if g.tab == nil {
		i := strings.LastIndex(text, " ") + 1
		word := text[i:]
		if word == "" {
			return
		}
		nicks := c.CompleteNick(g.cur.buf, word)
		if len(nicks) == 0 {
			return
		}
		g.tab = &tabState{start: i, nicks: nicks, atStart: i == 0}
	} else {
		g.tab.i = (g.tab.i + 1) % len(g.tab.nicks)
	}
	n := g.tab.nicks[g.tab.i]
	if g.tab.atStart {
		n += ": "
	} else {
		n += " "
	}
	g.input.SetText(text[:g.tab.start] + n)
	g.input.CursorColumn = len([]rune(g.input.Text))
	g.input.Refresh()
}

// ---------------------------------------------------------------------------
// Dialogs
// ---------------------------------------------------------------------------

func (g *gui) showHelp() {
	lbl := widget.NewLabel(helpText)
	lbl.TextStyle = fyne.TextStyle{Monospace: true}
	info := widget.NewLabel("Settings file: " + g.cl.Path() + "\nLogs folder: " + g.cl.Log.Dir())
	info.Wrapping = fyne.TextWrapBreak
	info.Importance = widget.LowImportance
	dialog.ShowCustom("Help", "Close", container.NewVBox(lbl, info), g.win)
}

func (g *gui) serverDialog(c *core.Conn) {
	sc := core.ServerConfig{TLS: true, AutoConnect: true}
	title := "Add IRC server"
	if c != nil {
		sc = c.Config()
		title = "Server settings — " + sc.DisplayName()
	}
	name := widget.NewEntry()
	name.SetText(sc.Name)
	host := widget.NewEntry()
	host.SetText(sc.Host)
	port := widget.NewEntry()
	if c != nil {
		port.SetText(strconv.Itoa(sc.EffectivePort()))
	}
	port.SetPlaceHolder("empty = 6697 encrypted / 6667 plain")
	host.SetPlaceHolder("irc.example.net")
	tls := widget.NewCheck("Encrypted connection (TLS/SSL)", nil)
	tls.SetChecked(sc.TLS)
	tls.OnChanged = func(b bool) {
		if b && port.Text == "6667" {
			port.SetText("6697")
		} else if !b && port.Text == "6697" {
			port.SetText("6667")
		}
	}
	self := widget.NewCheck("Allow self-signed certificate", nil)
	self.SetChecked(sc.SelfSigned)
	srvUser := widget.NewEntry()
	srvUser.SetText(sc.ServerUser)
	srvUser.SetPlaceHolder("only for ZNC / bouncers (user or user/network)")
	pass := widget.NewPasswordEntry()
	pass.SetText(sc.Password)
	saslUser := widget.NewEntry()
	saslUser.SetText(sc.SASLUser)
	saslUser.SetPlaceHolder("your registered account name (optional)")
	saslPass := widget.NewPasswordEntry()
	saslPass.SetText(sc.SASLPass)
	saslPass.SetPlaceHolder("account password — logs you in while connecting")
	nick := widget.NewEntry()
	nick.SetText(sc.Nick)
	nick.SetPlaceHolder(g.glob.Nick + "  (from Settings)")
	chans := widget.NewEntry()
	chans.SetText(strings.Join(sc.Channels, ", "))
	chans.SetPlaceHolder("#chat, #help")
	cmds := widget.NewMultiLineEntry()
	cmds.SetText(strings.Join(sc.Commands, "\n"))
	cmds.SetPlaceHolder("/msg NickServ IDENTIFY mypassword\n/mode $me +x")
	cmds.SetMinRowsVisible(4)
	auto := widget.NewCheck("Connect when the program starts", nil)
	auto.SetChecked(sc.AutoConnect)
	hint := widget.NewLabel("Commands run each time you connect (one per line). / commands work like typing them; other lines go to the server as-is. $me = your nick, /wait 2 pauses.")
	hint.Wrapping = fyne.TextWrapWord
	hint.Importance = widget.LowImportance

	form := widget.NewForm(
		widget.NewFormItem("Name", name),
		widget.NewFormItem("Server address", host),
		widget.NewFormItem("Port", port),
		widget.NewFormItem("", tls),
		widget.NewFormItem("", self),
		widget.NewFormItem("Server username", srvUser),
		widget.NewFormItem("Server password", pass),
		widget.NewFormItem("Account (SASL)", saslUser),
		widget.NewFormItem("Account password", saslPass),
		widget.NewFormItem("Nickname", nick),
		widget.NewFormItem("Channels", chans),
		widget.NewFormItem("Connect commands", cmds),
		widget.NewFormItem("", hint),
		widget.NewFormItem("", auto),
	)
	errLbl := widget.NewLabel("")
	errLbl.Importance = widget.DangerImportance
	content := container.NewVBox(form, errLbl)
	var d dialog.Dialog
	save := func() {
		sc.Name, sc.Host = strings.TrimSpace(name.Text), strings.TrimSpace(host.Text)
		sc.Port, _ = strconv.Atoi(strings.TrimSpace(port.Text))
		sc.TLS, sc.SelfSigned, sc.Password = tls.Checked, self.Checked, pass.Text
		sc.ServerUser = strings.TrimSpace(srvUser.Text)
		sc.SASLUser, sc.SASLPass = strings.TrimSpace(saslUser.Text), saslPass.Text
		sc.Nick = strings.TrimSpace(nick.Text)
		sc.Channels = strings.Split(chans.Text, ",")
		sc.Commands = strings.Split(cmds.Text, "\n")
		sc.AutoConnect = auto.Checked
		if c == nil {
			nc, err := g.cl.AddServer(sc)
			if err != nil {
				errLbl.SetText(err.Error())
				return
			}
			d.Hide()
			g.switchTo(nc.ID(), "*")
			return
		}
		if err := g.cl.UpdateServer(sc); err != nil {
			errLbl.SetText(err.Error())
			return
		}
		d.Hide()
		g.refreshAll()
	}
	buttons := container.NewHBox(layout.NewSpacer())
	if c != nil {
		del := widget.NewButtonWithIcon("Delete server", theme.DeleteIcon(), func() {
			dialog.ShowConfirm("Delete server", "Remove "+sc.DisplayName()+" from your list?", func(ok bool) {
				if ok {
					d.Hide()
					g.cl.RemoveServer(sc.ID)
					if cs := g.cl.Conns(); len(cs) > 0 {
						g.switchTo(cs[0].ID(), "*")
					} else {
						g.cur.conn = ""
						g.refreshAll()
					}
				}
			}, g.win)
		})
		del.Importance = widget.DangerImportance
		buttons.Objects = []fyne.CanvasObject{del, layout.NewSpacer()}
	}
	cancel := widget.NewButton("Cancel", func() { d.Hide() })
	saveBtn := widget.NewButtonWithIcon("Save", theme.ConfirmIcon(), save)
	saveBtn.Importance = widget.HighImportance
	buttons.Add(cancel)
	buttons.Add(saveBtn)
	d = dialog.NewCustomWithoutButtons(title, container.NewBorder(nil, buttons, nil, nil, content), g.win)
	d.Resize(fyne.NewSize(640, 720))
	d.Show()
}

func (g *gui) settingsDialog() {
	s := g.cl.Global()
	saved := false
	nick := widget.NewEntry()
	nick.SetText(s.Nick)
	alt := widget.NewEntry()
	alt.SetText(s.AltNick)
	real := widget.NewEntry()
	real.SetText(s.Realname)
	labels := []string{}
	for _, t := range themeOrder {
		labels = append(labels, themeLabels[t])
	}
	themeSel := widget.NewSelect(labels, func(label string) {
		for _, t := range themeOrder {
			if themeLabels[t] == label && t != g.th.name {
				g.setTheme(t) // preview immediately
			}
		}
	})
	themeSel.SetSelected(themeLabels[g.th.name])
	// Font and size (preview right away; saved with Save)
	origFont, origSize := s.Font, s.FontSize
	curFont, curSize := s.Font, s.FontSize
	if curFont == "" {
		curFont = fontDefault
	}
	if curSize == 0 {
		curSize = defaultSize
	}
	fontSel := widget.NewSelect([]string{fontDefault, fontMonospace}, nil)
	fontSel.SetSelected(curFont)
	sizes := []string{}
	for _, n := range []int{9, 10, 11, 12, 13, 14, 15, 16, 18, 20, 22, 24, 28, 32} {
		sizes = append(sizes, strconv.Itoa(n))
	}
	sizeSel := widget.NewSelect(sizes, nil)
	sizeSel.SetSelected(strconv.Itoa(curSize))
	preview := func() {
		f := fontSel.Selected
		n, _ := strconv.Atoi(sizeSel.Selected)
		g.applyFont(f, n)
	}
	fontSel.OnChanged = func(string) { preview() }
	sizeSel.OnChanged = func(string) { preview() }
	go func() { // reading the installed fonts can take a moment
		names := fontNames()
		fyne.Do(func() {
			cb := fontSel.OnChanged
			fontSel.OnChanged = nil // don't re-apply the font just for showing it
			sel := fontSel.Selected
			fontSel.Options = names
			found := false
			for _, n := range names {
				if strings.EqualFold(n, sel) || strings.EqualFold(n, curFont) {
					fontSel.SetSelected(n)
					found = true
					break
				}
			}
			if !found {
				fontSel.SetSelected(fontDefault)
			}
			fontSel.Refresh()
			fontSel.OnChanged = cb
		})
	}()
	fontHint := widget.NewLabel("Tip: Ctrl + and Ctrl - change the text size any time. Put .ttf/.otf fonts in a \"fonts\" folder next to the program to use them anywhere.")
	fontHint.Wrapping = fyne.TextWrapWord
	fontHint.Importance = widget.LowImportance
	chanOpts := []string{"Left pane", "Tabs on top", "Tabs on bottom"}
	chanVals := map[string]string{"Left pane": "left", "Tabs on top": "top", "Tabs on bottom": "bottom"}
	origList := s.ChanList
	chanSel := widget.NewSelect(chanOpts, func(o string) { // preview right away
		g.glob.ChanList = chanVals[o]
		g.relayout()
	})
	switch s.ChanList {
	case "top":
		chanSel.SetSelected("Tabs on top")
	case "bottom":
		chanSel.SetSelected("Tabs on bottom")
	default:
		chanSel.SetSelected("Left pane")
	}
	origOpacity := s.Opacity
	if origOpacity == 0 {
		origOpacity = 100
	}
	opLabel := widget.NewLabel(fmt.Sprintf("%d%%", origOpacity))
	opSlider := widget.NewSlider(20, 100)
	opSlider.Step = 5
	opSlider.SetValue(float64(origOpacity))
	opSlider.OnChanged = func(v float64) {
		opLabel.SetText(fmt.Sprintf("%d%%", int(v)))
		g.applyOpacity(int(v)) // preview
	}
	tray := widget.NewCheck("Close button hides the window to the tray (keeps you connected)", nil)
	tray.SetChecked(s.TrayOnClose)
	if !g.hasTray {
		tray.Disable()
	}
	media := widget.NewCheck("Show pictures and videos posted in chat", nil)
	media.SetChecked(s.ShowMedia)
	joins := widget.NewCheck("Show join / part / quit messages", nil)
	joins.SetChecked(s.ShowJoins)
	dccPorts := widget.NewEntry()
	dccPorts.SetText(s.DCCPorts)
	dccPorts.SetPlaceHolder("e.g. 5000-5010   (empty = any free port)")
	dccIP := widget.NewEntry()
	dccIP.SetText(s.DCCIP)
	dccIP.SetPlaceHolder("automatic — set your public IP if behind a router")
	dlDir := widget.NewEntry()
	dlDir.SetText(s.Downloads)
	dlDir.SetPlaceHolder("downloads  (next to the program)")
	logging := widget.NewCheck("Save chat logs (in the logs folder next to the program)", nil)
	logging.SetChecked(s.Logging)
	openLogs := widget.NewButtonWithIcon("Open logs folder", theme.FolderOpenIcon(), func() { core.OpenFolder(g.cl.Log.Dir()) })
	notify := widget.NewCheck("Notify me when someone mentions me or messages me privately", nil)
	notify.SetChecked(s.Notify)
	hlWords := widget.NewEntry()
	hlWords.SetText(strings.Join(s.Highlights, ", "))
	hlWords.SetPlaceHolder("extra words that count as a mention, e.g. bob, pizza")
	ignores := widget.NewMultiLineEntry()
	ignores.SetText(strings.Join(s.Ignores, "\n"))
	ignores.SetPlaceHolder("one per line: a nick, or a mask like *!*@bad.host")
	ignores.SetMinRowsVisible(3)
	errLbl := widget.NewLabel("")
	errLbl.Importance = widget.DangerImportance
	form := widget.NewForm(
		widget.NewFormItem("Nickname", nick),
		widget.NewFormItem("Backup nickname", alt),
		widget.NewFormItem("Real name", real),
		widget.NewFormItem("Channel list", chanSel),
		widget.NewFormItem("DCC ports", dccPorts),
		widget.NewFormItem("DCC public IP", dccIP),
		widget.NewFormItem("Downloads folder", dlDir),
		widget.NewFormItem("Theme", themeSel),
		widget.NewFormItem("Window opacity", container.NewBorder(nil, nil, nil, opLabel, opSlider)),
		widget.NewFormItem("", tray),
		widget.NewFormItem("Font", fontSel),
		widget.NewFormItem("Text size", sizeSel),
		widget.NewFormItem("", fontHint),
		widget.NewFormItem("", media),
		widget.NewFormItem("", joins),
		widget.NewFormItem("", logging),
		widget.NewFormItem("", container.NewHBox(openLogs)),
		widget.NewFormItem("", notify),
		widget.NewFormItem("Highlight words", hlWords),
		widget.NewFormItem("Ignore list", ignores),
	)
	var d dialog.Dialog
	saveBtn := widget.NewButtonWithIcon("Save", theme.ConfirmIcon(), func() {
		n := strings.TrimSpace(nick.Text)
		if n == "" || strings.ContainsAny(n, " ,*?!@#:") {
			errLbl.SetText("Please enter a valid nickname (no spaces).")
			return
		}
		if _, _, err := core.ParsePortRange(dccPorts.Text); err != nil {
			errLbl.SetText(err.Error())
			return
		}
		g.cl.SetGlobal(func(st *core.Settings) {
			st.Nick, st.AltNick, st.Realname = n, strings.TrimSpace(alt.Text), real.Text
			st.ShowMedia, st.ShowJoins, st.Logging = media.Checked, joins.Checked, logging.Checked
			st.Font = fontSel.Selected
			st.ChanList = chanVals[chanSel.Selected]
			st.DCCPorts, st.DCCIP, st.Downloads = strings.TrimSpace(dccPorts.Text), strings.TrimSpace(dccIP.Text), strings.TrimSpace(dlDir.Text)
			st.Opacity = int(opSlider.Value)
			st.TrayOnClose = tray.Checked
			st.Notify = notify.Checked
			st.Highlights = splitList(hlWords.Text, ",")
			st.Ignores = splitList(ignores.Text, "\n")
			st.FontSize, _ = strconv.Atoi(sizeSel.Selected)
		})
		saved = true
		g.glob = g.cl.Global()
		d.Hide()
		g.rendered = -1
		g.refreshAll()
	})
	saveBtn.Importance = widget.HighImportance
	buttons := container.NewHBox(layout.NewSpacer(), widget.NewButton("Close", func() { d.Hide() }), saveBtn)
	d0 := &d
	defer func() {
		(*d0).SetOnClosed(func() {
			if !saved { // closed without saving: go back to the old font and layout
				g.glob.ChanList = origList
				g.relayout()
				g.applyOpacity(origOpacity)
				g.applyFont(origFont, origSize)
			}
		})
	}()
	note := widget.NewLabel("Your nickname is used on servers that don't have their own (set it per server with the gear button).")
	note.Wrapping = fyne.TextWrapWord
	note.Importance = widget.LowImportance
	d = dialog.NewCustomWithoutButtons("Settings", container.NewBorder(nil, buttons, nil, nil, container.NewVBox(form, note, errLbl)), g.win)
	d.Resize(fyne.NewSize(600, 640))
	d.Show()
}

// makeTheme builds the color theme with the chosen font and size.
func (g *gui) makeTheme(name string) *ircTheme {
	t := newTheme(name)
	t.setFont(g.glob.Font, g.glob.FontSize)
	return t
}

// applyFont changes the font/size right away (not saved).
func (g *gui) applyFont(font string, size int) {
	t := newTheme(g.th.name)
	t.setFont(font, size)
	g.th = t
	g.app.Settings().SetTheme(t)
	g.applyThemeColors()
	g.rendered = -1
	g.refreshAll()
}

// changeSize makes the text bigger/smaller (Ctrl +, Ctrl -, Ctrl 0) and saves it.
func (g *gui) changeSize(delta int) {
	n := g.glob.FontSize
	if n == 0 {
		n = defaultSize
	}
	if delta == 0 {
		n = defaultSize
	} else {
		n += delta
	}
	if n < 8 {
		n = 8
	}
	if n > 40 {
		n = 40
	}
	g.cl.SetGlobal(func(st *core.Settings) { st.FontSize = n })
	g.glob = g.cl.Global()
	g.applyFont(g.glob.Font, n)
}

// chanList is where channels are shown: "left", "top" or "bottom".
func (g *gui) chanList() string {
	switch g.glob.ChanList {
	case "top", "bottom":
		return g.glob.ChanList
	}
	return "left"
}

// relayout puts the panes in place for the chosen channel list style.
func (g *gui) relayout() {
	var top, bottom fyne.CanvasObject
	mode := g.chanList()
	switch mode {
	case "top":
		top = g.tabBar
	case "bottom":
		bottom = g.tabBar
	}
	// chat | people (drag the divider to resize)
	var main fyne.CanvasObject = g.centerPane
	g.rightSplit, g.leftSplit = nil, nil
	if g.rightShown {
		g.rightSplit = container.NewHSplit(g.centerPane, g.rightPane)
		g.rightSplit.Offset = 0.82
		if g.glob.RightSplit > 0 {
			g.rightSplit.Offset = g.glob.RightSplit
		}
		main = g.rightSplit
	}
	// left pane | rest
	if mode == "left" && !g.glob.HideLeft {
		g.leftSplit = container.NewHSplit(g.leftPane, main)
		g.leftSplit.Offset = 0.19
		if g.glob.LeftSplit > 0 {
			g.leftSplit.Offset = g.glob.LeftSplit
		}
		main = g.leftSplit
	}
	if g.leftBtn != nil {
		if mode == "left" {
			g.leftBtn.Show()
		} else {
			g.leftBtn.Hide()
		}
	}
	g.win.SetContent(container.NewBorder(top, bottom, nil, nil, main))
	g.refreshTabs(-1)
}

// saveSplits remembers where the pane dividers were dragged to.
func (g *gui) saveSplits() {
	l, r := 0.0, 0.0
	if g.leftSplit != nil {
		l = g.leftSplit.Offset
	}
	if g.rightSplit != nil {
		r = g.rightSplit.Offset
	}
	if l == 0 && r == 0 {
		return
	}
	g.cl.SetGlobal(func(st *core.Settings) {
		if l > 0 {
			st.LeftSplit = l
		}
		if r > 0 {
			st.RightSplit = r
		}
	})
	g.glob = g.cl.Global()
}

// applyOpacity makes the window see-through (20..100 percent).
func (g *gui) applyOpacity(percent int) {
	if percent <= 0 {
		percent = 100
	}
	if nw, ok := g.win.(driver.NativeWindow); ok {
		nw.RunNative(func(ctx any) { setNativeOpacity(ctx, percent) })
	}
}

// refreshTabs rebuilds the tab buttons (only shown in top/bottom mode).
func (g *gui) refreshTabs(sel int) {
	if g.tabRow == nil || g.chanList() == "left" {
		return
	}
	g.tabRow.Objects = nil
	var selBtn fyne.CanvasObject
	for i, it := range g.sideItems {
		it := it
		label := it.buf
		switch it.kind {
		case "server":
			dot := map[string]string{"connected": "● ", "disconnected": "○ "}[it.status]
			if dot == "" {
				dot = "◌ "
			}
			label = dot + it.label
		case "query":
			label = "@" + it.buf
		}
		if it.unread > 0 {
			label += fmt.Sprintf(" (%d)", it.unread)
		}
		b := widget.NewButton(label, func() { g.switchTo(it.conn, it.buf) })
		switch {
		case it.conn == g.cur.conn && strings.EqualFold(it.buf, g.cur.buf):
			b.Importance = widget.HighImportance
			selBtn = b
		case it.hl:
			b.Importance = widget.DangerImportance
		case it.unread > 0:
			b.Importance = widget.WarningImportance
		default:
			b.Importance = widget.LowImportance
		}
		if it.kind == "channel" && !it.joined {
			b.Importance = widget.LowImportance
		}
		g.tabRow.Add(b)
		_ = i
	}
	g.tabRow.Refresh()
	if selBtn != nil { // keep the current tab in view
		pos := selBtn.Position().X
		w := g.tabScroll.Size().Width
		if pos < g.tabScroll.Offset.X || pos+selBtn.Size().Width > g.tabScroll.Offset.X+w {
			g.tabScroll.Offset.X = pos - 20
			if g.tabScroll.Offset.X < 0 {
				g.tabScroll.Offset.X = 0
			}
			g.tabScroll.Refresh()
		}
	}
}

type newLine struct {
	k  string
	hl bool
}

// lineWrap adds a right-click menu to a chat line: copy the message, the
// whole line, or one of its links.
type lineWrap struct {
	widget.BaseWidget
	g       *gui
	content fyne.CanvasObject
	line    core.Line
}

func newLineWrap(g *gui, content fyne.CanvasObject, l core.Line) *lineWrap {
	w := &lineWrap{g: g, content: content, line: l}
	w.ExtendBaseWidget(w)
	return w
}

func (w *lineWrap) CreateRenderer() fyne.WidgetRenderer { return widget.NewSimpleRenderer(w.content) }

func (w *lineWrap) TappedSecondary(pe *fyne.PointEvent) {
	l := w.line
	text := core.StripFormatting(l.Text)
	whole := l.Time.Format("15:04") + " "
	switch l.Kind {
	case "msg":
		whole += "<" + l.Nick + "> " + text
	case "action":
		whole += "* " + l.Nick + " " + text
	case "notice":
		whole += "-" + l.Nick + "- " + text
	default:
		whole += text
	}
	clip := w.g.app.Clipboard()
	items := []*fyne.MenuItem{
		fyne.NewMenuItem("Copy message", func() { clip.SetContent(text) }),
		fyne.NewMenuItem("Copy whole line", func() { clip.SetContent(whole) }),
	}
	for _, u := range core.FindURLs(text) {
		u := u
		label := u
		if len(label) > 60 {
			label = label[:57] + "…"
		}
		items = append(items, fyne.NewMenuItem("Copy link  "+label, func() { clip.SetContent(u) }))
	}
	if l.Nick != "" {
		nick := l.Nick
		items = append(items, fyne.NewMenuItemSeparator(),
			fyne.NewMenuItem("Copy nickname", func() { clip.SetContent(nick) }),
			fyne.NewMenuItem("Private chat with "+nick, func() { w.g.openQuery(nick) }))
		if sub := w.g.nickMenuItems(nick); len(sub) > 0 {
			more := fyne.NewMenuItem("More for "+nick, nil)
			more.ChildMenu = fyne.NewMenu("", sub...)
			items = append(items, more)
		}
	}
	items = append(items, fyne.NewMenuItemSeparator(),
		fyne.NewMenuItem("Select text to copy…  (Ctrl+Shift+C)", w.g.copyTextDialog),
		fyne.NewMenuItem("Copy this whole window", func() { clip.SetContent(w.g.windowText()) }),
		fyne.NewMenuItem("Paste into the typing box", w.g.pasteToInput))
	widget.ShowPopUpMenuAtPosition(fyne.NewMenu("", items...), w.g.win.Canvas(), pe.AbsolutePosition)
}

// windowText is the current window's chat as plain text.
func (g *gui) windowText() string {
	c := g.cl.Conn(g.cur.conn)
	if c == nil {
		return ""
	}
	var b strings.Builder
	for _, l := range c.Lines(g.cur.buf) {
		t := core.StripFormatting(l.Text)
		switch l.Kind {
		case "msg":
			t = "<" + l.Nick + "> " + t
		case "action":
			t = "* " + l.Nick + " " + t
		case "notice":
			t = "-" + l.Nick + "- " + t
		}
		b.WriteString(l.Time.Format("15:04") + " " + t + "\n")
	}
	return b.String()
}
