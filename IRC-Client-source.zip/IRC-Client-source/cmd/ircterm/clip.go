package main

// Copy and paste for the terminal version.
//
//   Ctrl+C  copy what's in the typing box (empty box: copy menu)
//   Ctrl+X  cut what's in the typing box
//   Ctrl+V  paste (your terminal's own paste — right-click, Shift+Insert,
//           Ctrl+Shift+V — works too)
//   Right-click the chat: copy menu (last message, pick a line, whole window)
//   Right-click the typing box: paste
//   F9      mouse off, so you can select text with your terminal and copy it
//           (in most terminals Shift+drag selects even with the mouse on)
//
// The clipboard is the computer's own (Windows, or Linux with xclip/xsel/
// wl-clipboard). Over SSH, copying also uses the OSC 52 code, which puts the
// text on YOUR computer's clipboard in terminals that support it (Windows
// Terminal, xterm, kitty, iTerm2, WezTerm, …).

import (
	"encoding/base64"
	"fmt"
	"os"
	"strings"

	"github.com/atotto/clipboard"
	"github.com/gdamore/tcell/v2"
	"github.com/rivo/tview"

	"ircclient/core"
)

// pasteField is the typing box; it catches pasted text so several pasted
// lines can be sent as separate messages.
type pasteField struct {
	*tview.InputField
	u *ui
}

func (p *pasteField) PasteHandler() func(string, func(tview.Primitive)) {
	return p.WrapPasteHandler(func(text string, setFocus func(tview.Primitive)) {
		p.u.paste(text)
	})
}

func (p *pasteField) MouseHandler() func(tview.MouseAction, *tcell.EventMouse, func(tview.Primitive)) (bool, tview.Primitive) {
	inner := p.InputField.MouseHandler()
	return func(a tview.MouseAction, ev *tcell.EventMouse, setFocus func(tview.Primitive)) (bool, tview.Primitive) {
		if a == tview.MouseRightClick && p.InRect(ev.Position()) {
			setFocus(p.InputField)
			p.u.pasteFromClipboard()
			return true, nil
		}
		return inner(a, ev, setFocus)
	}
}

func copyText(s string) (string, error) {
	err := clipboard.WriteAll(s)
	viaSSH := os.Getenv("SSH_CONNECTION") != "" || os.Getenv("SSH_TTY") != ""
	if err != nil || viaSSH {
		// OSC 52: ask the terminal itself to put the text on its clipboard.
		fmt.Fprintf(os.Stdout, "\x1b]52;c;%s\x07", base64.StdEncoding.EncodeToString([]byte(s)))
		if err != nil {
			return "Copied (sent to your terminal's clipboard — if it doesn't paste, use F9 and select with the mouse)", nil
		}
	}
	return "Copied to the clipboard", nil
}

func (u *ui) copyNote(s string) {
	msg, err := copyText(s)
	if err != nil {
		u.note("error", "Couldn't copy: "+err.Error())
		return
	}
	n := len([]rune(s))
	u.note("info", fmt.Sprintf("%s (%d characters)", msg, n))
}

func (u *ui) pasteFromClipboard() {
	t, err := clipboard.ReadAll()
	if err != nil || t == "" {
		u.note("info", "Nothing to paste from here — use your terminal's paste (right-click, Shift+Insert or Ctrl+Shift+V)")
		return
	}
	u.paste(t)
}

// paste inserts text into the typing box; several lines ask first.
func (u *ui) paste(text string) {
	text = strings.ReplaceAll(strings.ReplaceAll(text, "\r\n", "\n"), "\r", "\n")
	text = strings.Trim(text, "\n")
	if !strings.Contains(text, "\n") {
		u.input.PasteHandler()(text, func(p tview.Primitive) { u.app.SetFocus(p) })
		return
	}
	var lines []string
	for _, l := range strings.Split(text, "\n") {
		if strings.TrimSpace(l) != "" {
			lines = append(lines, l)
		}
	}
	c := u.cl.Conn(u.cur.conn)
	buf := u.cur.buf
	if c == nil || buf == "*" {
		u.input.PasteHandler()(strings.Join(lines, " "), func(p tview.Primitive) { u.app.SetFocus(p) })
		return
	}
	u.menu(fmt.Sprintf("You pasted %d lines", len(lines)), []string{
		fmt.Sprintf("Send them as %d messages to %s", len(lines), buf),
		"Put them on one line in the typing box",
		"Cancel",
	}, []func(){
		func() {
			for _, l := range lines {
				if strings.HasPrefix(l, "/") {
					l = "/" + l // send as text, not as a command
				}
				if _, err := c.Input(buf, l); err != nil {
					u.note("error", err.Error())
					return
				}
			}
			if len(lines) > 8 {
				u.note("info", "Sending slowly so the server doesn't disconnect you for flooding…")
			}
		},
		func() { u.input.SetText(u.input.GetText() + strings.Join(lines, " ")) },
		func() {},
	})
}

func (u *ui) lineText(l core.Line) string {
	t := core.StripFormatting(l.Text)
	switch l.Kind {
	case "msg":
		return "<" + l.Nick + "> " + t
	case "action":
		return "* " + l.Nick + " " + t
	case "notice":
		return "-" + l.Nick + "- " + t
	}
	return t
}

// copyMenu: right-click on the chat, or Ctrl+C with an empty typing box.
func (u *ui) copyMenu() {
	c := u.cl.Conn(u.cur.conn)
	var lines []core.Line
	if c != nil {
		lines = c.Lines(u.cur.buf)
	}
	var labels []string
	var acts []func()
	add := func(l string, f func()) { labels = append(labels, l); acts = append(acts, f) }
	for i := len(lines) - 1; i >= 0; i-- {
		if lines[i].IsChat() {
			l := lines[i]
			add("Copy the last message", func() { u.copyNote(core.StripFormatting(l.Text)) })
			break
		}
	}
	if len(lines) > 0 {
		add("Copy a line… (pick from the list)", func() { u.pickLine(lines) })
		add("Copy a link…", func() { u.pickLink(lines) })
		add("Copy the whole window", func() {
			var b strings.Builder
			for _, l := range lines {
				b.WriteString(l.Time.Format("15:04") + " " + u.lineText(l) + "\n")
			}
			u.copyNote(b.String())
		})
	}
	add("Paste", u.pasteFromClipboard)
	add("Select with the mouse (F9 — mouse off; F9 again when done)", func() { u.toggleMouse() })
	u.menu("Copy & paste", labels, acts)
}

func (u *ui) pickLine(lines []core.Line) {
	if len(lines) > 200 {
		lines = lines[len(lines)-200:]
	}
	var labels []string
	var acts []func()
	for i := len(lines) - 1; i >= 0; i-- {
		l := lines[i]
		t := u.lineText(l)
		label := l.Time.Format("15:04") + " " + t
		if r := []rune(label); len(r) > 80 {
			label = string(r[:79]) + "…"
		}
		labels = append(labels, label)
		acts = append(acts, func() { u.copyNote(t) })
	}
	u.menu("Pick a line to copy (newest first)", labels, acts)
}

func (u *ui) pickLink(lines []core.Line) {
	var labels []string
	var acts []func()
	seen := map[string]bool{}
	for i := len(lines) - 1; i >= 0 && len(labels) < 60; i-- {
		for _, link := range core.FindURLs(lines[i].Text) {
			if seen[link] {
				continue
			}
			seen[link] = true
			link := link
			labels = append(labels, link)
			acts = append(acts, func() { u.copyNote(link) })
		}
	}
	if len(labels) == 0 {
		u.note("info", "No links in this window")
		return
	}
	u.menu("Pick a link to copy", labels, acts)
}
