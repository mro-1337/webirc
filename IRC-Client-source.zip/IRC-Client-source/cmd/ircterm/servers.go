package main

// Servers menu (F5): edit / connect / disconnect / delete / add / import /
// export; channel list (F12, /list); bell on mentions.

import (
	"fmt"
	"strings"
	"time"

	"github.com/gdamore/tcell/v2"
	"github.com/rivo/tview"

	"ircclient/core"
)

func splitList(t string) []string {
	out := []string{}
	for _, w := range strings.FieldsFunc(t, func(r rune) bool { return r == ',' || r == '\n' }) {
		if w = strings.TrimSpace(w); w != "" {
			out = append(out, w)
		}
	}
	return out
}

var lastBell time.Time

func (u *ui) bell() {
	if !u.glob.Notify || u.scr == nil || time.Since(lastBell) < 2*time.Second {
		return
	}
	lastBell = time.Now()
	u.scr.Beep()
}

func (u *ui) serversMenu() {
	var labels []string
	var acts []func()
	add := func(l string, f func()) { labels = append(labels, l); acts = append(acts, f) }
	if c := u.cl.Conn(u.cur.conn); c != nil {
		cfg := c.Config()
		add("Edit this server ("+cfg.DisplayName()+")", func() { u.serverDialog(c) })
	}
	add("Add a server…", func() { u.serverDialog(nil) })
	add("Import servers from a file…", u.importForm)
	add("Export servers & settings to a file…", u.exportForm)
	conns := u.cl.Conns()
	if len(conns) > 0 {
		add("── your servers (Enter for options) ──", nil)
	}
	for _, c := range conns {
		c := c
		cfg, info := c.Config(), c.Info()
		add(fmt.Sprintf("%s  (%s:%d, %s)", cfg.DisplayName(), cfg.Host, cfg.EffectivePort(), info.Status), func() { u.serverActions(c) })
	}
	u.menu("Servers", labels, acts)
}

func (u *ui) serverActions(c *core.Conn) {
	cfg, info := c.Config(), c.Info()
	var labels []string
	var acts []func()
	add := func(l string, f func()) { labels = append(labels, l); acts = append(acts, f) }
	add("Edit settings…", func() { u.serverDialog(c) })
	if info.Status == "disconnected" {
		add("Connect", func() { c.Connect() })
	} else {
		add("Disconnect", func() { c.Disconnect("Leaving") })
	}
	add("Go to its window", func() { u.switchTo(c.ID(), "*") })
	add("Channel list", func() {
		if err := c.RequestList(""); err != nil {
			u.note("error", err.Error())
		} else {
			u.note("info", "Asking "+cfg.DisplayName()+" for its channel list… it opens when it arrives")
		}
	})
	add("Delete this server", func() {
		u.menu("Delete "+cfg.DisplayName()+"?", []string{"No, keep it", "Yes, delete it"}, []func(){
			func() {},
			func() {
				u.cl.RemoveServer(cfg.ID)
				if u.cur.conn == cfg.ID {
					if cs := u.cl.Conns(); len(cs) > 0 {
						u.switchTo(cs[0].ID(), "*")
					} else {
						u.cur.conn = ""
					}
				}
				u.refreshAll()
			},
		})
	})
	u.menu(cfg.DisplayName(), labels, acts)
}

func (u *ui) importForm() {
	path, all := "", false
	f := tview.NewForm()
	f.AddInputField("File", "", 56, nil, func(t string) { path = strings.Trim(strings.TrimSpace(t), `"'`) })
	f.AddCheckbox("Also import nick, theme & other settings", false, func(b bool) { all = b })
	f.AddButton("Import", func() {
		if path == "" {
			f.SetTitle(" ⚠ Type the path of the file to import ")
			return
		}
		r, err := u.cl.Import(path, all)
		if err != nil {
			f.SetTitle(" ⚠ " + err.Error() + " ")
			return
		}
		u.closeDialog()
		if r.Settings {
			u.glob = u.cl.Global()
			u.applyTheme(u.glob.Theme)
			u.relayout()
		}
		u.note("info", r.Summary())
		u.note("info", "New servers aren't connected yet — F5, pick one, Connect.")
		u.refreshAll()
	})
	f.AddButton("Cancel", u.closeDialog)
	f.SetTitle(" Import servers (this program's file, WebIRC, HexChat servlist.conf, mIRC servers.ini, list) ")
	u.styleForm(f)
	u.modal(f, 100, 9)
}

func (u *ui) exportForm() {
	path := "irc-servers.txt"
	f := tview.NewForm()
	f.AddInputField("Save as", path, 56, nil, func(t string) { path = strings.Trim(strings.TrimSpace(t), `"'`) })
	f.AddButton("Export", func() {
		if err := u.cl.Export(path); err != nil {
			f.SetTitle(" ⚠ " + err.Error() + " ")
			return
		}
		u.closeDialog()
		u.note("info", "Saved your servers and settings to "+path+" (includes passwords — keep it safe)")
	})
	f.AddButton("Cancel", u.closeDialog)
	f.SetTitle(" Export servers & settings ")
	u.styleForm(f)
	u.modal(f, 84, 7)
}

// channelList shows the server's channels with a search box; Enter joins.
func (u *ui) channelList(connID, filter string) {
	c := u.cl.Conn(connID)
	if c == nil {
		return
	}
	if u.pages.HasPage("dialog") {
		return // another window is open; F12 shows the list later
	}
	col := tcell.GetColor
	in := tview.NewInputField().SetLabel("Search: ").SetText(filter).SetFieldWidth(0)
	in.SetFieldStyle(tcell.StyleDefault.Background(col(u.th.bg)).Foreground(col(u.th.fg)))
	in.SetLabelColor(col(u.th.accent)).SetBackgroundColor(col(u.th.panel))
	l := tview.NewList().ShowSecondaryText(false).SetHighlightFullLine(true)
	l.SetBackgroundColor(col(u.th.panel))
	l.SetMainTextStyle(tcell.StyleDefault.Background(col(u.th.panel)).Foreground(col(u.th.fg)))
	l.SetSelectedStyle(tcell.StyleDefault.Background(col(u.th.accent)).Foreground(col(u.th.bg)))
	var items []core.ListEntry
	fill := func(text string) {
		items, _, _ = c.ChannelList(text)
		if len(items) > 2000 {
			items = items[:2000]
		}
		l.Clear()
		for _, e := range items {
			l.AddItem(tview.Escape(fmt.Sprintf("%-24s %5d  %s", e.Channel, e.Users, e.Topic)), "", 0, nil)
		}
	}
	fill(filter)
	box := tview.NewFlex().SetDirection(tview.FlexRow).AddItem(in, 1, 0, true).AddItem(l, 0, 1, false)
	cfg := c.Config()
	box.SetBorder(true).SetTitle(fmt.Sprintf(" Channels on %s — type to search, ↓ to the list, Enter joins, Esc closes ", cfg.DisplayName()))
	box.SetBorderColor(col(u.th.accent)).SetTitleColor(col(u.th.accent)).SetBackgroundColor(col(u.th.panel))
	in.SetChangedFunc(fill)
	in.SetDoneFunc(func(k tcell.Key) {
		if k == tcell.KeyEnter || k == tcell.KeyDown || k == tcell.KeyTab {
			u.app.SetFocus(l)
		}
	})
	l.SetSelectedFunc(func(i int, _, _ string, _ rune) {
		if i >= len(items) {
			return
		}
		ch := items[i].Channel
		u.closeDialog()
		if sw, err := c.Input("*", "/join "+ch); err != nil {
			u.note("error", err.Error())
		} else if sw != "" {
			go func() {
				for k := 0; k < 25; k++ {
					if _, ok := c.Buffer(sw); ok {
						u.app.QueueUpdateDraw(func() { u.switchTo(connID, sw) })
						return
					}
					time.Sleep(200 * time.Millisecond)
				}
			}()
		}
	})
	l.SetInputCapture(func(ev *tcell.EventKey) *tcell.EventKey {
		if ev.Key() == tcell.KeyUp && l.GetCurrentItem() == 0 || ev.Key() == tcell.KeyBacktab {
			u.app.SetFocus(in)
			return nil
		}
		return ev
	})
	box.SetInputCapture(func(ev *tcell.EventKey) *tcell.EventKey {
		if ev.Key() == tcell.KeyEscape {
			u.closeDialog()
			return nil
		}
		return ev
	})
	_, _, w, h := u.pages.GetRect()
	if w > 120 {
		w = 120
	}
	u.modal(box, w-4, h-4)
	u.app.SetFocus(in)
}
