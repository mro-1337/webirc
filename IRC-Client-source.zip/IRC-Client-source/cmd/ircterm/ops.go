package main

// Name menu (private chat, whois, CTCP, DCC, op/voice, kick, ban with a
// choice of mask), channel settings (F10) and DCC transfers (F4).

import (
	"fmt"
	"path/filepath"
	"strconv"
	"strings"

	"ircclient/core"

	"github.com/gdamore/tcell/v2"
	"github.com/rivo/tview"
)

// menu shows a list of choices in a box; Esc closes it.
func (u *ui) menu(title string, labels []string, actions []func()) {
	l := tview.NewList().ShowSecondaryText(false).SetHighlightFullLine(true)
	c := tcell.GetColor
	l.SetBorder(true).SetTitle(" " + title + " ").SetBorderColor(c(u.th.accent)).SetTitleColor(c(u.th.accent))
	l.SetBackgroundColor(c(u.th.panel))
	l.SetMainTextStyle(tcell.StyleDefault.Background(c(u.th.panel)).Foreground(c(u.th.fg)))
	l.SetSelectedStyle(tcell.StyleDefault.Background(c(u.th.accent)).Foreground(c(u.th.bg)))
	width := len(title) + 6
	for i, lab := range labels {
		act := actions[i]
		short := rune(0)
		if i < 9 {
			short = rune('1' + i)
		}
		if act == nil { // separator / heading
			l.AddItem("[::d]"+tview.Escape(lab)+"[::-]", "", 0, nil)
			continue
		}
		l.AddItem(tview.Escape(lab), "", short, func() {
			u.closeDialog()
			act()
		})
		if n := len([]rune(lab)) + 8; n > width {
			width = n
		}
	}
	if width > 90 {
		width = 90
	}
	h := len(labels) + 2
	if _, _, _, sh := u.pages.GetRect(); sh > 6 && h > sh-2 {
		h = sh - 2
	}
	u.modal(l, width, h)
}

func (u *ui) showErr(err error) {
	if err != nil {
		u.note("error", err.Error())
	}
}

// nickMenu: everything you can do with a person.
func (u *ui) nickMenu(nick string) {
	c := u.cl.Conn(u.cur.conn)
	if c == nil || nick == "" {
		return
	}
	ch := ""
	if c.IsChannel(u.cur.buf) {
		ch = u.cur.buf
	}
	var labels []string
	var acts []func()
	add := func(l string, f func()) { labels = append(labels, l); acts = append(acts, f) }
	add("Private chat", func() { u.switchTo(u.cur.conn, c.OpenQuery(nick)) })
	add("Whois (info)", func() { u.showErr(c.Whois(nick)); u.switchTo(u.cur.conn, "*") })
	add("Check client: version", func() { u.showErr(c.CTCP(nick, "VERSION", "")) })
	add("Check client: ping (lag)", func() { u.showErr(c.CTCP(nick, "PING", "")) })
	add("Check client: time", func() { u.showErr(c.CTCP(nick, "TIME", "")) })
	add("Direct chat (DCC)", func() {
		if _, err := c.OfferChat(nick); err != nil {
			u.note("error", "DCC: "+err.Error())
		}
	})
	add("Send a file (DCC)…", func() { u.sendFileForm(c, nick) })
	if ch != "" {
		add("── in "+ch+" ──", nil)
		mode := func(m string) func() { return func() { u.showErr(c.UserMode(ch, m, nick)) } }
		add("Give op (+o)", mode("+o"))
		add("Take op (-o)", mode("-o"))
		add("Give voice (+v)", mode("+v"))
		add("Take voice (-v)", mode("-v"))
		add("Kick…", func() { u.kickForm(c, ch, nick, -1) })
		add("Ban… (choose mask)", func() { u.banMaskMenu(c, ch, nick, false) })
		add("Kick + ban… (choose mask)", func() { u.banMaskMenu(c, ch, nick, true) })
	}
	u.menu(nick, labels, acts)
}

func (u *ui) banMaskMenu(c *core.Conn, ch, nick string, kick bool) {
	var labels []string
	var acts []func()
	for i := range core.BanMaskTypes {
		t := i
		labels = append(labels, fmt.Sprintf("%-14s  %s", core.BanMaskLabel(t), c.BanMaskPreview(t, nick)))
		if kick {
			acts = append(acts, func() { u.kickForm(c, ch, nick, t) })
		} else {
			acts = append(acts, func() { u.showErr(c.Ban(ch, nick, t, false, "")) })
		}
	}
	title := "Ban " + nick + " — pick a mask"
	if kick {
		title = "Kick + ban " + nick + " — pick a mask"
	}
	u.menu(title, labels, acts)
}

func (u *ui) kickForm(c *core.Conn, ch, nick string, banType int) {
	reason := ""
	f := tview.NewForm()
	f.AddInputField("Reason", "", 40, nil, func(t string) { reason = t })
	label := "Kick"
	if banType >= 0 {
		label = "Kick + ban"
	}
	f.AddButton(label, func() {
		u.closeDialog()
		if banType >= 0 {
			u.showErr(c.Ban(ch, nick, banType, true, reason))
		} else {
			u.showErr(c.Kick(ch, nick, reason))
		}
	})
	f.AddButton("Cancel", u.closeDialog)
	f.SetTitle(" " + label + " " + nick + " from " + ch + " ")
	u.styleForm(f)
	u.modal(f, 64, 9)
}

// ---------------------------------------------------------------------------
// Channel settings (F10)
// ---------------------------------------------------------------------------

func (u *ui) chanSettings() {
	c := u.cl.Conn(u.cur.conn)
	if c == nil || !c.IsChannel(u.cur.buf) {
		u.note("error", "F10 channel settings work in a channel window")
		return
	}
	ch := u.cur.buf
	ci, _ := c.ChannelInfo(ch)
	topic, key, limitText := ci.Topic, ci.Key, ""
	if ci.Limit > 0 {
		limitText = strconv.Itoa(ci.Limit)
	}
	modes := map[byte]bool{}
	for _, m := range core.SimpleModes {
		modes[m.Letter] = strings.IndexByte(ci.Modes, m.Letter) >= 0
	}
	f := tview.NewForm()
	f.AddInputField("Topic", topic, 0, nil, func(t string) { topic = t })
	for _, m := range core.SimpleModes {
		letter := m.Letter
		f.AddCheckbox(m.Label, modes[letter], func(b bool) { modes[letter] = b })
	}
	f.AddInputField("Password (+k, empty = none)", key, 24, nil, func(t string) { key = t })
	f.AddInputField("User limit (+l, empty = none)", limitText, 8, tview.InputFieldInteger, func(t string) { limitText = t })
	f.AddButton("Apply", func() {
		n := 0
		if limitText != "" {
			n, _ = strconv.Atoi(limitText)
		}
		ms := ""
		for _, m := range core.SimpleModes {
			if modes[m.Letter] {
				ms += string(m.Letter)
			}
		}
		u.closeDialog()
		if topic != ci.Topic {
			u.showErr(c.SetTopic(ch, topic))
		}
		u.showErr(c.ApplyChannelModes(ch, ms, key, n))
	})
	f.AddButton("Bans…", func() { u.closeDialog(); u.bansMenu(c, ch) })
	f.AddButton("Cancel", u.closeDialog)
	title := " Channel settings: " + ch + " "
	if !c.IsOp(ch) {
		title += "(you're not an operator — changes may be refused) "
	}
	f.SetTitle(title)
	u.styleForm(f)
	f.SetItemPadding(0)
	u.modal(f, 100, 17)
}

func (u *ui) bansMenu(c *core.Conn, ch string) {
	ci, _ := c.ChannelInfo(ch)
	if ci.Bans == nil {
		c.RequestBans(ch)
		u.note("info", "Loading the ban list… (opening it again in a moment)")
		go func() {
			for i := 0; i < 20; i++ {
				if ci, _ := c.ChannelInfo(ch); ci.Bans != nil {
					u.app.QueueUpdateDraw(func() { u.bansMenu(c, ch) })
					return
				}
				sleepMS(200)
			}
		}()
		return
	}
	var labels []string
	var acts []func()
	labels = append(labels, "Add a ban mask…")
	acts = append(acts, func() {
		mask := ""
		f := tview.NewForm()
		f.AddInputField("Mask", "*!*@", 50, nil, func(t string) { mask = t })
		f.AddButton("Ban", func() { u.closeDialog(); u.showErr(c.SendRaw("MODE " + ch + " +b " + mask)) })
		f.AddButton("Cancel", u.closeDialog)
		f.SetTitle(" Add ban in " + ch + " ")
		u.styleForm(f)
		u.modal(f, 70, 7)
	})
	labels = append(labels, "Refresh list")
	acts = append(acts, func() {
		c.RequestBans(ch)
		go func() { sleepMS(1200); u.app.QueueUpdateDraw(func() { u.bansMenu(c, ch) }) }()
	})
	if len(ci.Bans) == 0 {
		labels = append(labels, "(no bans)")
		acts = append(acts, nil)
	}
	for _, b := range ci.Bans {
		mask := b.Mask
		labels = append(labels, "Remove "+mask+"  (by "+b.SetBy+")")
		acts = append(acts, func() { u.showErr(c.Unban(ch, mask)) })
	}
	u.menu("Bans in "+ch, labels, acts)
}

// ---------------------------------------------------------------------------
// DCC (F4)
// ---------------------------------------------------------------------------

func (u *ui) showOffer(id int) {
	d, ok := u.cl.DCCInfo(id)
	if !ok || !d.IsOffer {
		return
	}
	if name, _ := u.pages.GetFrontPage(); name != "main" {
		return // another box is open; the offer is also in the server window (/dcc accept N)
	}
	text := fmt.Sprintf("%s wants to send you\n%s (%s)\n\nSaved to: %s", d.Nick, d.File, core.HumanSize(d.Size), u.cl.DownloadsDir())
	if d.Kind != "receive" {
		text = d.Nick + " wants a direct (DCC) chat with you."
	}
	m := tview.NewModal().SetText(text).AddButtons([]string{"Accept", "Decline", "Later"})
	m.SetDoneFunc(func(_ int, label string) {
		u.pages.RemovePage("offer")
		u.app.SetFocus(u.input)
		switch label {
		case "Accept":
			if err := u.cl.AcceptDCC(id); err != nil {
				u.note("error", "DCC: "+err.Error())
			} else if d.ChatWin != "" {
				if c := u.cl.Conn(d.ConnID); c != nil {
					go func() {
						for i := 0; i < 50; i++ {
							if _, ok := c.Buffer(d.ChatWin); ok {
								u.app.QueueUpdateDraw(func() { u.switchTo(c.ID(), d.ChatWin) })
								return
							}
							sleepMS(200)
						}
					}()
				}
			}
		case "Decline":
			u.cl.DeclineDCC(id)
		}
	})
	m.SetBackgroundColor(tcell.GetColor(u.th.panel))
	u.pages.AddPage("offer", m, true, true)
	u.app.SetFocus(m)
}

func (u *ui) sendFileForm(c *core.Conn, nick string) {
	path := filepath.Dir(u.cl.Path()) + string(filepath.Separator)
	f := tview.NewForm()
	f.AddInputField("File", path, 60, nil, func(t string) { path = t })
	f.AddButton("Send", func() {
		u.closeDialog()
		if _, err := c.OfferFile(nick, strings.Trim(strings.TrimSpace(path), "\"")); err != nil {
			u.note("error", "DCC: "+err.Error())
		}
	})
	f.AddButton("Cancel", u.closeDialog)
	f.SetTitle(" Send a file to " + nick + " (type the full path) ")
	u.styleForm(f)
	u.modal(f, 80, 7)
}

func (u *ui) transfersMenu() {
	list := u.cl.Transfers()
	var labels []string
	var acts []func()
	if len(list) == 0 {
		labels = append(labels, "No DCC chats or transfers yet. Click a name → Direct chat / Send a file.")
		acts = append(acts, nil)
	}
	for i := len(list) - 1; i >= 0; i-- {
		d := list[i]
		id := d.ID
		labels = append(labels, core.DescribeDCC(d))
		switch {
		case d.IsOffer:
			acts = append(acts, func() { u.showOffer(id) })
		case !d.Finished:
			acts = append(acts, func() {
				u.menu("DCC #"+strconv.Itoa(id), []string{"Cancel / close it", "Keep it"},
					[]func(){func() { u.cl.CancelDCC(id) }, func() {}})
			})
		default:
			acts = append(acts, func() {})
		}
	}
	labels = append(labels, "Clear finished", "Downloads folder: "+u.cl.DownloadsDir())
	acts = append(acts, func() { u.cl.ClearFinishedDCC() }, func() { core.OpenFolder(u.cl.DownloadsDir()) })
	u.menu("DCC chats & transfers (Enter on one for options)", labels, acts)
}
