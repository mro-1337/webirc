//go:build !windows

package main

import (
	"os"
	"regexp"

	"github.com/gdamore/tcell/v2"
)

// Some terminals (Bitvise xterm, older PuTTY, some SSH clients) don't
// understand a few newer escape codes and print part of them on screen —
// e.g. a stray "q" wherever the cursor is — or mangle key presses.
// We strip those codes so the program works like a classic xterm.
// Set IRCTERM_RAW=1 to turn this filtering off.
var unsupportedCodes = regexp.MustCompile(
	"\x1b\\[[0-9]* q" + // cursor shape (DECSCUSR) -> the stray "q"
		"|\x1b\\]1?12[^\x07\x1b]*(\x07|\x1b\\\\)" + // cursor colour
		"|\x1b\\[>4;[0-9]*m" + // xterm modifyOtherKeys
		"|\x1b\\[>[0-9]*u|\x1b\\[<u" + // kitty keyboard protocol
		"|\x1b\\[\\?9001[hl]") // win32-input-mode

type filterTty struct{ tcell.Tty }

func (f filterTty) Write(p []byte) (int, error) {
	clean := unsupportedCodes.ReplaceAll(p, nil)
	if _, err := f.Tty.Write(clean); err != nil {
		return 0, err
	}
	return len(p), nil
}

// newScreen returns a terminal screen that only uses widely supported codes.
func newScreen() (tcell.Screen, error) {
	if os.Getenv("IRCTERM_RAW") == "1" {
		return tcell.NewScreen()
	}
	tty, err := tcell.NewDevTty()
	if err != nil {
		return tcell.NewScreen()
	}
	return tcell.NewTerminfoScreenFromTty(filterTty{tty})
}
