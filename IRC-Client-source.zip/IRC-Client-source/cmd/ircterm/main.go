// Terminal IRC client (Windows Command Prompt / PowerShell / Linux terminal).

//go:debug tlsrsakex=1
//go:debug tls3des=1
//go:debug rsa1024min=0
package main

import (
	"fmt"
	"github.com/atotto/clipboard"
	"hash/fnv"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"ircclient/core"

	"github.com/gdamore/tcell/v2"
	"github.com/rivo/tview"
)

// ---------------------------------------------------------------------------
// Themes
// ---------------------------------------------------------------------------

type theme struct {
	bg, panel, fg, muted, accent, event, err, hlBg, link string
	nickS, nickL                                         float64
}

var themes = map[string]theme{
	"dark":            {"#0f1216", "#161a20", "#e6e9ef", "#8a93a3", "#3b82f6", "#7d8698", "#ef4444", "#3a2f12", "#60a5fa", .65, .68},
	"light":           {"#ffffff", "#eceef2", "#1b1f27", "#697386", "#2563eb", "#7a8290", "#dc2626", "#fdf0d5", "#2563eb", .65, .36},
	"midnight":        {"#0b1020", "#0f1630", "#dbe4ff", "#8592c0", "#7c5cff", "#7783b3", "#ef4444", "#2a2050", "#a5b4fc", .65, .72},
	"bbs":             {"#000000", "#0000a8", "#c0c0c0", "#55ffff", "#ffff55", "#55ff55", "#ff5555", "#550055", "#ffff55", 1, .66},
	"terminal":        {"#000000", "#0a1a0a", "#33ff66", "#1fae45", "#33ff66", "#1d9e3f", "#ff5555", "#0b3a14", "#a3ffbf", .7, .62},
	"solarized-dark":  {"#002b36", "#073642", "#93a1a1", "#657b83", "#268bd2", "#586e75", "#dc322f", "#3a3a10", "#2aa198", .6, .6},
	"solarized-light": {"#fdf6e3", "#eee8d5", "#586e75", "#839496", "#268bd2", "#93a1a1", "#dc322f", "#f5e6b0", "#268bd2", .6, .38},
	"classic":         {"#ffffff", "#d4d0c8", "#000000", "#555555", "#000080", "#009300", "#ff0000", "#ffff80", "#0000ff", 1, .3},
	"high-contrast":   {"#000000", "#000000", "#ffffff", "#dddddd", "#ffd600", "#cccccc", "#ff5555", "#504000", "#66ccff", 1, .75},
	"dracula":         {"#282a36", "#21222c", "#f8f8f2", "#8a8fb0", "#bd93f9", "#6272a4", "#ff5555", "#4a3f1a", "#8be9fd", 0.75, 0.72},
	"nord":            {"#2e3440", "#3b4252", "#eceff4", "#9aa5b8", "#88c0d0", "#81a1c1", "#bf616a", "#4a4430", "#8fbcbb", 0.45, 0.7},
	"gruvbox-dark":    {"#282828", "#32302f", "#ebdbb2", "#a89984", "#fabd2f", "#928374", "#fb4934", "#4a3a12", "#83a598", 0.6, 0.62},
	"gruvbox-light":   {"#fbf1c7", "#f2e5bc", "#3c3836", "#7c6f64", "#b57614", "#928374", "#9d0006", "#f5d78e", "#076678", 0.6, 0.35},
	"monokai":         {"#272822", "#1e1f1c", "#f8f8f2", "#90908a", "#a6e22e", "#75715e", "#f92672", "#4a4520", "#66d9ef", 0.8, 0.65},
	"ocean":           {"#0f1c2e", "#13253b", "#d6e6ff", "#7f9cc0", "#22d3ee", "#6a8cb8", "#f87171", "#3a3315", "#7dd3fc", 0.6, 0.7},
	"amber":           {"#0d0800", "#140c00", "#ffb000", "#b07a00", "#ffb000", "#c88a00", "#ff5f3f", "#3a2600", "#ffd27a", 0.9, 0.58},
	"sepia":           {"#f4ecd8", "#eadfc6", "#4a3b2a", "#86735c", "#9c5b2e", "#8f7c63", "#b0352b", "#f0d79b", "#7a4a1e", 0.5, 0.34},
}

var themeOrder = []string{"dark", "light", "midnight", "bbs", "terminal", "solarized-dark", "solarized-light", "classic", "high-contrast", "dracula", "nord", "gruvbox-dark", "gruvbox-light", "monokai", "ocean", "amber", "sepia"}

func hsl(h, s, l float64) string {
	c := (1 - abs(2*l-1)) * s
	x := c * (1 - abs(modf(h/60, 2)-1))
	m := l - c/2
	var r, g, b float64
	switch {
	case h < 60:
		r, g, b = c, x, 0
	case h < 120:
		r, g, b = x, c, 0
	case h < 180:
		r, g, b = 0, c, x
	case h < 240:
		r, g, b = 0, x, c
	case h < 300:
		r, g, b = x, 0, c
	default:
		r, g, b = c, 0, x
	}
	return fmt.Sprintf("#%02x%02x%02x", int((r+m)*255), int((g+m)*255), int((b+m)*255))
}
func abs(f float64) float64 {
	if f < 0 {
		return -f
	}
	return f
}
func modf(a, b float64) float64 { return a - b*float64(int(a/b)) }

// ---------------------------------------------------------------------------
// App state
// ---------------------------------------------------------------------------

type unread struct {
	n  int
	hl bool
}

type ui struct {
	imgs     *core.ImageCache
	previews map[string]string
	cl       *core.Client
	app      *tview.Application
	pages    *tview.Pages
	th       theme
	glob     core.Settings
	scr      tcell.Screen

	side     *tview.List
	header   *tview.TextView
	msgs     *tview.TextView
	nicks    *tview.List
	input    *tview.InputField
	status   *tview.TextView
	body     *tview.Flex
	mouseOff bool
	root     *tview.Flex
	tabs     *tview.TextView // one-line tab bar (top/bottom layout)

	mu       sync.Mutex
	cur      struct{ conn, buf string } // conn id + buffer name
	sideKeys []struct{ conn, buf string }
	unread   map[string]*unread
	rendered int // lines of the current buffer already written
	links    map[string]string
	linkSeq  int
	lastURLs []string
	history  []string
	histPos  int
	showNick bool
	tab      *tabState
	dirty    chan struct{}
	newMu    sync.Mutex
	newLines []newLine
}

type tabState struct {
	start, end int
	nicks      []string
	i          int
	atStart    bool
}

func key(conn, buf string) string { return conn + "\x00" + strings.ToLower(buf) }

func main() {
	path := core.SettingsPath("irc-client.txt")
	settings, err := core.LoadSettings(path)
	if err != nil {
		fmt.Println("Problem with your settings file:", err)
		fmt.Println("Fix that line, or delete", path, "to start fresh.")
		fmt.Println("\nPress Enter to close.")
		fmt.Scanln()
		os.Exit(1)
	}
	u := &ui{cl: core.NewClient(path, settings), unread: map[string]*unread{}, links: map[string]string{},
		showNick: true, dirty: make(chan struct{}, 1), histPos: -1}
	u.glob = u.cl.Global()
	u.cl.OnEvent = u.onEvent
	u.build()
	u.applyTheme(u.glob.Theme)
	u.imgs = core.NewImageCache(48, 28) // at most 48 x 14 characters
	u.previews = map[string]string{}
	u.imgs.OnReady = func(string) {
		u.mu.Lock()
		u.rendered = -1 // draw the window again, now with the picture
		u.mu.Unlock()
		select {
		case u.dirty <- struct{}{}:
		default:
		}
	}
	go u.refreshLoop()
	u.cl.Start()
	if conns := u.cl.Conns(); len(conns) > 0 {
		u.cur.conn, u.cur.buf = conns[0].ID(), "*"
	}
	u.refreshAll()
	if err := u.app.Run(); err != nil {
		fmt.Println(err)
	}
	u.cl.Shutdown("Leaving")
}

// onEvent runs inside the IRC engine (which holds its own lock), so it
// must not take u.mu — it just queues what happened for the screen.
func (u *ui) onEvent(ev core.Event) {
	if ev.Kind == core.EvDCCOffer {
		id := ev.DCC
		go u.app.QueueUpdateDraw(func() { u.showOffer(id) })
	}
	if ev.Kind == core.EvBuffer && ev.Buf == "*list" {
		id := ev.Conn.ID()
		go u.app.QueueUpdateDraw(func() { u.channelList(id, "") })
	}
	if ev.Kind == core.EvLine && ev.Line.Highlight && ev.Line.IsChat() && !ev.Line.Self {
		go u.app.QueueUpdate(u.bell)
	}
	if ev.Kind == core.EvLine && ev.Line.IsChat() && !ev.Line.Self {
		u.newMu.Lock()
		if len(u.newLines) < 10000 {
			u.newLines = append(u.newLines, newLine{key(ev.Conn.ID(), ev.Buf), ev.Line.Highlight})
		}
		u.newMu.Unlock()
	}
	select {
	case u.dirty <- struct{}{}:
	default:
	}
}

// takeNewLines counts queued messages as unread (on the screen's side).
func (u *ui) takeNewLines() {
	u.newMu.Lock()
	list := u.newLines
	u.newLines = nil
	u.newMu.Unlock()
	if len(list) == 0 {
		return
	}
	u.mu.Lock()
	cur := key(u.cur.conn, u.cur.buf)
	for _, nl := range list {
		if nl.k == cur {
			continue
		}
		un := u.unread[nl.k]
		if un == nil {
			un = &unread{}
			u.unread[nl.k] = un
		}
		un.n++
		un.hl = un.hl || nl.hl
	}
	u.mu.Unlock()
}

func (u *ui) refreshLoop() {
	for range u.dirty {
		time.Sleep(40 * time.Millisecond)
		u.app.QueueUpdateDraw(u.refreshAll)
	}
}

// ---------------------------------------------------------------------------
// Layout
// ---------------------------------------------------------------------------

func (u *ui) build() {
	u.app = tview.NewApplication().EnableMouse(true).EnablePaste(true)
	if scr, err := newScreen(); err == nil {
		u.app.SetScreen(scr)
		u.scr = scr
	}
	u.side = tview.NewList().ShowSecondaryText(false).SetHighlightFullLine(true)
	u.side.SetBorder(true).SetTitle(" Servers & channels ")
	u.side.SetSelectedFunc(func(i int, _, _ string, _ rune) {
		u.mu.Lock()
		if i < len(u.sideKeys) {
			k := u.sideKeys[i]
			u.mu.Unlock()
			u.switchTo(k.conn, k.buf)
			u.app.SetFocus(u.input)
			return
		}
		u.mu.Unlock()
	})

	u.header = tview.NewTextView().SetDynamicColors(true).SetWrap(false)
	u.msgs = tview.NewTextView().SetDynamicColors(true).SetRegions(true).SetWrap(true).SetWordWrap(true).SetMaxLines(3000)
	u.msgs.SetBorder(true)
	u.msgs.SetHighlightedFunc(func(added, _, _ []string) {
		for _, id := range added {
			u.mu.Lock()
			link := u.links[id]
			u.mu.Unlock()
			if link != "" {
				core.OpenURL(link)
			}
		}
		go u.app.QueueUpdate(func() { u.msgs.Highlight() })
	})
	u.nicks = tview.NewList().ShowSecondaryText(false).SetHighlightFullLine(true)
	u.nicks.SetBorder(true).SetTitle(" People ")
	u.nicks.SetSelectedFunc(func(_ int, main, _ string, _ rune) {
		n := strings.TrimLeft(stripTags(main), "~&@%+! ")
		u.nickMenu(n) // private chat, whois, CTCP, DCC, op, kick, ban…
	})
	u.input = tview.NewInputField().SetLabel("> ").SetFieldWidth(0)
	u.input.SetDoneFunc(func(k tcell.Key) {
		if k == tcell.KeyEnter {
			u.submit()
		}
	})
	u.input.SetInputCapture(u.inputKeys)
	u.status = tview.NewTextView().SetDynamicColors(true).SetWrap(false)

	center := tview.NewFlex().SetDirection(tview.FlexRow).
		AddItem(u.header, 2, 0, false).
		AddItem(u.msgs, 0, 1, false).
		AddItem(&pasteField{u.input, u}, 1, 0, true)
	u.body = tview.NewFlex().
		AddItem(u.side, 26, 0, false).
		AddItem(center, 0, 1, true).
		AddItem(u.nicks, 20, 0, false)
	u.tabs = tview.NewTextView().SetDynamicColors(true).SetRegions(true).SetWrap(false)
	u.tabs.SetHighlightedFunc(func(added, _, _ []string) {
		for _, id := range added {
			if n, err := strconv.Atoi(strings.TrimPrefix(id, "w")); err == nil {
				go u.app.QueueUpdateDraw(func() {
					u.mu.Lock()
					var k struct{ conn, buf string }
					ok := n < len(u.sideKeys)
					if ok {
						k = u.sideKeys[n]
					}
					u.mu.Unlock()
					if ok {
						u.switchTo(k.conn, k.buf)
					}
					u.app.SetFocus(u.input)
				})
			}
		}
	})
	u.root = tview.NewFlex().SetDirection(tview.FlexRow)
	u.relayout()
	u.pages = tview.NewPages().AddPage("main", u.root, true, true)
	u.app.SetRoot(u.pages, true).SetFocus(u.input)
	u.app.SetInputCapture(u.globalKeys)
	u.app.SetMouseCapture(u.mouseCapture)
}

func stripTags(s string) string {
	var b strings.Builder
	in := false
	for _, r := range s {
		switch {
		case r == '[':
			in = true
		case r == ']' && in:
			in = false
		case !in:
			b.WriteRune(r)
		}
	}
	return b.String()
}

func (u *ui) applyTheme(name string) {
	t, ok := themes[name]
	if !ok {
		t, name = themes["dark"], "dark"
	}
	u.th = t
	c := tcell.GetColor
	tview.Styles.PrimitiveBackgroundColor = c(t.bg)
	tview.Styles.ContrastBackgroundColor = c(t.panel)
	tview.Styles.MoreContrastBackgroundColor = c(t.accent)
	tview.Styles.PrimaryTextColor = c(t.fg)
	tview.Styles.SecondaryTextColor = c(t.accent)
	tview.Styles.TertiaryTextColor = c(t.muted)
	tview.Styles.BorderColor = c(t.muted)
	tview.Styles.TitleColor = c(t.accent)
	tview.Styles.GraphicsColor = c(t.muted)
	for _, p := range []interface{ SetBackgroundColor(tcell.Color) *tview.Box }{u.side.Box, u.header.Box, u.msgs.Box, u.nicks.Box, u.status.Box} {
		p.SetBackgroundColor(c(t.bg))
	}
	u.side.SetBackgroundColor(c(t.panel))
	u.nicks.SetBackgroundColor(c(t.panel))
	for _, l := range []*tview.List{u.side, u.nicks} {
		l.SetMainTextColor(c(t.fg)).SetSelectedBackgroundColor(c(t.accent)).SetSelectedTextColor(c(t.bg))
		l.SetBorderColor(c(t.muted))
		l.SetTitleColor(c(t.accent))
	}
	base := tcell.StyleDefault.Background(c(t.bg)).Foreground(c(t.fg))
	panel := tcell.StyleDefault.Background(c(t.panel)).Foreground(c(t.fg))
	u.msgs.SetBorderColor(c(t.muted))
	u.msgs.SetTextStyle(base)
	u.header.SetTextStyle(base)
	u.status.SetTextStyle(panel)
	if u.tabs != nil {
		u.tabs.SetTextStyle(panel)
		u.tabs.SetBackgroundColor(c(t.panel))
	}
	u.status.SetBackgroundColor(c(t.panel))
	u.side.SetMainTextStyle(panel)
	u.nicks.SetMainTextStyle(panel)
	for _, l := range []*tview.List{u.side, u.nicks} {
		l.SetSelectedStyle(tcell.StyleDefault.Background(c(t.accent)).Foreground(c(t.bg)))
	}
	u.input.SetBackgroundColor(c(t.bg))
	u.input.SetLabelStyle(base.Foreground(c(t.accent)))
	u.input.SetFieldStyle(panel)
	u.input.SetPlaceholder("Type a message, or /help")
	u.input.SetPlaceholderStyle(panel.Foreground(c(t.muted)))
	u.rendered = -1
}

func (u *ui) nickColor(n string) string {
	h := fnv.New32a()
	h.Write([]byte(strings.ToLower(n)))
	return hsl(float64(h.Sum32()%360), u.th.nickS, u.th.nickL)
}

// ---------------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------------

func (u *ui) refreshAll() {
	u.takeNewLines()
	u.refreshSide()
	u.refreshHeader()
	u.refreshMessages()
	u.refreshNicks()
	u.refreshStatus()
}

func statusWord(s string) string {
	return map[string]string{"connected": "connected", "connecting": "connecting…", "registering": "logging in…",
		"waiting": "reconnecting…", "disconnected": "disconnected"}[s]
}

func (u *ui) refreshSide() {
	u.mu.Lock()
	defer u.mu.Unlock()
	cur := u.side.GetCurrentItem()
	u.side.Clear()
	u.sideKeys = nil
	sel := 0
	for _, c := range u.cl.Conns() {
		info := c.Info()
		dot := map[string]string{"connected": "[#22c55e]●[-]", "waiting": "[#ef4444]●[-]", "disconnected": "[" + u.th.muted + "]○[-]"}[info.Status]
		if dot == "" {
			dot = "[#f59e0b]●[-]"
		}
		for _, b := range c.Buffers() {
			label := ""
			switch b.Kind {
			case "server":
				label = dot + " [::b]" + tview.Escape(info.Name) + "[::-]"
			case "channel":
				label = "  " + tview.Escape(b.Name)
				if !b.Joined {
					label = "  [" + u.th.muted + "::i]" + tview.Escape(b.Name) + "[-::-]"
				}
			case "dcc":
				label = "  " + tview.Escape(b.Name) + " [" + u.th.muted + "](direct)[-]"
			default:
				label = "  @" + tview.Escape(b.Name)
			}
			if un := u.unread[key(info.ID, b.Name)]; un != nil && un.n > 0 {
				col := u.th.accent
				if un.hl {
					col = u.th.err
				}
				label += fmt.Sprintf(" [%s::b](%d)[-::-]", col, un.n)
			}
			if info.ID == u.cur.conn && strings.EqualFold(b.Name, u.cur.buf) {
				sel = len(u.sideKeys)
			}
			u.side.AddItem(label, "", 0, nil)
			u.sideKeys = append(u.sideKeys, struct{ conn, buf string }{info.ID, b.Name})
		}
	}
	_ = cur
	if len(u.sideKeys) > 0 {
		u.side.SetCurrentItem(sel)
	}
	u.drawTabs(sel)
}

// chanList is where channels are shown: "left", "top" or "bottom".
func (u *ui) chanList() string {
	switch u.glob.ChanList {
	case "top", "bottom":
		return u.glob.ChanList
	}
	return "left"
}

// relayout puts the channel list on the left, or as tabs on the top/bottom.
func (u *ui) relayout() {
	mode := u.chanList()
	u.root.Clear()
	if mode == "top" {
		u.root.AddItem(u.tabs, 1, 0, false)
	}
	u.root.AddItem(u.body, 0, 1, true)
	if mode == "bottom" {
		u.root.AddItem(u.tabs, 1, 0, false)
	}
	u.root.AddItem(u.status, 1, 0, false)
	if mode == "left" {
		u.body.ResizeItem(u.side, 26, 0)
	} else {
		u.body.ResizeItem(u.side, 0, 0)
	}
}

// drawTabs fills the tab bar. Caller holds u.mu.
func (u *ui) drawTabs(sel int) {
	if u.tabs == nil || u.chanList() == "left" {
		return
	}
	type tab struct {
		text  string // with colors
		width int
	}
	var tabs []tab
	for i, k := range u.sideKeys {
		label := k.buf
		var status string
		if c := u.cl.Conn(k.conn); c != nil {
			if k.buf == "*" {
				info := c.Info()
				label = info.Name
				status = info.Status
			} else if bi, ok := c.Buffer(k.buf); ok && bi.Kind == "query" {
				label = "@" + k.buf
			}
		}
		if k.buf == "*" {
			dot := map[string]string{"connected": "●", "disconnected": "○"}[status]
			if dot == "" {
				dot = "◌"
			}
			label = dot + " " + label
		}
		un := u.unread[key(k.conn, k.buf)]
		if un != nil && un.n > 0 {
			label += fmt.Sprintf(" (%d)", un.n)
		}
		fg, bg, attr := u.th.fg, u.th.panel, "-"
		switch {
		case i == sel:
			fg, bg, attr = u.th.bg, u.th.accent, "b"
		case un != nil && un.hl:
			fg, attr = u.th.err, "b"
		case un != nil && un.n > 0:
			fg, attr = u.th.accent, "b"
		}
		text := fmt.Sprintf(`["w%d"][%s:%s:%s] %s [-:-:-][""]`, i, fg, bg, attr, tview.Escape(label))
		tabs = append(tabs, tab{text, len([]rune(label)) + 3})
	}
	// keep the current tab visible when they don't all fit
	_, _, width, _ := u.tabs.GetInnerRect()
	if width <= 0 {
		width = 200
	}
	start := 0
	for {
		used := 0
		for i := start; i <= sel && i < len(tabs); i++ {
			used += tabs[i].width
		}
		if used <= width-2 || start >= sel {
			break
		}
		start++
	}
	var b strings.Builder
	if start > 0 {
		b.WriteString("[" + u.th.muted + "]‹[-]")
	}
	for _, t := range tabs[start:] {
		b.WriteString(t.text + "[" + u.th.muted + "]│[-]")
	}
	u.tabs.SetText(b.String())
}

func (u *ui) refreshHeader() {
	c := u.cl.Conn(u.cur.conn)
	if c == nil {
		u.header.SetText("[::b]No servers yet[::-] — press F5 to add or import one")
		return
	}
	info := c.Info()
	if u.cur.buf == "*" {
		sc := c.Config()
		enc := "not encrypted"
		if sc.TLS {
			enc = "encrypted"
		}
		extra := ""
		if info.Error != "" && info.Status != "connected" {
			extra = " · [" + u.th.err + "]" + tview.Escape(info.Error) + "[-]"
		}
		u.header.SetText(fmt.Sprintf("[::b]%s[::-]  [%s]%s:%d · %s · %s[-]%s",
			tview.Escape(info.Name), u.th.muted, tview.Escape(sc.Host), sc.Port, enc, statusWord(info.Status), extra))
		return
	}
	b, _ := c.Buffer(u.cur.buf)
	title := "[::b]" + tview.Escape(b.Name) + "[::-]"
	if b.Kind == "channel" && !b.Joined {
		title += " [" + u.th.muted + "](not joined)[-]"
	}
	u.header.SetText(title + "\n" + u.formatText(b.Topic, u.th.muted))
}

func (u *ui) refreshNicks() {
	c := u.cl.Conn(u.cur.conn)
	b, ok := core.BufInfo{}, false
	if c != nil {
		b, ok = c.Buffer(u.cur.buf)
	}
	show := ok && b.Kind == "channel" && u.showNick
	u.body.ResizeItem(u.nicks, map[bool]int{true: 20, false: 0}[show], 0)
	u.nicks.Clear()
	if !show {
		return
	}
	users := c.Users(u.cur.buf)
	u.nicks.SetTitle(fmt.Sprintf(" %d people ", len(users)))
	for _, n := range users {
		pfx, name := "", n
		if strings.ContainsAny(n[:1], "~&@%+!") {
			pfx, name = n[:1], n[1:]
		}
		u.nicks.AddItem(fmt.Sprintf("[%s]%1s[-][%s]%s[-]", u.th.muted, tview.Escape(pfx), u.nickColor(name), tview.Escape(name)), "", 0, nil)
	}
}

func (u *ui) refreshStatus() {
	nick := ""
	if c := u.cl.Conn(u.cur.conn); c != nil {
		nick = c.Info().Nick
	}
	u.status.SetText(fmt.Sprintf(" [%s::b]%s[-::-]  [%s]F1 help · F7/F8 switch · F2 people (Enter on a name = menu) · F10 channel · F4 DCC · F12 list · F5 servers · F6 settings · Ctrl+C/V copy/paste · Ctrl+Q quit[-]",
		u.th.accent, tview.Escape(nick), u.th.muted))
}

func (u *ui) refreshMessages() {
	c := u.cl.Conn(u.cur.conn)
	if c == nil {
		u.msgs.Clear()
		u.msgs.SetTitle("")
		return
	}
	lines := c.Lines(u.cur.buf)
	u.mu.Lock()
	start := u.rendered
	full := start < 0 || start > len(lines)
	if full {
		u.msgs.Clear()
		u.links = map[string]string{}
		u.lastURLs = nil
		start = 0
	}
	u.rendered = len(lines)
	u.mu.Unlock()
	var b strings.Builder
	for _, l := range lines[start:] {
		u.writeLine(&b, l)
	}
	if b.Len() > 0 {
		u.msgs.Write([]byte(b.String()))
	}
	if full {
		u.msgs.ScrollToEnd()
	}
}

func (u *ui) writeLine(b *strings.Builder, l core.Line) {
	joins := map[string]bool{"join": true, "part": true, "quit": true}
	if !u.glob.ShowJoins && joins[l.Kind] && !l.Self {
		return
	}
	t := u.th
	fmt.Fprintf(b, "[%s]%s[-] ", t.muted, l.Time.Format("15:04"))
	if l.Highlight {
		fmt.Fprintf(b, "[:%s]", t.hlBg)
	}
	switch l.Kind {
	case "msg":
		fmt.Fprintf(b, "[%s::b]%s[-::-] %s", u.nickColor(l.Nick), tview.Escape(l.Nick), u.formatText(l.Text, ""))
	case "action":
		fmt.Fprintf(b, "[%s::i]* %s[-::-] [::i]%s[::-]", u.nickColor(l.Nick), tview.Escape(l.Nick), u.formatText(l.Text, ""))
	case "notice":
		fmt.Fprintf(b, "[%s]-%s-[-] [%s]%s[-]", u.nickColor(l.Nick), tview.Escape(l.Nick), t.muted, u.formatText(l.Text, t.muted))
	case "error":
		fmt.Fprintf(b, "[%s]! %s[-]", t.err, tview.Escape(l.Text))
	default:
		sym := map[string]string{"join": "→", "part": "←", "quit": "←", "kick": "✕", "nick": "↔", "topic": "✎", "mode": "⚙", "info": "•"}[l.Kind]
		fmt.Fprintf(b, "[%s]%s %s[-]", t.event, sym, u.formatText(l.Text, t.event))
	}
	if l.Highlight {
		b.WriteString("[:-]")
	}
	b.WriteString("\n")
	if l.IsChat() {
		for _, link := range core.FindURLs(core.StripFormatting(l.Text)) {
			kind := core.LinkKind(link)
			icon := map[string]string{"image": "[picture]", "video": "[video]", "audio": "[audio]", "youtube": "[YouTube video]"}[kind]
			u.mu.Lock()
			u.lastURLs = append(u.lastURLs, link)
			if len(u.lastURLs) > 50 {
				u.lastURLs = u.lastURLs[1:]
			}
			n := len(u.lastURLs)
			u.mu.Unlock()
			if kind == "" && u.glob.ShowMedia {
				if k, done := u.imgs.Probe(link); done {
					kind = k
					icon = map[string]string{"image": "[picture]", "video": "[video]", "audio": "[audio]"}[kind]
				}
			}
			if icon != "" && u.glob.ShowMedia {
				b.WriteString(u.preview(link, kind))
				fmt.Fprintf(b, "      [%s]%s — click the link to open it, or type /open %d[-]\n", t.accent, tview.Escape(icon), n)
			}
		}
	}
}

// preview draws a small picture with colored half-block characters
// (each character cell shows two pixels, one above the other).
func (u *ui) preview(link, kind string) string {
	var ci *core.CachedImage
	switch kind {
	case "image", "youtube":
		thumb := core.ThumbnailURL(link)
		if thumb == "" {
			thumb = link
		}
		ci = u.imgs.Get(thumb)
	case "video":
		if !core.HaveFFmpeg() {
			return ""
		}
		ci = u.imgs.GetVideoFrame(link)
	default:
		return ""
	}
	switch ci.State {
	case core.ImgLoading:
		return "      [" + u.th.muted + "::i]loading preview…[-::-]\n"
	case core.ImgFailed:
		return ""
	}
	cacheKey := link + "|" + u.th.bg
	u.mu.Lock()
	if s, ok := u.previews[cacheKey]; ok {
		u.mu.Unlock()
		return s
	}
	u.mu.Unlock()
	img := ci.Img
	bounds := img.Bounds()
	bg := tcell.GetColor(u.th.bg)
	br, bgc, bb := bg.RGB()
	px := func(x, y int) string {
		if y >= bounds.Max.Y {
			return fmt.Sprintf("#%02x%02x%02x", br, bgc, bb)
		}
		r, g, b, a := img.At(x, y).RGBA()
		// blend see-through pixels with the background
		mix := func(c uint32, back int32) int {
			return int((c>>8)*(a>>8)/255 + uint32(back)*(255-(a>>8))/255)
		}
		return fmt.Sprintf("#%02x%02x%02x", mix(r, br), mix(g, bgc), mix(b, bb))
	}
	var sb strings.Builder
	for y := bounds.Min.Y; y < bounds.Max.Y; y += 2 {
		sb.WriteString("      ")
		for x := bounds.Min.X; x < bounds.Max.X; x++ {
			fmt.Fprintf(&sb, "[%s:%s]▀", px(x, y), px(x, y+1))
		}
		sb.WriteString("[-:-]\n")
	}
	out := sb.String()
	u.mu.Lock()
	if len(u.previews) > 200 {
		u.previews = map[string]string{}
	}
	u.previews[cacheKey] = out
	u.mu.Unlock()
	return out
}

// formatText turns IRC formatting into tview color tags and makes links clickable.
func (u *ui) formatText(text, baseColor string) string {
	var b strings.Builder
	for _, sp := range core.ParseFormatting(text) {
		fg, bg, attrs := "-", "-", ""
		if baseColor != "" {
			fg = baseColor
		}
		if sp.FG >= 0 {
			fg = fmt.Sprintf("#%06x", core.MIRCColors[sp.FG])
		}
		if sp.BG >= 0 {
			bg = fmt.Sprintf("#%06x", core.MIRCColors[sp.BG])
		}
		if sp.Bold {
			attrs += "b"
		}
		if sp.Italic {
			attrs += "i"
		}
		if sp.Underline {
			attrs += "u"
		}
		if sp.Strike {
			attrs += "s"
		}
		styled := fg != "-" || bg != "-" || attrs != ""
		for _, piece := range core.SplitLinks(sp.Text) {
			if piece.URL != "" {
				u.mu.Lock()
				u.linkSeq++
				id := "l" + strconv.Itoa(u.linkSeq)
				u.links[id] = piece.URL
				u.mu.Unlock()
				fmt.Fprintf(&b, `["%s"][%s::u:%s]%s[-::-:-][::U][""]`, id, u.th.link, strings.ReplaceAll(piece.URL, "]", "%5D"), tview.Escape(piece.Text))
				continue
			}
			if styled {
				fmt.Fprintf(&b, "[%s:%s:%s]%s[-:-:-][::U]", fg, bg, attrs, tview.Escape(piece.Text))
				if baseColor != "" {
					fmt.Fprintf(&b, "[%s]", baseColor)
				}
			} else {
				b.WriteString(tview.Escape(piece.Text))
			}
		}
	}
	return b.String()
}

// ---------------------------------------------------------------------------
// Switching windows
// ---------------------------------------------------------------------------

func (u *ui) switchTo(conn, buf string) {
	u.mu.Lock()
	u.cur.conn, u.cur.buf = conn, buf
	delete(u.unread, key(conn, buf))
	u.rendered = -1
	u.tab = nil
	u.mu.Unlock()
	u.refreshAll()
	u.msgs.ScrollToEnd()
}

func (u *ui) moveWindow(delta int) {
	u.mu.Lock()
	keys := append([]struct{ conn, buf string }(nil), u.sideKeys...)
	cur := u.cur
	u.mu.Unlock()
	if len(keys) == 0 {
		return
	}
	idx := 0
	for i, k := range keys {
		if k.conn == cur.conn && strings.EqualFold(k.buf, cur.buf) {
			idx = i
		}
	}
	idx = (idx + delta + len(keys)) % len(keys)
	u.switchTo(keys[idx].conn, keys[idx].buf)
}

// ---------------------------------------------------------------------------
// Keys
// ---------------------------------------------------------------------------

func (u *ui) toggleMouse() {
	u.mouseOff = !u.mouseOff
	u.app.EnableMouse(!u.mouseOff)
	if u.mouseOff {
		u.note("info", "Mouse is OFF: select text with your mouse and copy it like normal (in most terminals: select, then Ctrl+Shift+C, Enter or right-click). Press F9 again to turn the mouse back on.")
	} else {
		u.note("info", "Mouse is ON again (click channels, names and links). Press F9 to select and copy text.")
	}
}

// mouseCapture: right-click on the chat opens the copy & paste menu.
func (u *ui) mouseCapture(ev *tcell.EventMouse, a tview.MouseAction) (*tcell.EventMouse, tview.MouseAction) {
	if a == tview.MouseRightClick {
		if name, _ := u.pages.GetFrontPage(); name == "main" && u.msgs.InRect(ev.Position()) {
			u.copyMenu()
			return nil, 0
		}
	}
	return ev, a
}

func (u *ui) globalKeys(ev *tcell.EventKey) *tcell.EventKey {
	if name, _ := u.pages.GetFrontPage(); name != "main" {
		if ev.Key() == tcell.KeyEscape {
			u.closeDialog()
			return nil
		}
		if ev.Key() == tcell.KeyCtrlV { // paste into a form field
			if t, err := clipboard.ReadAll(); err == nil && t != "" {
				if f := u.app.GetFocus(); f != nil {
					f.PasteHandler()(strings.TrimRight(t, "\r\n"), func(p tview.Primitive) { u.app.SetFocus(p) })
				}
			}
			return nil
		}
		return ev
	}
	switch {
	case ev.Key() == tcell.KeyCtrlC: // copy (Ctrl+Q quits)
		if t := u.input.GetText(); t != "" {
			u.copyNote(t)
		} else {
			u.copyMenu()
		}
		return nil
	case ev.Key() == tcell.KeyCtrlX:
		if t := u.input.GetText(); t != "" {
			u.copyNote(t)
			u.input.SetText("")
		}
		return nil
	case ev.Key() == tcell.KeyCtrlV:
		u.pasteFromClipboard()
		return nil
	case ev.Key() == tcell.KeyCtrlQ:
		u.app.Stop()
		return nil
	case ev.Key() == tcell.KeyF10:
		u.chanSettings()
		return nil
	case ev.Key() == tcell.KeyF12:
		if c := u.cl.Conn(u.cur.conn); c != nil {
			if l, busy, _ := c.ChannelList(""); len(l) == 0 && !busy {
				if err := c.RequestList(""); err != nil {
					u.note("error", err.Error())
				} else {
					u.note("info", "Asking the server for its channel list… it opens when it arrives")
				}
			} else {
				u.channelList(c.ID(), "")
			}
		}
		return nil
	case ev.Key() == tcell.KeyF9:
		u.toggleMouse()
		return nil
	case ev.Key() == tcell.KeyF1:
		u.showHelp()
		return nil
	case ev.Key() == tcell.KeyF2:
		// F2: show + focus the people list (Enter on a name = menu); again = hide
		if u.showNick && u.app.GetFocus() == u.nicks {
			u.showNick = false
			u.refreshNicks()
			u.app.SetFocus(u.input)
		} else {
			u.showNick = true
			u.refreshNicks()
			u.app.SetFocus(u.nicks)
		}
		return nil
	case ev.Key() == tcell.KeyF3:
		u.mu.Lock()
		var last string
		if n := len(u.lastURLs); n > 0 {
			last = u.lastURLs[n-1]
		}
		u.mu.Unlock()
		if last != "" {
			core.OpenURL(last)
		}
		return nil
	case ev.Key() == tcell.KeyF4:
		u.transfersMenu()
		return nil
	case ev.Key() == tcell.KeyF5:
		u.serversMenu()
		return nil
	case ev.Key() == tcell.KeyF6:
		u.settingsDialog()
		return nil
	case ev.Key() == tcell.KeyF8 || ev.Key() == tcell.KeyCtrlN || isCtrlRune(ev, 'n') ||
		(ev.Modifiers()&(tcell.ModAlt|tcell.ModCtrl) != 0 && (ev.Key() == tcell.KeyRight || ev.Key() == tcell.KeyDown || ev.Key() == tcell.KeyPgDn)):
		u.moveWindow(1)
		return nil
	case ev.Key() == tcell.KeyF7 || ev.Key() == tcell.KeyCtrlP || isCtrlRune(ev, 'p') ||
		(ev.Modifiers()&(tcell.ModAlt|tcell.ModCtrl) != 0 && (ev.Key() == tcell.KeyLeft || ev.Key() == tcell.KeyUp || ev.Key() == tcell.KeyPgUp)):
		u.moveWindow(-1)
		return nil
	case ev.Modifiers()&tcell.ModAlt != 0 && ev.Rune() >= '1' && ev.Rune() <= '9':
		n := int(ev.Rune() - '1')
		u.mu.Lock()
		keys := u.sideKeys
		u.mu.Unlock()
		if n < len(keys) {
			u.switchTo(keys[n].conn, keys[n].buf)
		}
		return nil
	case ev.Key() == tcell.KeyPgUp || ev.Key() == tcell.KeyPgDn:
		u.msgs.InputHandler()(ev, nil)
		return nil
	case ev.Key() == tcell.KeyEscape:
		u.app.SetFocus(u.input)
		return nil
	}
	return ev
}

func (u *ui) inputKeys(ev *tcell.EventKey) *tcell.EventKey {
	switch ev.Key() {
	case tcell.KeyTab:
		u.complete()
		return nil
	case tcell.KeyUp:
		if len(u.history) > 0 {
			if u.histPos < len(u.history)-1 {
				u.histPos++
			}
			u.input.SetText(u.history[u.histPos])
		}
		return nil
	case tcell.KeyDown:
		if u.histPos > 0 {
			u.histPos--
			u.input.SetText(u.history[u.histPos])
		} else {
			u.histPos = -1
			u.input.SetText("")
		}
		return nil
	}
	u.tab = nil
	return ev
}

func (u *ui) complete() {
	c := u.cl.Conn(u.cur.conn)
	if c == nil {
		return
	}
	text := u.input.GetText()
	if u.tab == nil {
		i := strings.LastIndex(text, " ") + 1
		word := text[i:]
		if word == "" {
			return
		}
		nicks := c.CompleteNick(u.cur.buf, word)
		if len(nicks) == 0 {
			return
		}
		u.tab = &tabState{start: i, end: len(text), nicks: nicks, atStart: i == 0}
	} else {
		u.tab.i = (u.tab.i + 1) % len(u.tab.nicks)
	}
	n := u.tab.nicks[u.tab.i]
	if u.tab.atStart {
		n += ": "
	} else {
		n += " "
	}
	newText := text[:u.tab.start] + n
	u.tab.end = len(newText)
	u.input.SetText(newText)
}

// ---------------------------------------------------------------------------
// Typing
// ---------------------------------------------------------------------------

var helpLines = []string{
	"Keys: Enter send · Tab complete nick · ↑/↓ history · PgUp/PgDn scroll",
	"      F7 / F8 previous / next window (also Ctrl+P/Ctrl+N, Alt+Left/Right,",
	"      Ctrl+PgUp/PgDn) · Alt+1..9 jump to window · or click a channel on the left",
	"      F2 people list · F3 open last link · F4 DCC chats & transfers · F5 servers (edit, connect,",
	"         delete, add, import, export) · F12 channel list (/list)",
	"      F6 settings (nick, theme) · Esc back to typing · Ctrl+Q quit · mouse works too",
	"Copy:     Ctrl+C copies the typing box (empty box = copy menu: last message, pick a line,",
	"          a link, whole window) · Ctrl+X cut · Ctrl+V paste · right-click chat = copy menu,",
	"          right-click typing box = paste · F9 mouse off to select text with your terminal",
	"          (most terminals: Shift+drag selects even with the mouse on). Pasting several",
	"          lines asks whether to send them as separate messages.",
	"Commands: /join #chan  /part  /msg nick text  /query nick  /me text  /nick name",
	"          /topic text  /whois nick  /notice  /away  /kick  /op  /voice  /raw LINE",
	"          /connect  /disconnect  /close  /clear  /links  /open N  /logs  /theme name  /quit",
	"          /server host port [tls] [selfsigned]   (adds a new server)",
	"          /next  /prev  /win N  /win #channel   (switch windows; /win lists them)",
	"          /tabs top | bottom | left   (channel tabs, or the channel pane on the left)",
	"People:   F2 then Enter on a name (or click it): private chat, whois, CTCP version/ping/time,",
	"          direct chat, send file, op/voice, kick, ban, kick+ban (choose the ban mask)",
	"          /ban nick [1-6]  /kickban nick [1-6] [reason]  /unban mask  /bans  /kick nick reason",
	"          mask types: 1 *!*@host  2 *!*user@host  3 *!user@host  4 *!*@*.domain  5 nick!*@*  6 nick!*@host",
	"Channel:  F10 = topic, modes (+t +n +m +i +s +p), password (+k), user limit (+l), ban list",
	"CTCP:     /version nick  /ping nick  /time nick  /ctcp nick WHAT",
	"DCC:      F4 = chats & transfers (/transfers) · /dcc chat nick · /dcc send nick file · /dcc accept N",
	"          /dcc decline N · /dcc close N · /dcc list   (ports & public IP: F6 settings)",
	"Servers:  /import file [all]  (this program's file, WebIRC config, HexChat servlist.conf,",
	"          mIRC servers.ini, or one server per line; all = also nick/theme/settings)",
	"          /export file   /list [filter]   /cycle   /back   /umode +x   /motd",
	"Ignore:   /ignore nick (or *!*@host)  /unignore nick  /ignore = show list",
	"Mentions: /highlight add word · /highlight del word  (beeps when mentioned; F6 to turn off)",
	"Login:    F5 → server → Account (SASL) logs you in to NickServ while connecting",
	"Links: click a link (or /open N) to open it in your browser or picture viewer.",
}

func (u *ui) note(kind, text string) {
	c := u.cl.Conn(u.cur.conn)
	tv := u.msgs
	_ = c
	var b strings.Builder
	u.writeLine(&b, core.Line{Time: time.Now(), Kind: kind, Text: text})
	tv.Write([]byte(b.String()))
}

func (u *ui) submit() {
	text := u.input.GetText()
	if strings.TrimSpace(text) == "" {
		return
	}
	u.input.SetText("")
	u.history = append([]string{text}, u.history...)
	if len(u.history) > 100 {
		u.history = u.history[:100]
	}
	u.histPos = -1
	fields := strings.Fields(text)
	cmd := strings.ToLower(fields[0])
	c := u.cl.Conn(u.cur.conn)
	switch cmd {
	case "/help":
		for _, h := range helpLines {
			u.note("info", h)
		}
		return
	case "/quit", "/exit":
		u.app.Stop()
		return
	case "/tabs", "/layout", "/channellist":
		mode := ""
		if len(fields) > 1 {
			mode = strings.ToLower(fields[1])
		}
		switch mode {
		case "top", "bottom", "left":
		case "off", "pane":
			mode = "left"
		default:
			u.note("info", "Usage: /tabs top  ·  /tabs bottom  ·  /tabs left  (left = channel pane)")
			return
		}
		u.cl.SetGlobal(func(s *core.Settings) { s.ChanList = mode })
		u.glob = u.cl.Global()
		u.relayout()
		u.refreshAll()
		return
	case "/next", "/prev", "/previous":
		if cmd == "/next" {
			u.moveWindow(1)
		} else {
			u.moveWindow(-1)
		}
		return
	case "/win", "/window", "/go":
		u.mu.Lock()
		keys := append([]struct{ conn, buf string }(nil), u.sideKeys...)
		u.mu.Unlock()
		if len(fields) < 2 {
			for i, k := range keys {
				u.note("info", fmt.Sprintf("%d: %s", i+1, k.buf))
			}
			u.note("info", "Type /win N (number) or /win #channel to switch.")
			return
		}
		if n, err := strconv.Atoi(fields[1]); err == nil && n >= 1 && n <= len(keys) {
			u.switchTo(keys[n-1].conn, keys[n-1].buf)
			return
		}
		for _, k := range keys {
			if strings.EqualFold(k.buf, fields[1]) || strings.EqualFold("#"+strings.TrimPrefix(fields[1], "#"), k.buf) {
				u.switchTo(k.conn, k.buf)
				return
			}
		}
		u.note("error", "No such window. Type /win to list them.")
		return
	case "/clear":
		if c != nil {
			c.ClearLines(u.cur.buf)
		}
		u.rendered = -1
		u.refreshMessages()
		return
	case "/close":
		if c != nil && u.cur.buf != "*" {
			c.CloseBuffer(u.cur.buf)
			u.switchTo(u.cur.conn, "*")
		}
		return
	case "/transfers", "/dccs":
		u.transfersMenu()
		return
	case "/chanset", "/channel", "/chan":
		u.chanSettings()
		return
	case "/copy":
		u.copyMenu()
		return
	case "/logs":
		u.note("info", "Chat logs are saved in: "+u.cl.Log.Dir())
		core.OpenFolder(u.cl.Log.Dir())
		return
	case "/links":
		u.mu.Lock()
		urls := append([]string(nil), u.lastURLs...)
		u.mu.Unlock()
		if len(urls) == 0 {
			u.note("info", "No links yet.")
		}
		for i, l := range urls {
			u.note("info", fmt.Sprintf("%d: %s", i+1, l))
		}
		return
	case "/open":
		n := len(u.lastURLs)
		if len(fields) > 1 {
			n, _ = strconv.Atoi(fields[1])
		}
		u.mu.Lock()
		var link string
		if n >= 1 && n <= len(u.lastURLs) {
			link = u.lastURLs[n-1]
		}
		u.mu.Unlock()
		if link == "" {
			u.note("error", "No such link. Type /links to see them.")
		} else {
			core.OpenURL(link)
		}
		return
	case "/theme":
		if len(fields) < 2 || themes[strings.ToLower(fields[1])].bg == "" {
			u.note("info", "Themes: "+strings.Join(themeOrder, ", ")+"   e.g. /theme light")
			return
		}
		u.setTheme(strings.ToLower(fields[1]))
		return
	case "/server":
		if len(fields) < 2 {
			u.note("error", "usage: /server host port [tls] [selfsigned]   — or press F4")
			return
		}
		sc := core.ServerConfig{Host: fields[1], AutoConnect: true}
		for _, f := range fields[2:] {
			switch strings.ToLower(f) {
			case "tls", "ssl", "-tls", "+tls", "encrypted":
				sc.TLS = true
			case "selfsigned", "-selfsigned", "self-signed":
				sc.SelfSigned = true
			default:
				sc.Port, _ = strconv.Atoi(strings.TrimPrefix(f, "+"))
			}
		}
		nc, err := u.cl.AddServer(sc)
		if err != nil {
			u.note("error", err.Error())
			return
		}
		u.switchTo(nc.ID(), "*")
		return
	}
	if handled, out, err := u.cl.GlobalCommand(text); handled {
		if err != nil {
			u.note("error", err.Error())
		} else {
			u.note("info", out)
		}
		u.glob = u.cl.Global()
		u.refreshAll()
		return
	}
	if c == nil {
		u.note("error", "No server yet — press F5 for the Servers menu (add or import).")
		return
	}
	sw, err := c.Input(u.cur.buf, text)
	if err != nil {
		u.note("error", err.Error())
		return
	}
	if sw != "" {
		go func() {
			for i := 0; i < 25; i++ {
				if _, ok := c.Buffer(sw); ok {
					u.app.QueueUpdateDraw(func() { u.switchTo(u.cur.conn, sw) })
					return
				}
				time.Sleep(200 * time.Millisecond)
			}
		}()
	}
}

func (u *ui) setTheme(name string) {
	u.cl.SetGlobal(func(s *core.Settings) { s.Theme = name })
	u.glob = u.cl.Global()
	u.applyTheme(name)
	u.refreshAll()
}

// ---------------------------------------------------------------------------
// Dialogs
// ---------------------------------------------------------------------------

func (u *ui) modal(p tview.Primitive, w, h int) {
	grid := tview.NewGrid().SetColumns(0, w, 0).SetRows(0, h, 0).AddItem(p, 1, 1, 1, 1, 0, 0, true)
	u.pages.AddPage("dialog", grid, true, true)
	u.app.SetFocus(p)
}

func (u *ui) closeDialog() {
	u.pages.RemovePage("dialog")
	u.app.SetFocus(u.input)
}

func (u *ui) styleForm(f *tview.Form) {
	c := tcell.GetColor
	f.SetBackgroundColor(c(u.th.panel))
	f.SetFieldStyle(tcell.StyleDefault.Background(c(u.th.bg)).Foreground(c(u.th.fg))).SetLabelColor(c(u.th.fg))
	f.SetButtonStyle(tcell.StyleDefault.Background(c(u.th.accent)).Foreground(c(u.th.bg)))
	f.SetBorder(true).SetBorderColor(c(u.th.accent))
	f.SetTitleColor(c(u.th.accent))
}

func (u *ui) showHelp() {
	tv := tview.NewTextView().SetDynamicColors(true).SetWrap(true)
	tv.SetText(strings.Join(helpLines, "\n") + "\n\n[::d]Settings file: " + tview.Escape(u.cl.Path()) + "\nLogs folder:   " + tview.Escape(u.cl.Log.Dir()) + "\n\nPress Esc to close.")
	tv.SetTextStyle(tcell.StyleDefault.Background(tcell.GetColor(u.th.panel)).Foreground(tcell.GetColor(u.th.fg)))
	tv.SetBorder(true).SetTitle(" Help ").SetBackgroundColor(tcell.GetColor(u.th.panel))
	tv.SetDoneFunc(func(tcell.Key) { u.closeDialog() })
	u.modal(tv, 92, 18)
}

func (u *ui) serverDialog(c *core.Conn) {
	sc := core.ServerConfig{TLS: true, AutoConnect: true}
	title := " Add IRC server "
	if c != nil {
		sc = c.Config()
		title = " Server settings: " + sc.DisplayName() + " "
	}
	f := tview.NewForm()
	f.AddInputField("Name", sc.Name, 40, nil, func(t string) { sc.Name = t })
	f.AddInputField("Server address", sc.Host, 40, nil, func(t string) { sc.Host = t })
	portText := ""
	if c != nil {
		portText = strconv.Itoa(sc.EffectivePort())
	}
	f.AddInputField("Port (empty = 6697 encrypted / 6667 plain)", portText, 8, tview.InputFieldInteger, func(t string) { sc.Port, _ = strconv.Atoi(t) })
	f.AddCheckbox("Encrypted (TLS/SSL)", sc.TLS, func(b bool) { sc.TLS = b })
	f.AddCheckbox("Allow self-signed certificate", sc.SelfSigned, func(b bool) { sc.SelfSigned = b })
	f.AddInputField("Server username (ZNC/bouncer)", sc.ServerUser, 30, nil, func(t string) { sc.ServerUser = strings.TrimSpace(t) })
	f.AddPasswordField("Server password", sc.Password, 30, '*', func(t string) { sc.Password = t })
	f.AddInputField("Account (SASL login, optional)", sc.SASLUser, 30, nil, func(t string) { sc.SASLUser = strings.TrimSpace(t) })
	f.AddPasswordField("Account password", sc.SASLPass, 30, '*', func(t string) { sc.SASLPass = t })
	f.AddInputField("Nickname (empty = default)", sc.Nick, 20, nil, func(t string) { sc.Nick = t })
	f.AddInputField("Channels (comma separated)", strings.Join(sc.Channels, ", "), 40, nil, func(t string) {
		sc.Channels = strings.Split(t, ",")
	})
	f.AddTextArea("Commands to run when connected", strings.Join(sc.Commands, "\n"), 50, 4, 0, func(t string) {
		sc.Commands = strings.Split(t, "\n")
	})
	f.AddCheckbox("Connect when program starts", sc.AutoConnect, func(b bool) { sc.AutoConnect = b })
	f.AddButton("Save", func() {
		var err error
		if c == nil {
			var nc *core.Conn
			if nc, err = u.cl.AddServer(sc); err == nil {
				u.closeDialog()
				u.switchTo(nc.ID(), "*")
				return
			}
		} else if err = u.cl.UpdateServer(sc); err == nil {
			u.closeDialog()
			u.refreshAll()
			return
		}
		f.SetTitle(" ⚠ " + err.Error() + " ")
	})
	if c != nil {
		f.AddButton("Connect", func() { c.Connect(); u.closeDialog() })
		f.AddButton("Disconnect", func() { c.Disconnect("Leaving"); u.closeDialog() })
		f.AddButton("Delete", func() {
			u.cl.RemoveServer(sc.ID)
			u.closeDialog()
			if cs := u.cl.Conns(); len(cs) > 0 {
				u.switchTo(cs[0].ID(), "*")
			} else {
				u.cur.conn = ""
				u.refreshAll()
			}
		})
	}
	f.AddButton("Cancel", u.closeDialog)
	f.SetTitle(title)
	u.styleForm(f)
	f.SetItemPadding(0)
	u.modal(f, 84, 24)
}

func (u *ui) settingsDialog() {
	g := u.cl.Global()
	f := tview.NewForm()
	f.AddInputField("Nickname", g.Nick, 20, nil, func(t string) { g.Nick = strings.TrimSpace(t) })
	f.AddInputField("Backup nickname", g.AltNick, 20, nil, func(t string) { g.AltNick = strings.TrimSpace(t) })
	f.AddInputField("Real name", g.Realname, 30, nil, func(t string) { g.Realname = t })
	cur := 0
	for i, t := range themeOrder {
		if t == g.Theme {
			cur = i
		}
	}
	f.AddDropDown("Theme", themeOrder, cur, func(o string, _ int) { g.Theme = o })
	listOpts := []string{"Left pane", "Tabs on top", "Tabs on bottom"}
	listVals := []string{"left", "top", "bottom"}
	listCur := 0
	for i, v := range listVals {
		if v == g.ChanList {
			listCur = i
		}
	}
	f.AddDropDown("Channel list", listOpts, listCur, func(_ string, i int) {
		if i >= 0 {
			g.ChanList = listVals[i]
		}
	})
	f.AddCheckbox("Show picture/video links", g.ShowMedia, func(b bool) { g.ShowMedia = b })
	f.AddCheckbox("Show join/part messages", g.ShowJoins, func(b bool) { g.ShowJoins = b })
	f.AddCheckbox("Save chat logs (logs folder)", g.Logging, func(b bool) { g.Logging = b })
	f.AddInputField("DCC ports (e.g. 5000-5010)", g.DCCPorts, 14, nil, func(t string) { g.DCCPorts = strings.TrimSpace(t) })
	f.AddInputField("DCC public IP (empty = auto)", g.DCCIP, 24, nil, func(t string) { g.DCCIP = strings.TrimSpace(t) })
	f.AddInputField("Downloads folder", g.Downloads, 30, nil, func(t string) { g.Downloads = strings.TrimSpace(t) })
	f.AddCheckbox("Beep when someone mentions me", g.Notify, func(b bool) { g.Notify = b })
	f.AddInputField("Highlight words (comma sep.)", strings.Join(g.Highlights, ", "), 36, nil, func(t string) { g.Highlights = splitList(t) })
	f.AddInputField("Ignore list (comma sep.)", strings.Join(g.Ignores, ", "), 36, nil, func(t string) { g.Ignores = splitList(t) })
	f.AddButton("Save", func() {
		if g.Nick == "" {
			f.SetTitle(" ⚠ Nickname can't be empty ")
			return
		}
		if _, _, err := core.ParsePortRange(g.DCCPorts); err != nil {
			f.SetTitle(" ⚠ " + err.Error() + " ")
			return
		}
		u.cl.SetGlobal(func(s *core.Settings) {
			s.Nick, s.AltNick, s.Realname, s.Theme, s.ShowMedia, s.ShowJoins, s.Logging = g.Nick, g.AltNick, g.Realname, g.Theme, g.ShowMedia, g.ShowJoins, g.Logging
			s.ChanList = g.ChanList
			s.DCCPorts, s.DCCIP, s.Downloads = g.DCCPorts, g.DCCIP, g.Downloads
			s.Notify, s.Highlights, s.Ignores = g.Notify, g.Highlights, g.Ignores
		})
		u.glob = u.cl.Global()
		u.closeDialog()
		u.relayout()
		u.applyTheme(g.Theme)
		u.refreshAll()
	})
	f.AddButton("Cancel", u.closeDialog)
	f.SetTitle(" Settings (saved to " + shortPath(u.cl.Path()) + ") ")
	u.styleForm(f)
	f.SetItemPadding(0)
	u.modal(f, 76, 22)
}

func shortPath(p string) string {
	if i := strings.LastIndexAny(p, `/\`); i >= 0 {
		return p[i+1:]
	}
	return p
}

var _ = sort.Strings

// isCtrlRune matches Ctrl+letter when a terminal reports it as a letter
// with the Ctrl modifier instead of a control code.
func isCtrlRune(ev *tcell.EventKey, r rune) bool {
	return ev.Key() == tcell.KeyRune && ev.Modifiers()&tcell.ModCtrl != 0 && (ev.Rune() == r || ev.Rune() == r-32)
}

type newLine struct {
	k  string
	hl bool
}

func sleepMS(ms int) { time.Sleep(time.Duration(ms) * time.Millisecond) }
