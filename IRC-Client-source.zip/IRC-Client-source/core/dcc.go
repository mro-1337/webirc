package core

// DCC CHAT and DCC SEND (direct connections between two people).
//
// Sending: we listen on a port (from the "dccports" range in the settings)
// and tell the other person our IP and port; they connect to us.
// Receiving: the other side tells us their IP and port and we connect —
// or, for a "passive" offer (port 0), we listen and they connect to us.
// Nothing is ever accepted automatically.

import (
	"bufio"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
	"unicode"
)

const dccOfferTimeout = 5 * time.Minute

type dccItem struct {
	mu      sync.Mutex
	id      int
	conn    *Conn
	nick    string
	kind    string // "send", "receive", "chat-out", "chat-in"
	file    string // name as offered
	path    string // file on this computer
	size    int64
	done    int64
	state   string // offered, waiting, connecting, active, done, failed, declined, cancelled
	err     string
	started time.Time
	ended   time.Time
	ip      string
	port    int
	token   string
	ln      net.Listener
	sock    net.Conn
	emitted time.Time
}

type dccManager struct {
	mu    sync.Mutex
	items []*dccItem
	next  int
}

// DCCInfo describes a DCC chat or file transfer for the screen.
type DCCInfo struct {
	ID       int
	ConnID   string
	Nick     string
	Kind     string // send, receive, chat-out, chat-in
	File     string
	Path     string
	Size     int64
	Done     int64
	State    string
	Err      string
	Speed    float64 // bytes per second
	Started  time.Time
	Finished bool
	IsOffer  bool // waiting for you to accept or decline
	ChatWin  string
}

func (it *dccItem) info() DCCInfo {
	it.mu.Lock()
	defer it.mu.Unlock()
	d := DCCInfo{ID: it.id, ConnID: it.conn.id, Nick: it.nick, Kind: it.kind, File: it.file, Path: it.path,
		Size: it.size, Done: it.done, State: it.state, Err: it.err, Started: it.started,
		IsOffer: it.state == "offered"}
	switch it.state {
	case "done", "failed", "declined", "cancelled", "closed":
		d.Finished = true
	}
	if strings.HasPrefix(it.kind, "chat") {
		d.ChatWin = "=" + it.nick
	}
	if !it.started.IsZero() && it.done > 0 {
		end := time.Now()
		if !it.ended.IsZero() {
			end = it.ended
		}
		if secs := end.Sub(it.started).Seconds(); secs > 0 {
			d.Speed = float64(it.done) / secs
		}
	}
	return d
}

func (cl *Client) dccAdd(it *dccItem) {
	cl.dcc.mu.Lock()
	cl.dcc.next++
	it.id = cl.dcc.next
	cl.dcc.items = append(cl.dcc.items, it)
	cl.dcc.mu.Unlock()
}

func (cl *Client) dccFind(id int) *dccItem {
	cl.dcc.mu.Lock()
	defer cl.dcc.mu.Unlock()
	for _, it := range cl.dcc.items {
		if it.id == id {
			return it
		}
	}
	return nil
}

// Transfers lists all DCC chats and file transfers (newest last).
func (cl *Client) Transfers() []DCCInfo {
	cl.dcc.mu.Lock()
	items := append([]*dccItem(nil), cl.dcc.items...)
	cl.dcc.mu.Unlock()
	out := make([]DCCInfo, 0, len(items))
	for _, it := range items {
		out = append(out, it.info())
	}
	return out
}

func (cl *Client) DCCInfo(id int) (DCCInfo, bool) {
	if it := cl.dccFind(id); it != nil {
		return it.info(), true
	}
	return DCCInfo{}, false
}

// ClearFinishedDCC removes finished items from the list.
func (cl *Client) ClearFinishedDCC() {
	cl.dcc.mu.Lock()
	keep := cl.dcc.items[:0]
	for _, it := range cl.dcc.items {
		if !it.info().Finished {
			keep = append(keep, it)
		}
	}
	cl.dcc.items = keep
	cl.dcc.mu.Unlock()
	cl.emit(Event{Kind: EvDCC})
}

func (it *dccItem) set(f func()) {
	it.mu.Lock()
	f()
	it.mu.Unlock()
	it.conn.cl.emit(Event{Kind: EvDCC, Conn: it.conn, DCC: it.id})
}

// note writes a line in the server window (and the person's private window if open).
func (c *Conn) dccNote(nick, kind, text string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.dccNoteLocked(nick, kind, text)
}

func (c *Conn) dccNoteLocked(nick, kind, text string) {
	c.addLine(c.buffers["*"], Line{Kind: kind, Text: "DCC: " + text})
	if b, ok := c.buffers[strings.ToLower(nick)]; ok && b.Kind == "query" {
		c.addLine(b, Line{Kind: kind, Text: "DCC: " + text})
	}
}

func (m *dccManager) close(it *dccItem, state string) {
	it.mu.Lock()
	if it.ln != nil {
		it.ln.Close()
	}
	if it.sock != nil {
		it.sock.Close()
	}
	if it.state != "done" && it.state != "failed" {
		it.state = state
	}
	if it.ended.IsZero() {
		it.ended = time.Now()
	}
	it.mu.Unlock()
	it.conn.cl.emit(Event{Kind: EvDCC, Conn: it.conn, DCC: it.id})
}

func (it *dccItem) fail(err error) {
	it.mu.Lock()
	if it.state == "cancelled" || it.state == "declined" || it.state == "closed" {
		it.mu.Unlock()
		return
	}
	it.state, it.err, it.ended = "failed", err.Error(), time.Now()
	nick, kind, file := it.nick, it.kind, it.file
	it.mu.Unlock()
	it.conn.cl.dcc.close(it, "failed")
	what := "file " + file
	if strings.HasPrefix(kind, "chat") {
		what = "chat"
	}
	it.conn.dccNote(nick, "error", fmt.Sprintf("%s with %s failed: %v", what, nick, err))
}

// ---------------------------------------------------------------------------
// Settings: port range, IP, downloads folder
// ---------------------------------------------------------------------------

// DownloadsDir is where received files are saved (next to the program by default).
func (cl *Client) DownloadsDir() string {
	g := cl.Global()
	dir := strings.TrimSpace(g.Downloads)
	if dir == "" {
		dir = filepath.Join(filepath.Dir(cl.path), "downloads")
	} else if !filepath.IsAbs(dir) {
		dir = filepath.Join(filepath.Dir(cl.path), dir)
	}
	return dir
}

// ParsePortRange reads "5000-5010", "5000" or "" (any free port).
func ParsePortRange(s string) (lo, hi int, err error) {
	s = strings.TrimSpace(s)
	if s == "" || s == "0" || strings.EqualFold(s, "any") {
		return 0, 0, nil
	}
	a, b, isRange := strings.Cut(s, "-")
	lo, err1 := strconv.Atoi(strings.TrimSpace(a))
	hi = lo
	var err2 error
	if isRange {
		hi, err2 = strconv.Atoi(strings.TrimSpace(b))
	}
	if err1 != nil || err2 != nil || lo < 1 || hi > 65535 || hi < lo {
		return 0, 0, fmt.Errorf("DCC ports must look like 5000-5010 (or one port, or empty for any)")
	}
	return lo, hi, nil
}

func (cl *Client) dccListen() (net.Listener, int, error) {
	lo, hi, err := ParsePortRange(cl.Global().DCCPorts)
	if err != nil {
		return nil, 0, err
	}
	if lo == 0 {
		ln, err := net.Listen("tcp", ":0")
		if err != nil {
			return nil, 0, err
		}
		return ln, ln.Addr().(*net.TCPAddr).Port, nil
	}
	for p := lo; p <= hi; p++ {
		if ln, err := net.Listen("tcp", ":"+strconv.Itoa(p)); err == nil {
			return ln, p, nil
		}
	}
	return nil, 0, fmt.Errorf("all DCC ports %d-%d are in use — widen the range in Settings", lo, hi)
}

// dccMyIP is the address we tell people to connect to.
func (c *Conn) dccMyIP() (string, error) {
	if s := strings.TrimSpace(c.cl.Global().DCCIP); s != "" {
		if ip := net.ParseIP(s); ip != nil {
			return encodeDCCIP(ip), nil
		}
		ips, err := net.LookupIP(s)
		if err != nil || len(ips) == 0 {
			return "", fmt.Errorf("can't look up the DCC IP/host %q from Settings", s)
		}
		for _, ip := range ips {
			if ip.To4() != nil {
				return encodeDCCIP(ip), nil
			}
		}
		return encodeDCCIP(ips[0]), nil
	}
	c.mu.Lock()
	sock := c.sock
	c.mu.Unlock()
	if sock == nil {
		return "", errors.New("not connected")
	}
	host, _, _ := net.SplitHostPort(sock.LocalAddr().String())
	ip := net.ParseIP(host)
	if ip == nil {
		return "", errors.New("can't find this computer's IP address")
	}
	return encodeDCCIP(ip), nil
}

func encodeDCCIP(ip net.IP) string {
	if ip4 := ip.To4(); ip4 != nil {
		return strconv.FormatUint(uint64(binary.BigEndian.Uint32(ip4)), 10)
	}
	return ip.String()
}

func decodeDCCIP(s string) string {
	if n, err := strconv.ParseUint(s, 10, 32); err == nil {
		b := make([]byte, 4)
		binary.BigEndian.PutUint32(b, uint32(n))
		return net.IP(b).String()
	}
	return s
}

func isPrivateIP(s string) bool {
	ip := net.ParseIP(s)
	return ip != nil && (ip.IsPrivate() || ip.IsLoopback() || ip.IsLinkLocalUnicast())
}

// ---------------------------------------------------------------------------
// Offers from other people
// ---------------------------------------------------------------------------

// splitDCC splits "SEND "my file.txt" 3232235777 5000 1234 [token]".
func splitDCC(rest string) []string {
	var out []string
	rest = strings.TrimSpace(rest)
	for rest != "" {
		if rest[0] == '"' {
			end := strings.IndexByte(rest[1:], '"')
			if end >= 0 {
				out = append(out, rest[1:end+1])
				rest = strings.TrimSpace(rest[end+2:])
				continue
			}
		}
		f, r, _ := strings.Cut(rest, " ")
		out = append(out, f)
		rest = strings.TrimSpace(r)
	}
	return out
}

// dccIncoming handles a CTCP DCC from someone. The caller holds c.mu.
func (cl *Client) dccIncoming(c *Conn, from, rest string) {
	f := splitDCC(rest)
	if len(f) < 1 {
		return
	}
	switch strings.ToUpper(f[0]) {
	case "SEND":
		if len(f) < 4 {
			return
		}
		port, _ := strconv.Atoi(f[3])
		var size int64
		if len(f) > 4 {
			size, _ = strconv.ParseInt(f[4], 10, 64)
		}
		token := ""
		if len(f) > 5 {
			token = f[5]
		}
		// Reply to a passive offer we made isn't supported; this is a new offer.
		it := &dccItem{conn: c, nick: from, kind: "receive", file: cleanFileName(f[1]), size: size,
			state: "offered", ip: decodeDCCIP(f[2]), port: port, token: token}
		cl.dccAdd(it)
		c.dccNoteLocked(from, "info", fmt.Sprintf("%s wants to send you %q (%s). Type /dcc accept %d or /dcc decline %d",
			from, it.file, HumanSize(size), it.id, it.id))
		cl.emit(Event{Kind: EvDCCOffer, Conn: c, DCC: it.id})
	case "CHAT":
		if len(f) < 4 {
			return
		}
		port, _ := strconv.Atoi(f[3])
		token := ""
		if len(f) > 4 {
			token = f[4]
		}
		it := &dccItem{conn: c, nick: from, kind: "chat-in", state: "offered",
			ip: decodeDCCIP(f[2]), port: port, token: token}
		cl.dccAdd(it)
		c.dccNoteLocked(from, "info", fmt.Sprintf("%s wants a direct (DCC) chat. Type /dcc accept %d or /dcc decline %d", from, it.id, it.id))
		cl.emit(Event{Kind: EvDCCOffer, Conn: c, DCC: it.id})
	case "ACCEPT", "RESUME":
		c.dccNoteLocked(from, "info", from+" asked to resume a transfer — resuming isn't supported, the file will be sent from the start")
	}
}

// AcceptDCC accepts an offered file or chat.
func (cl *Client) AcceptDCC(id int) error {
	it := cl.dccFind(id)
	if it == nil {
		return errors.New("no such DCC offer")
	}
	it.mu.Lock()
	if it.state != "offered" {
		it.mu.Unlock()
		return errors.New("that DCC isn't waiting to be accepted")
	}
	it.state = "connecting"
	passive := it.port == 0
	it.mu.Unlock()
	cl.emit(Event{Kind: EvDCC, Conn: it.conn, DCC: id})
	if it.kind == "receive" {
		dir := cl.DownloadsDir()
		if err := os.MkdirAll(dir, 0700); err != nil {
			it.fail(err)
			return err
		}
		it.mu.Lock()
		it.path = uniquePath(dir, it.file)
		it.mu.Unlock()
	}
	go func() {
		var sock net.Conn
		var err error
		if passive { // they're behind a router: we listen, they connect to us
			sock, err = cl.passiveAccept(it)
		} else {
			if isPrivateIP(it.ip) {
				it.conn.dccNote(it.nick, "info", fmt.Sprintf("note: %s offered a private address (%s) — this only works on the same network", it.nick, it.ip))
			}
			sock, err = net.DialTimeout("tcp", net.JoinHostPort(it.ip, strconv.Itoa(it.port)), 25*time.Second)
		}
		if err != nil {
			it.fail(err)
			return
		}
		cl.dccRun(it, sock)
	}()
	return nil
}

func (cl *Client) passiveAccept(it *dccItem) (net.Conn, error) {
	ln, port, err := cl.dccListen()
	if err != nil {
		return nil, err
	}
	ip, err := it.conn.dccMyIP()
	if err != nil {
		ln.Close()
		return nil, err
	}
	it.mu.Lock()
	it.ln = ln
	it.mu.Unlock()
	if it.kind == "receive" {
		it.conn.writeLine(fmt.Sprintf("PRIVMSG %s :\x01DCC SEND %s %s %d %d %s\x01", it.nick, quoteName(it.file), ip, port, it.size, it.token))
	} else {
		it.conn.writeLine(fmt.Sprintf("PRIVMSG %s :\x01DCC CHAT chat %s %d %s\x01", it.nick, ip, port, it.token))
	}
	return acceptWithin(ln, dccOfferTimeout)
}

func acceptWithin(ln net.Listener, d time.Duration) (net.Conn, error) {
	if tl, ok := ln.(*net.TCPListener); ok {
		tl.SetDeadline(time.Now().Add(d))
	}
	sock, err := ln.Accept()
	ln.Close()
	if err != nil {
		if ne, ok := err.(net.Error); ok && ne.Timeout() {
			return nil, errors.New("they didn't connect in time (check firewall / port forwarding for your DCC ports)")
		}
		return nil, err
	}
	return sock, nil
}

func (cl *Client) DeclineDCC(id int) {
	if it := cl.dccFind(id); it != nil {
		it.mu.Lock()
		offered := it.state == "offered"
		it.mu.Unlock()
		if offered {
			cl.dcc.close(it, "declined")
			it.conn.dccNote(it.nick, "info", fmt.Sprintf("declined DCC #%d from %s", id, it.nick))
		}
	}
}

// CancelDCC stops a transfer or chat.
func (cl *Client) CancelDCC(id int) {
	if it := cl.dccFind(id); it != nil {
		cl.dcc.close(it, "cancelled")
		it.conn.mu.Lock()
		delete(it.conn.dccChats, strings.ToLower("="+it.nick))
		it.conn.mu.Unlock()
	}
}

// ---------------------------------------------------------------------------
// Offering a chat / file
// ---------------------------------------------------------------------------

// OfferChat invites someone to a direct (DCC) chat.
func (c *Conn) OfferChat(nick string) (int, error) {
	return c.offer(nick, "chat-out", "", 0)
}

// OfferFile offers a file to someone.
func (c *Conn) OfferFile(nick, path string) (int, error) {
	st, err := os.Stat(path)
	if err != nil {
		return 0, err
	}
	if st.IsDir() {
		return 0, errors.New("that's a folder — pick a file")
	}
	return c.offer(nick, "send", path, st.Size())
}

func (c *Conn) offer(nick, kind, path string, size int64) (int, error) {
	if err := c.online(); err != nil {
		return 0, err
	}
	ip, err := c.dccMyIP()
	if err != nil {
		return 0, err
	}
	ln, port, err := c.cl.dccListen()
	if err != nil {
		return 0, err
	}
	it := &dccItem{conn: c, nick: nick, kind: kind, path: path, file: filepath.Base(path), size: size,
		state: "waiting", ln: ln, port: port}
	c.cl.dccAdd(it)
	if kind == "send" {
		c.writeLine(fmt.Sprintf("PRIVMSG %s :\x01DCC SEND %s %s %d %d\x01", nick, quoteName(it.file), ip, port, size))
		c.dccNote(nick, "info", fmt.Sprintf("offered %q (%s) to %s on port %d — waiting for them to accept", it.file, HumanSize(size), nick, port))
	} else {
		c.writeLine(fmt.Sprintf("PRIVMSG %s :\x01DCC CHAT chat %s %d\x01", nick, ip, port))
		c.dccNote(nick, "info", fmt.Sprintf("asked %s for a direct chat on port %d — waiting for them to accept", nick, port))
	}
	if isPrivateIP(decodeDCCIP(ip)) {
		c.dccNote(nick, "info", "your IP looks private ("+decodeDCCIP(ip)+"): people outside your network can only connect if you set your public IP in Settings and forward your DCC ports on your router")
	}
	c.cl.emit(Event{Kind: EvDCC, Conn: c, DCC: it.id})
	go func() {
		sock, err := acceptWithin(ln, dccOfferTimeout)
		if err != nil {
			it.fail(err)
			return
		}
		c.cl.dccRun(it, sock)
	}()
	return it.id, nil
}

// ---------------------------------------------------------------------------
// Running a connection
// ---------------------------------------------------------------------------

func (cl *Client) dccRun(it *dccItem, sock net.Conn) {
	it.mu.Lock()
	if it.state == "cancelled" {
		it.mu.Unlock()
		sock.Close()
		return
	}
	it.sock, it.state, it.started = sock, "active", time.Now()
	it.mu.Unlock()
	cl.emit(Event{Kind: EvDCC, Conn: it.conn, DCC: it.id})
	switch it.kind {
	case "send":
		cl.dccSendFile(it, sock)
	case "receive":
		cl.dccReceiveFile(it, sock)
	default:
		cl.dccChat(it, sock)
	}
}

func (it *dccItem) progress(n int64) {
	it.mu.Lock()
	it.done += n
	emit := time.Since(it.emitted) > 250*time.Millisecond
	if emit {
		it.emitted = time.Now()
	}
	it.mu.Unlock()
	if emit {
		it.conn.cl.emit(Event{Kind: EvDCC, Conn: it.conn, DCC: it.id})
	}
}

func (it *dccItem) finish() {
	it.set(func() { it.state, it.ended = "done", time.Now() })
}

func (cl *Client) dccSendFile(it *dccItem, sock net.Conn) {
	defer sock.Close()
	f, err := os.Open(it.path)
	if err != nil {
		it.fail(err)
		return
	}
	defer f.Close()
	it.conn.dccNote(it.nick, "info", fmt.Sprintf("sending %q to %s…", it.file, it.nick))
	acked := make(chan struct{})
	go func() { // read (and ignore) the 4-byte "received so far" acknowledgements
		defer close(acked)
		var b [4]byte
		for {
			if _, err := io.ReadFull(sock, b[:]); err != nil {
				return
			}
			if int64(binary.BigEndian.Uint32(b[:])) == it.size&0xffffffff {
				return
			}
		}
	}()
	buf := make([]byte, 64*1024)
	for {
		n, rerr := f.Read(buf)
		if n > 0 {
			sock.SetWriteDeadline(time.Now().Add(2 * time.Minute))
			if _, err := sock.Write(buf[:n]); err != nil {
				it.fail(fmt.Errorf("connection lost: %v", err))
				return
			}
			it.progress(int64(n))
		}
		if rerr == io.EOF {
			break
		}
		if rerr != nil {
			it.fail(rerr)
			return
		}
	}
	select { // give them a moment to confirm they got everything
	case <-acked:
	case <-time.After(30 * time.Second):
	}
	it.finish()
	it.conn.dccNote(it.nick, "info", fmt.Sprintf("finished sending %q to %s (%s)", it.file, it.nick, HumanSize(it.size)))
}

func (cl *Client) dccReceiveFile(it *dccItem, sock net.Conn) {
	defer sock.Close()
	f, err := os.OpenFile(it.path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if err != nil {
		it.fail(err)
		return
	}
	it.conn.dccNote(it.nick, "info", fmt.Sprintf("receiving %q from %s…", it.file, it.nick))
	w := bufio.NewWriterSize(f, 256*1024)
	buf := make([]byte, 64*1024)
	var total int64
	var ack [4]byte
	for {
		sock.SetReadDeadline(time.Now().Add(3 * time.Minute))
		n, rerr := sock.Read(buf)
		if n > 0 {
			if _, err := w.Write(buf[:n]); err != nil {
				f.Close()
				it.fail(err)
				return
			}
			total += int64(n)
			it.progress(int64(n))
			binary.BigEndian.PutUint32(ack[:], uint32(total))
			sock.Write(ack[:])
		}
		if it.size > 0 && total >= it.size {
			break
		}
		if rerr != nil {
			if rerr == io.EOF && (it.size == 0 || total >= it.size) {
				break
			}
			w.Flush()
			f.Close()
			if rerr == io.EOF {
				rerr = fmt.Errorf("the other side stopped early (%s of %s)", HumanSize(total), HumanSize(it.size))
			}
			it.fail(rerr)
			return
		}
	}
	w.Flush()
	f.Close()
	it.finish()
	it.conn.dccNote(it.nick, "info", fmt.Sprintf("received %q from %s (%s) — saved to %s", it.file, it.nick, HumanSize(total), it.path))
}

func (cl *Client) dccChat(it *dccItem, sock net.Conn) {
	c := it.conn
	win := "=" + it.nick
	k := strings.ToLower(win)
	c.mu.Lock()
	if old := c.dccChats[k]; old != nil && old != it {
		go cl.dcc.close(old, "closed")
	}
	c.dccChats[k] = it
	b := c.getBuf(win, "dcc", true)
	b.Name, b.Joined = win, true
	c.addLine(b, Line{Kind: "info", Text: "Direct (DCC) chat with " + it.nick + " started. Messages go straight to them, not through the server."})
	c.mu.Unlock()
	c.emitNet()
	sc := bufio.NewScanner(sock)
	sc.Buffer(make([]byte, 16*1024), 16*1024)
	for sc.Scan() {
		text := strings.TrimRight(sc.Text(), "\r")
		kind := "msg"
		if strings.HasPrefix(text, "\x01ACTION ") {
			kind, text = "action", strings.TrimSuffix(strings.TrimPrefix(text, "\x01ACTION "), "\x01")
		}
		c.mu.Lock()
		b := c.getBuf(win, "dcc", true)
		c.addLine(b, Line{Kind: kind, Nick: it.nick, Text: text})
		c.mu.Unlock()
	}
	c.mu.Lock()
	if c.dccChats[k] == it {
		delete(c.dccChats, k)
	}
	if b := c.buffers[k]; b != nil {
		b.Joined = false
		c.addLine(b, Line{Kind: "info", Text: "Direct chat with " + it.nick + " ended."})
	}
	c.mu.Unlock()
	cl.dcc.close(it, "closed")
	c.emitNet()
}

// dccSay sends a line in a DCC chat window ("=nick").
func (c *Conn) dccSay(win, kind, text string) error {
	c.mu.Lock()
	it := c.dccChats[strings.ToLower(win)]
	nick := c.nick
	c.mu.Unlock()
	if it == nil {
		return errors.New("this direct chat isn't connected — start a new one with /dcc chat " + strings.TrimPrefix(win, "="))
	}
	it.mu.Lock()
	sock := it.sock
	it.mu.Unlock()
	for _, l := range strings.Split(text, "\n") {
		if strings.TrimSpace(l) == "" {
			continue
		}
		out := l
		if kind == "action" {
			out = "\x01ACTION " + l + "\x01"
		}
		sock.SetWriteDeadline(time.Now().Add(30 * time.Second))
		if _, err := io.WriteString(sock, out+"\n"); err != nil {
			return err
		}
		c.mu.Lock()
		b := c.getBuf(win, "dcc", true)
		c.addLine(b, Line{Kind: kind, Nick: nick, Text: l, Self: true})
		c.mu.Unlock()
	}
	return nil
}

// ---------------------------------------------------------------------------
// /dcc command
// ---------------------------------------------------------------------------

const dccHelp = "usage: /dcc chat nick · /dcc send nick file · /dcc accept N · /dcc decline N · /dcc close N · /dcc list"

func (c *Conn) dccCommand(target, rest string) (string, error) {
	sub, args, _ := strings.Cut(strings.TrimSpace(rest), " ")
	args = strings.TrimSpace(args)
	num := func() (int, error) {
		n, err := strconv.Atoi(strings.TrimPrefix(args, "#"))
		if err != nil {
			return 0, errors.New("give the DCC number, e.g. /dcc " + strings.ToLower(sub) + " 3 (see /dcc list)")
		}
		return n, nil
	}
	switch strings.ToLower(sub) {
	case "chat":
		if args == "" {
			return "", errors.New("usage: /dcc chat nick")
		}
		_, err := c.OfferChat(strings.Fields(args)[0])
		return "", err
	case "send":
		nick, file, _ := strings.Cut(args, " ")
		file = strings.Trim(strings.TrimSpace(file), "\"")
		if nick == "" || file == "" {
			return "", errors.New("usage: /dcc send nick path/to/file")
		}
		if !filepath.IsAbs(file) {
			if _, err := os.Stat(file); err != nil {
				file = filepath.Join(filepath.Dir(c.cl.path), file)
			}
		}
		_, err := c.OfferFile(nick, file)
		return "", err
	case "accept", "get":
		n, err := num()
		if err != nil {
			return "", err
		}
		if err := c.cl.AcceptDCC(n); err != nil {
			return "", err
		}
		if d, ok := c.cl.DCCInfo(n); ok && d.ChatWin != "" {
			return d.ChatWin, nil
		}
		return "", nil
	case "decline", "reject":
		n, err := num()
		if err != nil {
			return "", err
		}
		c.cl.DeclineDCC(n)
		return "", nil
	case "close", "cancel", "stop":
		n, err := num()
		if err != nil {
			return "", err
		}
		c.cl.CancelDCC(n)
		return "", nil
	case "list", "":
		list := c.cl.Transfers()
		if len(list) == 0 {
			c.dccNote("", "info", "no DCC chats or transfers")
		}
		for _, d := range list {
			c.dccNote("", "info", DescribeDCC(d))
		}
		return "", nil
	}
	return "", errors.New(dccHelp)
}

// DescribeDCC is a one-line description of a transfer or chat.
func DescribeDCC(d DCCInfo) string {
	who := map[string]string{"send": "to", "receive": "from", "chat-out": "with", "chat-in": "with"}[d.Kind]
	what := fmt.Sprintf("%q", d.File)
	if strings.HasPrefix(d.Kind, "chat") {
		what = "chat"
	}
	s := fmt.Sprintf("#%d %s %s %s — %s", d.ID, what, who, d.Nick, d.State)
	if d.Size > 0 && !strings.HasPrefix(d.Kind, "chat") {
		s += fmt.Sprintf(", %s of %s (%d%%)", HumanSize(d.Done), HumanSize(d.Size), d.Done*100/d.Size)
		if d.Speed > 0 && d.State == "active" {
			s += ", " + HumanSize(int64(d.Speed)) + "/s"
		}
	}
	if d.Err != "" {
		s += " — " + d.Err
	}
	if d.IsOffer {
		s += fmt.Sprintf(" — /dcc accept %d or /dcc decline %d", d.ID, d.ID)
	}
	return s
}

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

func HumanSize(n int64) string {
	switch {
	case n >= 1<<30:
		return fmt.Sprintf("%.2f GB", float64(n)/(1<<30))
	case n >= 1<<20:
		return fmt.Sprintf("%.1f MB", float64(n)/(1<<20))
	case n >= 1<<10:
		return fmt.Sprintf("%.1f KB", float64(n)/(1<<10))
	}
	return fmt.Sprintf("%d bytes", n)
}

func quoteName(name string) string {
	name = strings.ReplaceAll(name, "\"", "'")
	if strings.ContainsRune(name, ' ') {
		return "\"" + name + "\""
	}
	return name
}

// cleanFileName makes an offered name safe to save (no folders, no odd characters).
func cleanFileName(name string) string {
	name = strings.ReplaceAll(name, "\\", "/")
	name = filepath.Base("/" + name)
	name = strings.Map(func(r rune) rune {
		if r < 32 || strings.ContainsRune(`<>:"/\|?*`, r) || !unicode.IsPrint(r) {
			return '_'
		}
		return r
	}, name)
	name = strings.TrimLeft(strings.TrimSpace(name), ".")
	if name == "" || name == "_" {
		name = "file"
	}
	base := strings.ToUpper(strings.TrimSuffix(name, filepath.Ext(name)))
	switch base { // names Windows won't allow
	case "CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "LPT1", "LPT2", "LPT3":
		name = "_" + name
	}
	if len(name) > 200 {
		name = name[len(name)-200:]
	}
	return name
}

// uniquePath never overwrites: "file.txt" -> "file (1).txt" if needed.
func uniquePath(dir, name string) string {
	p := filepath.Join(dir, name)
	ext := filepath.Ext(name)
	base := strings.TrimSuffix(name, ext)
	for i := 1; ; i++ {
		if _, err := os.Stat(p); os.IsNotExist(err) {
			return p
		}
		p = filepath.Join(dir, fmt.Sprintf("%s (%d)%s", base, i, ext))
	}
}
