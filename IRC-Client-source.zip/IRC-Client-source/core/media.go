package core

import (
	"bytes"
	"context"
	"errors"
	"image"
	"image/gif"
	_ "image/jpeg"
	_ "image/png"
	"io"
	"mime"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path"
	"regexp"
	"runtime"
	"strings"
	"sync"
	"time"

	_ "golang.org/x/image/bmp"
	"golang.org/x/image/draw"
	_ "golang.org/x/image/webp"
)

// ---------------------------------------------------------------------------
// Links
// ---------------------------------------------------------------------------

var urlRe = regexp.MustCompile(`\bhttps?://[^\s<>"'\x00-\x1f]+`)

func trimURL(u string) string {
	for len(u) > 0 {
		last := u[len(u)-1]
		if strings.ContainsRune(".,;:!?'\"]>", rune(last)) ||
			(last == ')' && strings.Count(u, "(") < strings.Count(u, ")")) {
			u = u[:len(u)-1]
			continue
		}
		break
	}
	return u
}

// FindURLs returns the links in a message (formatting codes already removed).
func FindURLs(text string) []string {
	var out []string
	for _, m := range urlRe.FindAllString(text, -1) {
		u := trimURL(m)
		dup := false
		for _, x := range out {
			dup = dup || x == u
		}
		if !dup {
			out = append(out, u)
		}
	}
	return out
}

// URLSpans splits text into pieces, marking which pieces are links.
type TextPiece struct {
	Text string
	URL  string // non-empty if this piece is a link
}

func SplitLinks(text string) []TextPiece {
	var out []TextPiece
	last := 0
	for _, loc := range urlRe.FindAllStringIndex(text, -1) {
		u := trimURL(text[loc[0]:loc[1]])
		if loc[0] > last {
			out = append(out, TextPiece{Text: text[last:loc[0]]})
		}
		out = append(out, TextPiece{Text: u, URL: u})
		last = loc[0] + len(u)
	}
	if last < len(text) {
		out = append(out, TextPiece{Text: text[last:]})
	}
	return out
}

// OpenURL opens a link in the default browser / viewer.
func OpenURL(u string) error {
	if !strings.HasPrefix(u, "http://") && !strings.HasPrefix(u, "https://") {
		return errors.New("only web links can be opened")
	}
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		cmd = exec.Command("rundll32", "url.dll,FileProtocolHandler", u)
	case "darwin":
		cmd = exec.Command("open", u)
	default:
		cmd = exec.Command("xdg-open", u)
	}
	return cmd.Start()
}

// ---------------------------------------------------------------------------
// What kind of media a link is
// ---------------------------------------------------------------------------

var (
	imageExt = map[string]bool{".jpg": true, ".jpeg": true, ".png": true, ".gif": true, ".webp": true, ".bmp": true}
	videoExt = map[string]bool{".mp4": true, ".m4v": true, ".webm": true, ".mov": true, ".ogv": true, ".gifv": true, ".mkv": true}
	audioExt = map[string]bool{".mp3": true, ".ogg": true, ".oga": true, ".wav": true, ".m4a": true, ".flac": true, ".opus": true}
)

// YouTubeID returns the video id of a YouTube link, or "".
func YouTubeID(raw string) string {
	u, err := url.Parse(raw)
	if err != nil {
		return ""
	}
	h := strings.TrimPrefix(strings.TrimPrefix(strings.ToLower(u.Hostname()), "www."), "m.")
	id := ""
	switch h {
	case "youtu.be":
		id = strings.Split(strings.TrimPrefix(u.Path, "/"), "/")[0]
	case "youtube.com", "music.youtube.com":
		if u.Path == "/watch" {
			id = u.Query().Get("v")
		} else if m := regexp.MustCompile(`^/(shorts|embed|live)/([\w-]{6,})`).FindStringSubmatch(u.Path); m != nil {
			id = m[2]
		}
	}
	if regexp.MustCompile(`^[\w-]{6,20}$`).MatchString(id) {
		return id
	}
	return ""
}

// LinkKind guesses from the address: "image", "video", "audio", "youtube" or "".
func LinkKind(raw string) string {
	if YouTubeID(raw) != "" {
		return "youtube"
	}
	u, err := url.Parse(raw)
	if err != nil {
		return ""
	}
	ext := strings.ToLower(path.Ext(u.Path))
	switch {
	case imageExt[ext]:
		return "image"
	case videoExt[ext]:
		return "video"
	case audioExt[ext]:
		return "audio"
	}
	return ""
}

// ThumbnailURL is the picture to show for a link ("" if none).
func ThumbnailURL(raw string) string {
	if id := YouTubeID(raw); id != "" {
		return "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg"
	}
	if LinkKind(raw) == "image" {
		return raw
	}
	return ""
}

// ---------------------------------------------------------------------------
// Downloading pictures (cached)
// ---------------------------------------------------------------------------

var httpClient = &http.Client{Timeout: 25 * time.Second}

type ImageState int

const (
	ImgLoading ImageState = iota
	ImgReady
	ImgFailed
)

type CachedImage struct {
	State  ImageState
	Img    image.Image     // scaled down to thumbnail size (first frame)
	Frames []image.Image   // animated GIF frames (nil if not animated)
	Delays []time.Duration // how long to show each frame
	Err    error           // why it failed
	failed time.Time
}

type ImageCache struct {
	mu      sync.Mutex
	items   map[string]*CachedImage
	order   []string
	MaxW    int
	MaxH    int
	OnReady func(url string)
	probe   map[string]string
}

func NewImageCache(maxW, maxH int) *ImageCache {
	return &ImageCache{items: map[string]*CachedImage{}, probe: map[string]string{}, MaxW: maxW, MaxH: maxH}
}

// Get returns the cached picture for a link, starting a download if needed.
func (ic *ImageCache) Get(u string) *CachedImage {
	ic.mu.Lock()
	defer ic.mu.Unlock()
	if it, ok := ic.items[u]; ok {
		if it.State != ImgFailed || time.Since(it.failed) < 30*time.Second {
			return it
		}
		delete(ic.items, u) // try a failed download again
	}
	it := &CachedImage{State: ImgLoading}
	ic.items[u] = it
	ic.order = append(ic.order, u)
	if len(ic.order) > 300 { // forget old pictures
		old := ic.order[0]
		ic.order = ic.order[1:]
		delete(ic.items, old)
	}
	go ic.load(u, it)
	return it
}

// GetVideoFrame returns a preview picture (first frame) of a video link.
// It needs ffmpeg; see FFmpegPath.
func (ic *ImageCache) GetVideoFrame(u string) *CachedImage { return ic.Get(VideoKey(u)) }

// VideoKey is the cache key / OnReady name used for a video's preview frame.
func VideoKey(u string) string { return "video:" + u }

func (ic *ImageCache) load(u string, it *CachedImage) {
	var img image.Image
	var frames []image.Image
	var delays []time.Duration
	var err error
	if strings.HasPrefix(u, "video:") {
		img, err = videoFrame(strings.TrimPrefix(u, "video:"))
	} else {
		var data []byte
		if data, err = fetchBytes(u); err == nil {
			img, frames, delays, err = decodeImage(data, ic.MaxW, ic.MaxH)
		}
	}
	ic.mu.Lock()
	if err != nil {
		it.State, it.failed, it.Err = ImgFailed, time.Now(), err
	} else {
		if frames != nil {
			it.Frames, it.Delays, it.Img = frames, delays, frames[0]
		} else {
			it.Img = scaleDown(img, ic.MaxW, ic.MaxH)
		}
		it.State = ImgReady
	}
	f := ic.OnReady
	ic.mu.Unlock()
	if f != nil {
		f(u)
	}
}

func fetchBytes(u string) ([]byte, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 25*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, "GET", u, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "Mozilla/5.0 (compatible; IRC client image preview)")
	resp, err := httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return nil, errors.New(resp.Status)
	}
	return io.ReadAll(io.LimitReader(resp.Body, 40<<20))
}

// decodeImage decodes a picture. Animated GIFs come back as scaled frames.
func decodeImage(data []byte, maxW, maxH int) (image.Image, []image.Image, []time.Duration, error) {
	if bytes.HasPrefix(data, []byte("GIF8")) {
		if g, err := gif.DecodeAll(bytes.NewReader(data)); err == nil && len(g.Image) > 1 {
			frames, delays := gifFrames(g, maxW, maxH)
			if len(frames) > 1 {
				return frames[0], frames, delays, nil
			}
		}
	}
	img, _, err := image.Decode(bytes.NewReader(data))
	return img, nil, nil, err
}

// gifFrames draws each GIF frame onto a full canvas (GIF frames are often
// only the changed part) and scales them down.
func gifFrames(g *gif.GIF, maxW, maxH int) ([]image.Image, []time.Duration) {
	w, h := g.Config.Width, g.Config.Height
	if w <= 0 || h <= 0 {
		b := g.Image[0].Bounds()
		w, h = b.Max.X, b.Max.Y
	}
	if w*h > 4000*4000 {
		return nil, nil
	}
	canvas := image.NewRGBA(image.Rect(0, 0, w, h))
	var frames []image.Image
	var delays []time.Duration
	limit := len(g.Image)
	if limit > 400 {
		limit = 400
	}
	for i := 0; i < limit; i++ {
		fr := g.Image[i]
		var saved *image.RGBA
		disposal := byte(0)
		if i < len(g.Disposal) {
			disposal = g.Disposal[i]
		}
		if disposal == gif.DisposalPrevious {
			saved = image.NewRGBA(canvas.Bounds())
			draw.Draw(saved, saved.Bounds(), canvas, image.Point{}, draw.Src)
		}
		draw.Draw(canvas, fr.Bounds(), fr, fr.Bounds().Min, draw.Over)
		frames = append(frames, scaleFast(canvas, maxW, maxH))
		d := 100 * time.Millisecond
		if i < len(g.Delay) && g.Delay[i] > 1 {
			d = time.Duration(g.Delay[i]) * 10 * time.Millisecond
		}
		delays = append(delays, d)
		switch disposal {
		case gif.DisposalBackground:
			draw.Draw(canvas, fr.Bounds(), image.Transparent, image.Point{}, draw.Src)
		case gif.DisposalPrevious:
			canvas = saved
		}
	}
	return frames, delays
}

func scaleFast(img image.Image, maxW, maxH int) image.Image {
	nw, nh := fitSize(img.Bounds().Dx(), img.Bounds().Dy(), maxW, maxH)
	dst := image.NewRGBA(image.Rect(0, 0, nw, nh))
	draw.ApproxBiLinear.Scale(dst, dst.Bounds(), img, img.Bounds(), draw.Src, nil)
	return dst
}

func fitSize(w, h, maxW, maxH int) (int, int) {
	if w <= 0 || h <= 0 {
		return 1, 1
	}
	scale := 1.0
	if w > maxW {
		scale = float64(maxW) / float64(w)
	}
	if float64(h)*scale > float64(maxH) {
		scale = float64(maxH) / float64(h)
	}
	nw, nh := int(float64(w)*scale), int(float64(h)*scale)
	if nw < 1 {
		nw = 1
	}
	if nh < 1 {
		nh = 1
	}
	return nw, nh
}

func scaleDown(img image.Image, maxW, maxH int) image.Image {
	b := img.Bounds()
	w, h := b.Dx(), b.Dy()
	if w <= 0 || h <= 0 {
		return img
	}
	scale := 1.0
	if w > maxW {
		scale = float64(maxW) / float64(w)
	}
	if float64(h)*scale > float64(maxH) {
		scale = float64(maxH) / float64(h)
	}
	nw, nh := int(float64(w)*scale), int(float64(h)*scale)
	if nw < 1 {
		nw = 1
	}
	if nh < 1 {
		nh = 1
	}
	dst := image.NewRGBA(image.Rect(0, 0, nw, nh))
	draw.CatmullRom.Scale(dst, dst.Bounds(), img, b, draw.Over, nil)
	return dst
}

// Probe asks the web server what a link without a file extension is
// ("image", "video", "audio" or ""). Results are cached; may be slow.
func (ic *ImageCache) Probe(u string) (string, bool) {
	ic.mu.Lock()
	k, ok := ic.probe[u]
	if !ok {
		ic.probe[u] = "?"
	}
	ic.mu.Unlock()
	if ok {
		return k, k != "?"
	}
	go func() {
		kind := ""
		ctx, cancel := context.WithTimeout(context.Background(), 12*time.Second)
		defer cancel()
		if req, err := http.NewRequestWithContext(ctx, "GET", u, nil); err == nil {
			req.Header.Set("Range", "bytes=0-0")
			req.Header.Set("User-Agent", "Mozilla/5.0 (compatible; IRC client link check)")
			if resp, err := httpClient.Do(req); err == nil {
				if resp.StatusCode < 400 {
					mt, _, _ := mime.ParseMediaType(resp.Header.Get("Content-Type"))
					switch {
					case strings.HasPrefix(mt, "image/") && mt != "image/svg+xml":
						kind = "image"
					case strings.HasPrefix(mt, "video/"):
						kind = "video"
					case strings.HasPrefix(mt, "audio/"):
						kind = "audio"
					}
				}
				resp.Body.Close()
			}
		}
		ic.mu.Lock()
		ic.probe[u] = kind
		f := ic.OnReady
		ic.mu.Unlock()
		if kind != "" && f != nil {
			f(u)
		}
	}()
	return "", false
}

// ---------------------------------------------------------------------------
// mIRC formatting codes (bold, colors, ...)
// ---------------------------------------------------------------------------

type Span struct {
	Text                                  string
	Bold, Italic, Underline, Strike, Mono bool
	FG, BG                                int // -1 = default, 0..15 mIRC colors
}

var MIRCColors = []uint32{0xffffff, 0x000000, 0x00007f, 0x009300, 0xff0000, 0x7f0000, 0x9c009c, 0xfc7f00,
	0xffff00, 0x00fc00, 0x009393, 0x00ffff, 0x0000fc, 0xff00ff, 0x7f7f7f, 0xd2d2d2}

var stripRe = regexp.MustCompile(`\x03(\d{1,2}(,\d{1,2})?)?|\x04([0-9a-fA-F]{6}(,[0-9a-fA-F]{6})?)?|[\x02\x0f\x11\x16\x1d\x1e\x1f]`)

func StripFormatting(s string) string { return stripRe.ReplaceAllString(s, "") }

var colorCodeRe = regexp.MustCompile(`^(\d{1,2})(?:,(\d{1,2}))?`)
var hexCodeRe = regexp.MustCompile(`^[0-9a-fA-F]{6}(?:,[0-9a-fA-F]{6})?`)

// ParseFormatting splits a message into styled pieces.
func ParseFormatting(s string) []Span {
	var out []Span
	st := Span{FG: -1, BG: -1}
	rev := false
	var buf strings.Builder
	flush := func() {
		if buf.Len() == 0 {
			return
		}
		sp := st
		sp.Text = buf.String()
		if rev {
			fg, bg := sp.BG, sp.FG
			if fg < 0 {
				fg = 0
			}
			if bg < 0 {
				bg = 1
			}
			sp.FG, sp.BG = fg, bg
		}
		if sp.FG > 15 {
			sp.FG = -1
		}
		if sp.BG > 15 {
			sp.BG = -1
		}
		out = append(out, sp)
		buf.Reset()
	}
	for i := 0; i < len(s); i++ {
		switch s[i] {
		case 0x02:
			flush()
			st.Bold = !st.Bold
		case 0x1d:
			flush()
			st.Italic = !st.Italic
		case 0x1f:
			flush()
			st.Underline = !st.Underline
		case 0x1e:
			flush()
			st.Strike = !st.Strike
		case 0x11:
			flush()
			st.Mono = !st.Mono
		case 0x16:
			flush()
			rev = !rev
		case 0x0f:
			flush()
			st, rev = Span{FG: -1, BG: -1}, false
		case 0x03:
			flush()
			if m := colorCodeRe.FindStringSubmatch(s[i+1:]); m != nil {
				st.FG = atoi(m[1])
				if m[2] != "" {
					st.BG = atoi(m[2])
				}
				i += len(m[0])
			} else {
				st.FG, st.BG = -1, -1
			}
		case 0x04:
			flush()
			if m := hexCodeRe.FindString(s[i+1:]); m != "" {
				i += len(m)
			}
		default:
			buf.WriteByte(s[i])
		}
	}
	flush()
	return out
}

func atoi(s string) int {
	n := 0
	for _, r := range s {
		n = n*10 + int(r-'0')
	}
	return n
}

// OpenFolder opens a folder in the file manager (Explorer, Files, ...).
func OpenFolder(dir string) error {
	os.MkdirAll(dir, 0700)
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		cmd = exec.Command("explorer", dir)
	case "darwin":
		cmd = exec.Command("open", dir)
	default:
		cmd = exec.Command("xdg-open", dir)
	}
	return cmd.Start()
}
