//go:build windows

package core

import (
	"os/exec"
	"syscall"
)

// hideConsole stops a black console window flashing up when ffmpeg runs.
func hideConsole(cmd *exec.Cmd) {
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000} // CREATE_NO_WINDOW
}
