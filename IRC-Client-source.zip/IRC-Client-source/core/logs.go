package core

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"
)

// ProgramDir is the folder the program is in. Everything (settings file and
// logs folder) is kept there, so the program is portable: copy the folder to
// a USB stick or another computer and it keeps working.
func ProgramDir() string {
	if exe, err := os.Executable(); err == nil {
		if real, err := filepath.EvalSymlinks(exe); err == nil {
			exe = real
		}
		dir := filepath.Dir(exe)
		if !strings.Contains(dir, "go-build") { // "go run" builds in a temp folder
			return dir
		}
	}
	wd, _ := os.Getwd()
	return wd
}

// Logger writes chat to  logs/<server>/<channel>.log  next to the program.
type Logger struct {
	mu      sync.Mutex
	dir     string
	enabled bool
	files   map[string]*os.File
	lastDay map[string]string
	err     error
}

func NewLogger(dir string, enabled bool) *Logger {
	return &Logger{dir: dir, enabled: enabled, files: map[string]*os.File{}, lastDay: map[string]string{}}
}

func (lg *Logger) Dir() string { return lg.dir }

func (lg *Logger) SetEnabled(on bool) {
	lg.mu.Lock()
	defer lg.mu.Unlock()
	lg.enabled = on
	if !on {
		lg.closeAllLocked()
	}
}

// badFileChars are not allowed in Windows file names.
var badFileChars = regexp.MustCompile(`[<>:"/\\|?*\x00-\x1f]`)

func safeName(s string) string {
	s = strings.TrimSpace(badFileChars.ReplaceAllString(s, "_"))
	s = strings.TrimRight(s, ". ")
	if s == "" {
		s = "_"
	}
	switch strings.ToUpper(s) { // reserved names on Windows
	case "CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "LPT1", "LPT2", "LPT3":
		s = "_" + s
	}
	if len(s) > 80 {
		s = s[:80]
	}
	return s
}

// Write adds one line to the log of a window.
func (lg *Logger) Write(server, buffer string, l Line) {
	lg.mu.Lock()
	defer lg.mu.Unlock()
	if !lg.enabled {
		return
	}
	name := buffer
	if buffer == "*" || buffer == "" {
		name = "server"
	}
	path := filepath.Join(lg.dir, safeName(server), safeName(strings.ToLower(name))+".log")
	f := lg.files[path]
	if f == nil {
		if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
			lg.err = err
			return
		}
		var err error
		f, err = os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
		if err != nil {
			lg.err = err
			return
		}
		lg.files[path] = f
		if len(lg.files) > 64 { // don't keep too many files open
			for p, of := range lg.files {
				if p != path {
					of.Close()
					delete(lg.files, p)
					break
				}
			}
		}
	}
	day := l.Time.Format("Monday, January 2, 2006")
	if lg.lastDay[path] != day {
		lg.lastDay[path] = day
		fmt.Fprintf(f, "\n--- %s ---\n", day)
	}
	text := StripFormatting(l.Text)
	var line string
	switch l.Kind {
	case "msg":
		line = fmt.Sprintf("<%s> %s", l.Nick, text)
	case "action":
		line = fmt.Sprintf("* %s %s", l.Nick, text)
	case "notice":
		line = fmt.Sprintf("-%s- %s", l.Nick, text)
	case "error":
		line = "! " + text
	default:
		line = "-- " + text
	}
	fmt.Fprintf(f, "[%s] %s\n", l.Time.Format("15:04:05"), strings.NewReplacer("\r", "", "\n", " ").Replace(line))
}

func (lg *Logger) closeAllLocked() {
	for p, f := range lg.files {
		f.Close()
		delete(lg.files, p)
	}
}

// Close closes all log files (call when the program exits).
func (lg *Logger) Close() {
	lg.mu.Lock()
	defer lg.mu.Unlock()
	lg.closeAllLocked()
}

// LastError reports a problem writing logs (e.g. the folder is read-only).
func (lg *Logger) LastError() error {
	lg.mu.Lock()
	defer lg.mu.Unlock()
	return lg.err
}

var _ = time.Now
