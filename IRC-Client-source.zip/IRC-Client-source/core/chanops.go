package core

// Channel operator tools: topic, modes, key, user limit, ban list,
// kicking and banning with a choice of ban mask.

import (
	"errors"
	"net"
	"sort"
	"strconv"
	"strings"
	"time"
)

type BanEntry struct {
	Mask  string
	SetBy string
	When  time.Time
}

// ChanInfo is a channel's current settings.
type ChanInfo struct {
	Name    string
	Topic   string
	Modes   string // simple mode letters, e.g. "nt"
	Key     string
	Limit   int
	Bans    []BanEntry
	MyModes string // your own prefix in the channel ("@", "+", ...)
}

// SimpleModes are the yes/no channel modes shown as checkboxes.
var SimpleModes = []struct {
	Letter byte
	Label  string
}{
	{'t', "Only operators can change the topic (+t)"},
	{'n', "No messages from outside the channel (+n)"},
	{'m', "Moderated: only voiced people can talk (+m)"},
	{'i', "Invite only (+i)"},
	{'s', "Secret: hidden from the channel list (+s)"},
	{'p', "Private (+p)"},
}

func prefixUserHost(prefix string) (user, host string) {
	_, rest, ok := strings.Cut(prefix, "!")
	if !ok {
		return "", ""
	}
	user, host, _ = strings.Cut(rest, "@")
	return user, host
}

// parseChanModes reads "+ntkl" "key" "20" into letters, key and limit.
func parseChanModes(modes string, args []string) (letters, key string, limit int) {
	ai := 0
	next := func() string {
		if ai < len(args) {
			ai++
			return args[ai-1]
		}
		return ""
	}
	for _, r := range strings.TrimPrefix(modes, "+") {
		switch r {
		case 'k':
			key = next()
		case 'l':
			limit, _ = strconv.Atoi(next())
		case 'f', 'j', 'L', 'F', 'H', 'J': // other modes that take an argument
			next()
		default:
			letters += string(r)
		}
	}
	return
}

// ChannelInfo returns a channel's topic, modes, key, limit and bans.
func (c *Conn) ChannelInfo(ch string) (ChanInfo, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	b, ok := c.buffers[strings.ToLower(ch)]
	if !ok || b.Kind != "channel" {
		return ChanInfo{}, false
	}
	ci := ChanInfo{Name: b.Name, Topic: b.Topic, Modes: b.Modes, Key: b.Key, Limit: b.Limit,
		Bans: append([]BanEntry(nil), b.Bans...)}
	if me := b.Users[strings.ToLower(c.nick)]; me != nil {
		ci.MyModes = me.Modes
	}
	return ci, true
}

// IsOp reports whether you are a channel operator (or higher) in ch.
func (c *Conn) IsOp(ch string) bool {
	ci, ok := c.ChannelInfo(ch)
	return ok && strings.ContainsAny(ci.MyModes, "~&@%")
}

// RequestBans asks the server for the channel's ban list (arrives as EvBuffer).
func (c *Conn) RequestBans(ch string) error {
	if err := c.online(); err != nil {
		return err
	}
	c.mu.Lock()
	c.quietBans[strings.ToLower(ch)] = true
	if b := c.buffers[strings.ToLower(ch)]; b != nil && b.Bans == nil {
		b.Bans = []BanEntry{}
	}
	c.mu.Unlock()
	return c.writeLine("MODE " + ch + " +b")
}

func (c *Conn) SetTopic(ch, topic string) error {
	if err := c.online(); err != nil {
		return err
	}
	return c.writeLine("TOPIC " + ch + " :" + topic)
}

// ApplyChannelModes changes the simple modes, key and limit to the wanted
// values (only what differs is sent).
func (c *Conn) ApplyChannelModes(ch, wantModes, wantKey string, wantLimit int) error {
	if err := c.online(); err != nil {
		return err
	}
	ci, ok := c.ChannelInfo(ch)
	if !ok {
		return errors.New("not in that channel")
	}
	plus, minus := "", ""
	var plusArgs, minusArgs []string
	for _, m := range SimpleModes {
		has, want := strings.IndexByte(ci.Modes, m.Letter) >= 0, strings.IndexByte(wantModes, m.Letter) >= 0
		if want && !has {
			plus += string(m.Letter)
		} else if has && !want {
			minus += string(m.Letter)
		}
	}
	wantKey = strings.TrimSpace(wantKey)
	if wantKey != ci.Key {
		if ci.Key != "" {
			minus += "k"
			minusArgs = append(minusArgs, ci.Key)
		}
		if wantKey != "" {
			plus += "k"
			plusArgs = append(plusArgs, wantKey)
		}
	}
	if wantLimit != ci.Limit {
		if wantLimit > 0 {
			plus += "l"
			plusArgs = append(plusArgs, strconv.Itoa(wantLimit))
		} else {
			minus += "l"
		}
	}
	if plus == "" && minus == "" {
		return nil
	}
	line := "MODE " + ch + " "
	if plus != "" {
		line += "+" + plus
	}
	if minus != "" {
		line += "-" + minus
	}
	args := append(plusArgs, minusArgs...)
	if len(args) > 0 {
		line += " " + strings.Join(args, " ")
	}
	return c.writeLine(line)
}

// ---------------------------------------------------------------------------
// Ban masks
// ---------------------------------------------------------------------------

// BanMaskTypes are the kinds of ban mask you can choose, with an example.
var BanMaskTypes = []string{
	"*!*@host           (everyone from their address — most common)",
	"*!*user@host       (their user name at their address)",
	"*!user@host        (exact user name and address)",
	"*!*@*.domain       (their whole provider / network)",
	"nick!*@*           (only that nickname, anywhere)",
	"nick!*@host        (that nickname from their address)",
}

// BanMaskLabel is a short label for menus.
func BanMaskLabel(i int) string {
	if i < 0 || i >= len(BanMaskTypes) {
		return ""
	}
	return strings.TrimSpace(strings.SplitN(BanMaskTypes[i], "(", 2)[0])
}

// MakeBanMask builds ban mask type t for a person.
func MakeBanMask(t int, nick, user, host string) string {
	if host == "" {
		return nick + "!*@*" // address not known: fall back to the nickname
	}
	u := strings.TrimLeft(user, "~^=+-")
	if u == "" {
		u = "*"
	}
	switch t {
	case 0:
		return "*!*@" + host
	case 1:
		return "*!*" + u + "@" + host
	case 2:
		return "*!" + user + "@" + host
	case 3:
		return "*!*@" + domainPart(host)
	case 4:
		return nick + "!*@*"
	case 5:
		return nick + "!*@" + host
	}
	return "*!*@" + host
}

// domainPart: "a.b.example.com" -> "*.example.com"; "1.2.3.4" -> "1.2.3.*"
func domainPart(host string) string {
	if ip := net.ParseIP(host); ip != nil {
		if ip4 := ip.To4(); ip4 != nil {
			p := strings.Split(host, ".")
			return strings.Join(p[:3], ".") + ".*"
		}
		if i := strings.LastIndex(host, ":"); i > 0 {
			return host[:i] + ":*"
		}
	}
	p := strings.Split(host, ".")
	if len(p) <= 2 {
		return host
	}
	return "*." + strings.Join(p[1:], ".")
}

// MemberHost returns a person's user and host if known (from any channel).
func (c *Conn) MemberHost(nick string) (user, host string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	k := strings.ToLower(nick)
	for _, b := range c.buffers {
		if mem := b.Users[k]; mem != nil && mem.Host != "" {
			return mem.User, mem.Host
		}
	}
	return "", ""
}

// resolveHost finds a person's user@host, asking the server (USERHOST) if needed.
func (c *Conn) resolveHost(nick string, done func(user, host string)) {
	if u, h := c.MemberHost(nick); h != "" {
		done(u, h)
		return
	}
	once := make(chan struct{})
	call := func(u, h string) {
		select {
		case <-once:
		default:
			close(once)
			done(u, h)
		}
	}
	c.mu.Lock()
	k := strings.ToLower(nick)
	c.hostWait[k] = append(c.hostWait[k], call)
	c.mu.Unlock()
	c.writeLine("USERHOST " + nick)
	go func() {
		time.Sleep(6 * time.Second)
		c.mu.Lock()
		delete(c.hostWait, k)
		c.mu.Unlock()
		call("", "") // no answer: ban by nickname
	}()
}

// Kick removes someone from a channel.
func (c *Conn) Kick(ch, nick, reason string) error {
	if err := c.online(); err != nil {
		return err
	}
	if reason == "" {
		reason = nick
	}
	return c.writeLine("KICK " + ch + " " + nick + " :" + reason)
}

// Ban bans someone with mask type t (see BanMaskTypes), and kicks them too if kick is set.
func (c *Conn) Ban(ch, nick string, t int, kick bool, reason string) error {
	if err := c.online(); err != nil {
		return err
	}
	c.resolveHost(nick, func(user, host string) {
		mask := MakeBanMask(t, nick, user, host)
		c.writeLine("MODE " + ch + " +b " + mask)
		if kick {
			time.Sleep(300 * time.Millisecond)
			c.Kick(ch, nick, reason)
		}
	})
	return nil
}

// BanMaskPreview shows what the mask would be (address may still be unknown).
func (c *Conn) BanMaskPreview(t int, nick string) string {
	u, h := c.MemberHost(nick)
	return MakeBanMask(t, nick, u, h)
}

func (c *Conn) Unban(ch, mask string) error {
	if err := c.online(); err != nil {
		return err
	}
	return c.writeLine("MODE " + ch + " -b " + mask)
}

// UserMode sets +o/-o/+v/-v etc. for someone in a channel.
func (c *Conn) UserMode(ch, mode, nick string) error {
	if err := c.online(); err != nil {
		return err
	}
	return c.writeLine("MODE " + ch + " " + mode + " " + nick)
}

// Whois asks the server about someone (the answer appears in the server window).
func (c *Conn) Whois(nick string) error {
	if err := c.online(); err != nil {
		return err
	}
	return c.writeLine("WHOIS " + nick)
}

// sortedBans returns bans newest first.
func sortedBans(b []BanEntry) []BanEntry {
	out := append([]BanEntry(nil), b...)
	sort.SliceStable(out, func(i, j int) bool { return out[i].When.After(out[j].When) })
	return out
}
