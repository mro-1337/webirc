// Package core is the IRC engine shared by the terminal and desktop clients.
package core

import (
	"bufio"
	"crypto/tls"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"net"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
	"unicode/utf8"
)

const maxLines = 2000

// Line is one line shown in a chat window.
type Line struct {
	Time      time.Time
	Kind      string // msg action notice join part quit kick nick topic mode info error
	Nick      string
	Text      string
	Self      bool
	Highlight bool // mentions you, or a private message
}

// IsChat reports whether this is something a person said.
func (l Line) IsChat() bool { return l.Kind == "msg" || l.Kind == "action" || l.Kind == "notice" }

type EventKind int

const (
	EvLine     EventKind = iota // a new line in a buffer
	EvNet                       // status / nick / list of buffers changed
	EvBuffer                    // topic or user list of a buffer changed
	EvMedia                     // an image finished downloading
	EvDCC                       // a DCC transfer/chat changed (Event.DCC = id)
	EvDCCOffer                  // someone offers a DCC file/chat (Event.DCC = id)
)

type Event struct {
	Kind EventKind
	// Conn is the server. Inside OnEvent only Conn.ID() may be called.
	Conn *Conn
	Buf  string
	Line Line
	DCC  int
}

// ---------------------------------------------------------------------------
// Client: all servers
// ---------------------------------------------------------------------------

type Client struct {
	mu       sync.Mutex
	path     string
	Log      *Logger
	settings *Settings
	conns    []*Conn
	dcc      dccManager
	// OnEvent is called when something changes. It must return quickly and
	// must not call back into the client (just wake up the UI).
	OnEvent func(Event)
}

func NewClient(path string, s *Settings) *Client {
	cl := &Client{path: path, settings: s, Log: NewLogger(filepath.Join(filepath.Dir(path), "logs"), s.Logging)}
	for _, sc := range s.Servers {
		cl.conns = append(cl.conns, newConn(cl, *sc))
	}
	return cl
}

func (cl *Client) Path() string { return cl.path }

// Start connects every server marked autoconnect.
func (cl *Client) Start() {
	for _, c := range cl.Conns() {
		if c.Config().AutoConnect {
			c.Connect()
		}
	}
}

func (cl *Client) Conns() []*Conn {
	cl.mu.Lock()
	defer cl.mu.Unlock()
	return append([]*Conn(nil), cl.conns...)
}

func (cl *Client) Conn(id string) *Conn {
	for _, c := range cl.Conns() {
		if c.ID() == id {
			return c
		}
	}
	return nil
}

func (cl *Client) emit(ev Event) {
	if f := cl.OnEvent; f != nil {
		f(ev)
	}
}

// Global returns a copy of the global settings (without servers).
func (cl *Client) Global() Settings {
	cl.mu.Lock()
	defer cl.mu.Unlock()
	s := *cl.settings
	s.Servers = nil
	return s
}

// SetGlobal changes the global settings and saves them.
func (cl *Client) SetGlobal(f func(*Settings)) error {
	cl.mu.Lock()
	f(cl.settings)
	logging := cl.settings.Logging
	cl.mu.Unlock()
	cl.Log.SetEnabled(logging)
	return cl.Save()
}

// Save writes the settings file.
func (cl *Client) Save() error {
	conns := cl.Conns()
	servers := make([]*ServerConfig, 0, len(conns))
	for _, c := range conns {
		sc := c.Config()
		servers = append(servers, &sc)
	}
	cl.mu.Lock()
	cl.settings.Servers = servers
	s := *cl.settings
	cl.mu.Unlock()
	return SaveSettings(cl.path, &s)
}

func (cl *Client) AddServer(sc ServerConfig) (*Conn, error) { return cl.addServer(sc, true) }

func (cl *Client) addServer(sc ServerConfig, connect bool) (*Conn, error) {
	if err := validateServer(&sc); err != nil {
		return nil, err
	}
	sc.ID = newID()
	c := newConn(cl, sc)
	cl.mu.Lock()
	cl.conns = append(cl.conns, c)
	cl.mu.Unlock()
	cl.Save()
	cl.emit(Event{Kind: EvNet, Conn: c})
	if connect {
		c.Connect()
	}
	return c, nil
}

func validateServer(sc *ServerConfig) error {
	sc.Host = strings.TrimSpace(sc.Host)
	if sc.Host == "" {
		return errors.New("the server address is required")
	}
	if sc.Nick != "" && strings.ContainsAny(sc.Nick, " ,*?!@#:") {
		return errors.New("that nickname has characters IRC doesn't allow")
	}
	sc.Port = sc.EffectivePort()
	sc.Channels = cleanChannels(sc.Channels)
	cmds := []string{}
	for _, c := range sc.Commands {
		if c = strings.TrimSpace(c); c != "" {
			cmds = append(cmds, c)
		}
	}
	sc.Commands = cmds
	return nil
}

// UpdateServer saves new settings for a server and applies them.
func (cl *Client) UpdateServer(sc ServerConfig) error {
	if err := validateServer(&sc); err != nil {
		return err
	}
	c := cl.Conn(sc.ID)
	if c == nil {
		return errors.New("no such server")
	}
	c.mu.Lock()
	old := c.cfg
	sc.ID = c.id
	c.cfg = sc
	active, online, curNick := c.want, c.registered, c.nick
	c.mu.Unlock()
	cl.Save()
	reconnect := old.Host != sc.Host || old.Port != sc.Port || old.TLS != sc.TLS ||
		old.SelfSigned != sc.SelfSigned || old.Password != sc.Password || old.ServerUser != sc.ServerUser ||
		old.Username != sc.Username || old.Realname != sc.Realname
	if active && reconnect {
		c.Disconnect("Reconnecting with new settings")
		go func() { time.Sleep(1500 * time.Millisecond); c.Connect() }()
	} else if online {
		newNick := cl.nickFor(sc)
		if !strings.EqualFold(newNick, curNick) && sc.Nick != old.Nick {
			c.writeLine("NICK " + newNick)
		}
		for _, ch := range sc.Channels {
			if !containsChan(old.Channels, ch) {
				c.writeLine("JOIN " + ch)
			}
		}
	}
	cl.emit(Event{Kind: EvNet, Conn: c})
	return nil
}

func (cl *Client) RemoveServer(id string) {
	cl.mu.Lock()
	var gone *Conn
	for i, c := range cl.conns {
		if c.ID() == id {
			gone = c
			cl.conns = append(cl.conns[:i], cl.conns[i+1:]...)
			break
		}
	}
	cl.mu.Unlock()
	if gone != nil {
		gone.Disconnect("Leaving")
		cl.Save()
		cl.emit(Event{Kind: EvNet, Conn: gone})
	}
}

// Shutdown disconnects everything (call before the program exits).
func (cl *Client) Shutdown(reason string) {
	for _, c := range cl.Conns() {
		c.Disconnect(reason)
	}
	time.Sleep(900 * time.Millisecond)
	cl.Log.Close()
}

func (cl *Client) nickFor(sc ServerConfig) string {
	if sc.Nick != "" {
		return sc.Nick
	}
	cl.mu.Lock()
	defer cl.mu.Unlock()
	return cl.settings.Nick
}

func (cl *Client) identity(sc ServerConfig) (nick, alt, user, real string) {
	cl.mu.Lock()
	g := *cl.settings
	cl.mu.Unlock()
	nick, alt, user, real = sc.Nick, sc.AltNick, sc.Username, sc.Realname
	if nick == "" {
		nick = g.Nick
	}
	if alt == "" {
		alt = g.AltNick
	}
	if user == "" && sc.ServerUser != "" { // bouncers like the ident to be the login name
		user = badNickChars.ReplaceAllString(strings.SplitN(sc.ServerUser, "/", 2)[0], "")
	}
	if user == "" {
		user = badNickChars.ReplaceAllString(strings.ToLower(nick), "")
		if user == "" {
			user = "user"
		}
	}
	if real == "" {
		real = g.Realname
	}
	if real == "" {
		real = nick
	}
	return
}

func containsChan(list []string, ch string) bool {
	name := strings.Fields(ch)[0]
	for _, x := range list {
		if f := strings.Fields(x); len(f) > 0 && strings.EqualFold(f[0], name) {
			return true
		}
	}
	return false
}

// ---------------------------------------------------------------------------
// Conn: one server connection
// ---------------------------------------------------------------------------

type Member struct {
	Nick  string
	Modes string
	User  string // from WHO / JOIN (used for ban masks)
	Host  string
}

type Buffer struct {
	Name   string
	Kind   string // server channel query
	Topic  string
	Joined bool
	Users  map[string]*Member
	Lines  []Line

	// channel settings (from MODE replies)
	Modes  string // simple mode letters, e.g. "nt"
	Key    string // +k
	Limit  int    // +l
	Bans   []BanEntry
	banTmp []BanEntry
}

type Conn struct {
	cl *Client
	id string // never changes, safe to read without the lock

	mu         sync.Mutex
	cfg        ServerConfig
	status     string // disconnected connecting registering connected waiting
	lastErr    string
	tlsInfo    string
	nick       string
	wantNick   string
	altNick    string
	want       bool
	running    bool
	registered bool
	nickTry    int
	sock       net.Conn
	wake       chan struct{}
	buffers    map[string]*Buffer
	prefModes  string
	prefSyms   string
	chanTypes  string
	names      map[string]bool
	quietWho   map[string]bool // WHO we sent ourselves (don't print the reply)
	quietMode  map[string]bool // MODE #chan we sent ourselves
	quietBans  map[string]bool // ban list we asked for
	hostWait   map[string][]func(user, host string)
	dccChats   map[string]*dccItem // "=nick" window -> chat

	listTmp  []ListEntry // /list results being received
	listDone []ListEntry // last complete /list
	listing  bool
	saslBusy bool

	wmu   sync.Mutex
	w     net.Conn
	sendq chan string // lines waiting to be sent (flood protection)
}

func newConn(cl *Client, sc ServerConfig) *Conn {
	c := &Conn{
		cl: cl, id: sc.ID, cfg: sc, status: "disconnected", wake: make(chan struct{}, 1),
		buffers: map[string]*Buffer{}, prefModes: "ov", prefSyms: "@+", chanTypes: "#&",
		names: map[string]bool{}, quietWho: map[string]bool{}, quietMode: map[string]bool{},
		quietBans: map[string]bool{}, hostWait: map[string][]func(string, string){}, dccChats: map[string]*dccItem{},
	}
	c.nick = cl.nickFor(sc)
	c.buffers["*"] = &Buffer{Name: "*", Kind: "server", Users: map[string]*Member{}}
	return c
}

// ---- read-only views for the UI ----

type ConnInfo struct {
	ID, Name, Status, Nick, Error, TLSInfo string
}

type BufInfo struct {
	Name   string
	Kind   string
	Topic  string
	Joined bool
}

// ID never changes and can be called from anywhere (even inside OnEvent).
func (c *Conn) ID() string { return c.id }

func (c *Conn) Config() ServerConfig {
	c.mu.Lock()
	defer c.mu.Unlock()
	sc := c.cfg
	sc.Channels = append([]string(nil), c.cfg.Channels...)
	sc.Commands = append([]string(nil), c.cfg.Commands...)
	return sc
}

func (c *Conn) Info() ConnInfo {
	c.mu.Lock()
	defer c.mu.Unlock()
	return ConnInfo{c.cfg.ID, c.cfg.DisplayName(), c.status, c.nick, c.lastErr, c.tlsInfo}
}

func (c *Conn) Buffers() []BufInfo {
	c.mu.Lock()
	defer c.mu.Unlock()
	out := []BufInfo{}
	for _, b := range c.buffers {
		out = append(out, BufInfo{b.Name, b.Kind, b.Topic, b.Joined})
	}
	rank := map[string]int{"server": 0, "channel": 1, "query": 2, "dcc": 3}
	sort.Slice(out, func(i, j int) bool {
		if rank[out[i].Kind] != rank[out[j].Kind] {
			return rank[out[i].Kind] < rank[out[j].Kind]
		}
		return strings.ToLower(out[i].Name) < strings.ToLower(out[j].Name)
	})
	return out
}

func (c *Conn) Buffer(name string) (BufInfo, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	b, ok := c.buffers[strings.ToLower(name)]
	if !ok {
		return BufInfo{}, false
	}
	return BufInfo{b.Name, b.Kind, b.Topic, b.Joined}, true
}

// Lines returns (a copy of) the lines of a buffer.
func (c *Conn) Lines(name string) []Line {
	c.mu.Lock()
	defer c.mu.Unlock()
	if b, ok := c.buffers[strings.ToLower(name)]; ok {
		return append([]Line(nil), b.Lines...)
	}
	return nil
}

// ClearLines empties a window (only on this computer).
func (c *Conn) ClearLines(name string) {
	c.mu.Lock()
	if b, ok := c.buffers[strings.ToLower(name)]; ok {
		b.Lines = nil
	}
	c.mu.Unlock()
}

// Users returns the nick list with prefixes (@op, +voice), sorted by rank.
func (c *Conn) Users(name string) []string {
	c.mu.Lock()
	defer c.mu.Unlock()
	b, ok := c.buffers[strings.ToLower(name)]
	if !ok {
		return nil
	}
	ms := make([]*Member, 0, len(b.Users))
	for _, m := range b.Users {
		ms = append(ms, m)
	}
	rank := func(m *Member) int {
		best := len(c.prefSyms)
		for _, r := range m.Modes {
			if i := strings.IndexRune(c.prefSyms, r); i >= 0 && i < best {
				best = i
			}
		}
		return best
	}
	sort.Slice(ms, func(i, j int) bool {
		ri, rj := rank(ms[i]), rank(ms[j])
		if ri != rj {
			return ri < rj
		}
		return strings.ToLower(ms[i].Nick) < strings.ToLower(ms[j].Nick)
	})
	out := make([]string, 0, len(ms))
	for _, m := range ms {
		p := ""
		if r := rank(m); r < len(c.prefSyms) {
			p = c.prefSyms[r : r+1]
		}
		out = append(out, p+m.Nick)
	}
	return out
}

func (c *Conn) IsChannel(name string) bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.isChannel(name)
}

// ---- connecting ----

func (c *Conn) Connect() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.want = true
	if !c.running {
		c.running = true
		go c.run()
	} else {
		select {
		case c.wake <- struct{}{}:
		default:
		}
	}
}

func (c *Conn) Disconnect(reason string) {
	c.mu.Lock()
	c.want = false
	sock := c.sock
	c.mu.Unlock()
	if sock != nil {
		if reason == "" {
			reason = "Leaving"
		}
		c.writeLine("QUIT :" + reason)
		go func() { time.Sleep(700 * time.Millisecond); sock.Close() }()
	}
	select {
	case c.wake <- struct{}{}:
	default:
	}
}

func (c *Conn) run() {
	delay := 10 * time.Second
	for {
		c.mu.Lock()
		if !c.want {
			c.running = false
			c.status = "disconnected"
			c.mu.Unlock()
			c.emitNet()
			return
		}
		c.mu.Unlock()

		started := time.Now()
		err := c.session()

		c.mu.Lock()
		c.sock = nil
		c.registered = false
		c.tlsInfo = ""
		for _, b := range c.buffers {
			if b.Kind == "channel" {
				b.Joined = false
				b.Users = map[string]*Member{}
			}
		}
		want := c.want
		msg := "Disconnected"
		kind := "info"
		if err != nil {
			msg, kind = "Disconnected: "+err.Error(), "error"
			c.lastErr = err.Error()
		}
		if want {
			c.status = "waiting"
			msg += fmt.Sprintf(" — reconnecting in %d seconds", int(delay.Seconds()))
		} else {
			c.status = "disconnected"
		}
		for _, b := range c.buffers {
			if b.Kind != "query" {
				c.addLine(b, Line{Kind: kind, Text: msg})
			}
		}
		c.mu.Unlock()
		c.emitNet()
		if !want {
			continue
		}
		if time.Since(started) > 2*time.Minute {
			delay = 10 * time.Second
		}
		select {
		case <-time.After(delay):
		case <-c.wake:
		}
		if delay *= 2; delay > 3*time.Minute {
			delay = 3 * time.Minute
		}
	}
}

func (c *Conn) session() error {
	cfg := c.Config()
	nick, alt, user, real := c.cl.identity(cfg)
	c.mu.Lock()
	c.status = "connecting"
	c.lastErr = ""
	mode := "plain (not encrypted)"
	if cfg.TLS {
		mode = "TLS (encrypted)"
	}
	c.addLine(c.buffers["*"], Line{Kind: "info", Text: fmt.Sprintf("Connecting to %s port %d using %s…", cfg.Host, cfg.Port, mode)})
	c.mu.Unlock()
	c.emitNet()

	addr := net.JoinHostPort(cfg.Host, strconv.Itoa(cfg.Port))
	d := &net.Dialer{Timeout: 20 * time.Second, KeepAlive: 60 * time.Second}
	var sock net.Conn
	var err error
	tlsInfo := ""
	if cfg.TLS {
		var tc *tls.Conn
		tc, err = tls.DialWithDialer(d, "tcp", addr, TLSConfig(cfg.Host, cfg.SelfSigned))
		if err != nil {
			if _, isNet := err.(*net.OpError); isNet && !strings.Contains(err.Error(), "reset") {
				return err
			}
			return ExplainTLSError(err)
		}
		sock = tc
		st := tc.ConnectionState()
		tlsInfo = fmt.Sprintf("Encrypted with %s (%s)", tls.VersionName(st.Version), tls.CipherSuiteName(st.CipherSuite))
		if len(st.PeerCertificates) > 0 {
			cert := st.PeerCertificates[0]
			if cert.Subject.String() == cert.Issuer.String() {
				tlsInfo += ", self-signed certificate"
			} else {
				tlsInfo += ", certificate from " + firstNonEmpty(cert.Issuer.CommonName, strings.Join(cert.Issuer.Organization, " "), "unknown issuer")
			}
		}
	} else {
		sock, err = d.Dial("tcp", addr)
		if err != nil {
			return err
		}
	}
	defer sock.Close()

	c.mu.Lock()
	if !c.want {
		c.mu.Unlock()
		return nil
	}
	c.sock = sock
	c.status = "registering"
	c.nick, c.wantNick, c.altNick = nick, nick, alt
	c.nickTry = 0
	c.tlsInfo = tlsInfo
	c.names = map[string]bool{}
	if tlsInfo != "" {
		c.addLine(c.buffers["*"], Line{Kind: "info", Text: "🔒 " + tlsInfo})
	}
	c.addLine(c.buffers["*"], Line{Kind: "info", Text: "Connected. Logging in…"})
	c.mu.Unlock()
	c.emitNet()

	done := make(chan struct{})
	q := make(chan string, 1000)
	c.wmu.Lock()
	c.w, c.sendq = sock, q
	c.wmu.Unlock()
	go c.sendLoop(q, done)
	defer func() {
		close(done)
		c.wmu.Lock()
		if c.w == sock {
			c.w, c.sendq = nil, nil
		}
		c.wmu.Unlock()
	}()

	if pass := PassLine(cfg.ServerUser, cfg.Password); pass != "" {
		c.writeLine("PASS " + trailing(pass))
	}
	if cfg.SASLUser != "" {
		c.mu.Lock()
		c.saslBusy = true
		c.mu.Unlock()
		c.writeLine("CAP REQ :sasl")
	}
	c.writeLine("NICK " + nick)
	c.writeLine("USER " + user + " 0 * :" + real)

	go func() {
		t := time.NewTicker(90 * time.Second)
		defer t.Stop()
		for {
			select {
			case <-done:
				return
			case <-t.C:
				c.writeLine("PING :client")
			}
		}
	}()

	r := bufio.NewReaderSize(sock, 16*1024)
	gotAny := false
	for {
		sock.SetReadDeadline(time.Now().Add(5 * time.Minute))
		line, err := readIRCLine(r)
		if err == nil && !gotAny && !cfg.TLS && looksLikeTLS(line) {
			return errors.New("this port expects an ENCRYPTED connection — turn encryption on")
		}
		if err != nil {
			if errors.Is(err, io.EOF) {
				if !gotAny && !cfg.TLS {
					return errors.New("server closed the connection without answering — if this port uses encryption, turn encryption on")
				}
				return errors.New("server closed the connection")
			}
			c.mu.Lock()
			quitting := !c.want
			c.mu.Unlock()
			if quitting {
				return nil
			}
			return err
		}
		gotAny = true
		if line != "" {
			c.handle(parseMsg(line))
		}
	}
}

func readIRCLine(r *bufio.Reader) (string, error) {
	var buf []byte
	for {
		part, isPrefix, err := r.ReadLine()
		if err != nil {
			return "", err
		}
		if len(buf) < 8192 {
			buf = append(buf, part...)
		}
		if !isPrefix {
			break
		}
	}
	if utf8.Valid(buf) {
		return string(buf), nil
	}
	rs := make([]rune, len(buf)) // Latin-1 fallback for old servers
	for i, b := range buf {
		rs[i] = rune(b)
	}
	return string(rs), nil
}

// writeLine queues a line for the server. Lines go out at a safe speed
// (a burst of 8, then about one every 0.8 seconds) so pasting a lot of text
// doesn't get you disconnected for flooding. PONG and QUIT go out at once.
func (c *Conn) writeLine(s string) error {
	s = strings.NewReplacer("\r", "", "\n", "").Replace(s)
	c.wmu.Lock()
	w, q := c.w, c.sendq
	c.wmu.Unlock()
	if w == nil {
		return errors.New("not connected")
	}
	up := strings.ToUpper(s)
	if q == nil || strings.HasPrefix(up, "PONG") || strings.HasPrefix(up, "QUIT") {
		return c.writeNow(s)
	}
	select {
	case q <- s:
		return nil
	default:
		return errors.New("too much waiting to be sent — slow down")
	}
}

func (c *Conn) writeNow(s string) error {
	c.wmu.Lock()
	defer c.wmu.Unlock()
	if c.w == nil {
		return errors.New("not connected")
	}
	c.w.SetWriteDeadline(time.Now().Add(30 * time.Second))
	_, err := io.WriteString(c.w, s+"\r\n")
	return err
}

func (c *Conn) sendLoop(q chan string, done chan struct{}) {
	const burst, every = 8.0, 800 * time.Millisecond
	tokens, last := burst, time.Now()
	for {
		select {
		case <-done:
			return
		case s := <-q:
			now := time.Now()
			tokens += float64(now.Sub(last)) / float64(every)
			if tokens > burst {
				tokens = burst
			}
			last = now
			if tokens < 1 {
				wait := time.Duration((1 - tokens) * float64(every))
				select {
				case <-done:
					return
				case <-time.After(wait):
				}
				tokens, last = 1, time.Now()
			}
			tokens--
			c.writeNow(s)
		}
	}
}

// Queued reports how many lines are still waiting to be sent.
func (c *Conn) Queued() int {
	c.wmu.Lock()
	defer c.wmu.Unlock()
	return len(c.sendq)
}

// SendRaw sends a raw IRC line.
func (c *Conn) SendRaw(s string) error { return c.writeLine(s) }

func trailing(s string) string {
	if s == "" || strings.ContainsAny(s, " :") {
		return ":" + s
	}
	return s
}

func firstNonEmpty(vals ...string) string {
	for _, v := range vals {
		if strings.TrimSpace(v) != "" {
			return v
		}
	}
	return ""
}

// ---------------------------------------------------------------------------
// Parsing and handling server messages
// ---------------------------------------------------------------------------

type msg struct {
	Prefix string
	Cmd    string
	Params []string
}

func (m msg) Nick() string {
	if i := strings.IndexByte(m.Prefix, '!'); i >= 0 {
		return m.Prefix[:i]
	}
	return m.Prefix
}

func (m msg) P(i int) string {
	if i < len(m.Params) {
		return m.Params[i]
	}
	return ""
}

func parseMsg(line string) msg {
	var m msg
	if strings.HasPrefix(line, "@") {
		i := strings.IndexByte(line, ' ')
		if i < 0 {
			return m
		}
		line = strings.TrimLeft(line[i+1:], " ")
	}
	if strings.HasPrefix(line, ":") {
		i := strings.IndexByte(line, ' ')
		if i < 0 {
			m.Prefix = line[1:]
			return m
		}
		m.Prefix = line[1:i]
		line = strings.TrimLeft(line[i+1:], " ")
	}
	for line != "" {
		if strings.HasPrefix(line, ":") {
			m.Params = append(m.Params, line[1:])
			break
		}
		i := strings.IndexByte(line, ' ')
		if i < 0 {
			m.Params = append(m.Params, line)
			break
		}
		m.Params = append(m.Params, line[:i])
		line = strings.TrimLeft(line[i+1:], " ")
	}
	if len(m.Params) > 0 {
		m.Cmd = strings.ToUpper(m.Params[0])
		m.Params = m.Params[1:]
	}
	return m
}

func (c *Conn) isChannel(name string) bool {
	return name != "" && strings.ContainsRune(c.chanTypes, rune(name[0]))
}

func (c *Conn) isMe(nick string) bool { return strings.EqualFold(nick, c.nick) }

// getBuf finds or creates a buffer. Caller holds c.mu.
func (c *Conn) getBuf(name, kind string, create bool) *Buffer {
	key := strings.ToLower(name)
	if b, ok := c.buffers[key]; ok {
		return b
	}
	if !create {
		return nil
	}
	b := &Buffer{Name: name, Kind: kind, Users: map[string]*Member{}}
	c.buffers[key] = b
	c.cl.emit(Event{Kind: EvNet, Conn: c})
	return b
}

var wordChars = `[\w\[\]\\` + "`" + `^{}|-]`

// addLine appends a line. Caller holds c.mu.
func (c *Conn) addLine(b *Buffer, l Line) {
	if l.Time.IsZero() {
		l.Time = time.Now()
	}
	if l.IsChat() && !l.Self && b.Kind != "server" {
		if b.Kind == "query" {
			l.Highlight = true
		} else if c.nick != "" {
			re, err := regexp.Compile(`(?i)(^|[^\w\[\]\\` + "`" + `^{}|-])` + regexp.QuoteMeta(c.nick) + `($|[^\w\[\]\\` + "`" + `^{}|-])`)
			if err == nil && re.MatchString(l.Text) {
				l.Highlight = true
			}
			if !l.Highlight && c.cl.matchesHighlight(l.Text) {
				l.Highlight = true
			}
		}
	}
	b.Lines = append(b.Lines, l)
	c.cl.Log.Write(c.cfg.DisplayName(), b.Name, l)
	if len(b.Lines) > maxLines {
		b.Lines = append([]Line(nil), b.Lines[len(b.Lines)-maxLines:]...)
	}
	c.cl.emit(Event{Kind: EvLine, Conn: c, Buf: b.Name, Line: l})
}

func (c *Conn) serverLine(kind, text string) { c.addLine(c.buffers["*"], Line{Kind: kind, Text: text}) }

func (c *Conn) emitNet()            { c.cl.emit(Event{Kind: EvNet, Conn: c}) }
func (c *Conn) emitBuf(name string) { c.cl.emit(Event{Kind: EvBuffer, Conn: c, Buf: name}) }

func (c *Conn) handle(m msg) {
	c.mu.Lock()
	defer c.mu.Unlock()
	from := m.Nick()

	switch m.Cmd {
	case "PING":
		c.writeLine("PONG " + trailing(m.P(len(m.Params)-1)))
	case "PONG", "333", "331", "321":
	case "CAP":
		sub, caps := strings.ToUpper(m.P(1)), strings.ToLower(m.P(len(m.Params)-1))
		if !c.saslBusy {
			return
		}
		if sub == "ACK" && strings.Contains(caps, "sasl") {
			c.writeLine("AUTHENTICATE PLAIN")
		} else if sub == "NAK" {
			c.saslBusy = false
			c.serverLine("error", "This server doesn't support SASL login — continuing without it")
			c.writeLine("CAP END")
		}
	case "AUTHENTICATE":
		if c.saslBusy && m.P(0) == "+" {
			u, p := c.cfg.SASLUser, c.cfg.SASLPass
			c.writeLine("AUTHENTICATE " + base64.StdEncoding.EncodeToString([]byte(u+"\x00"+u+"\x00"+p)))
		}
	case "903":
		c.saslBusy = false
		c.serverLine("info", "Logged in to your account (SASL)")
		c.writeLine("CAP END")
	case "900":
		c.serverLine("info", m.P(len(m.Params)-1))
	case "902", "904", "905", "906", "907", "908":
		if c.saslBusy {
			c.saslBusy = false
			c.serverLine("error", "SASL login failed: "+m.P(len(m.Params)-1)+" — check the SASL user name and password in the server settings")
			c.writeLine("CAP END")
		}
	case "322": // /list entry: me channel users :topic
		if c.listing {
			n, _ := strconv.Atoi(m.P(2))
			c.listTmp = append(c.listTmp, ListEntry{Channel: m.P(1), Users: n, Topic: stripListTopic(m.P(3))})
		}
	case "323": // end of /list
		if c.listing {
			c.listing = false
			sort.Slice(c.listTmp, func(i, j int) bool { return c.listTmp[i].Users > c.listTmp[j].Users })
			c.listDone, c.listTmp = c.listTmp, nil
			c.serverLine("info", fmt.Sprintf("Channel list received: %d channels", len(c.listDone)))
			c.emitBuf("*list")
		}
	case "001":
		c.registered = true
		c.status = "connected"
		c.nick = m.P(0)
		c.serverLine("info", m.P(1))
		cmds := append([]string(nil), c.cfg.Commands...)
		chans := append([]string(nil), c.cfg.Channels...)
		if len(cmds) == 0 {
			for _, ch := range chans {
				c.writeLine("JOIN " + ch)
			}
		} else {
			c.serverLine("info", fmt.Sprintf("Running your %d connect command(s)…", len(cmds)))
			go c.runConnectCommands(cmds, chans)
		}
		c.emitNet()
	case "005":
		for _, tok := range m.Params[1:] {
			if strings.HasPrefix(tok, "PREFIX=(") {
				v := tok[len("PREFIX=("):]
				if i := strings.IndexByte(v, ')'); i > 0 && len(v[i+1:]) == i {
					c.prefModes, c.prefSyms = v[:i], v[i+1:]
				}
			} else if strings.HasPrefix(tok, "CHANTYPES=") {
				c.chanTypes = tok[len("CHANTYPES="):]
			}
		}
	case "433", "432", "437":
		if !c.registered {
			c.nickTry++
			next := ""
			switch {
			case c.nickTry == 1 && c.altNick != "":
				next = c.altNick
			case c.nickTry <= 3:
				next = c.wantNick + strings.Repeat("_", c.nickTry)
			default:
				next = fmt.Sprintf("%s%d", c.wantNick, 100+int(time.Now().UnixNano()%900))
			}
			c.serverLine("error", fmt.Sprintf("Nickname %s is not available, trying %s", m.P(1), next))
			c.nick = next
			c.writeLine("NICK " + next)
		} else {
			c.serverLine("error", strings.Join(m.Params[1:], " "))
		}
	case "JOIN":
		ch := m.P(0)
		b := c.getBuf(ch, "channel", c.isMe(from))
		if b == nil {
			return
		}
		user, host := prefixUserHost(m.Prefix)
		if c.isMe(from) {
			b.Name, b.Joined, b.Users = ch, true, map[string]*Member{}
			b.Bans = nil
			c.quietWho[strings.ToLower(ch)] = true
			c.quietMode[strings.ToLower(ch)] = true
			c.addLine(b, Line{Kind: "join", Nick: from, Text: "You joined " + ch, Self: true})
			c.rememberChannel(ch, true)
			c.emitNet()
		} else {
			b.Users[strings.ToLower(from)] = &Member{Nick: from, User: user, Host: host}
			c.addLine(b, Line{Kind: "join", Nick: from, Text: from + " joined"})
		}
		c.emitBuf(b.Name)
	case "PART":
		b := c.getBuf(m.P(0), "channel", false)
		if b == nil {
			return
		}
		reason := ""
		if m.P(1) != "" {
			reason = " (" + m.P(1) + ")"
		}
		if c.isMe(from) {
			b.Joined, b.Users = false, map[string]*Member{}
			c.addLine(b, Line{Kind: "part", Nick: from, Text: "You left " + b.Name + reason, Self: true})
			c.rememberChannel(b.Name, false)
			c.emitNet()
		} else {
			delete(b.Users, strings.ToLower(from))
			c.addLine(b, Line{Kind: "part", Nick: from, Text: from + " left" + reason})
		}
		c.emitBuf(b.Name)
	case "KICK":
		ch, victim := m.P(0), m.P(1)
		b := c.getBuf(ch, "channel", false)
		if b == nil {
			return
		}
		if c.isMe(victim) {
			b.Joined, b.Users = false, map[string]*Member{}
			c.addLine(b, Line{Kind: "kick", Nick: from, Text: fmt.Sprintf("You were kicked by %s (%s)", from, m.P(2)), Highlight: true})
			c.emitNet()
		} else {
			delete(b.Users, strings.ToLower(victim))
			c.addLine(b, Line{Kind: "kick", Nick: from, Text: fmt.Sprintf("%s was kicked by %s (%s)", victim, from, m.P(2))})
		}
		c.emitBuf(b.Name)
	case "QUIT":
		key := strings.ToLower(from)
		for _, b := range c.buffers {
			if _, ok := b.Users[key]; ok && b.Kind == "channel" {
				delete(b.Users, key)
				c.addLine(b, Line{Kind: "quit", Nick: from, Text: from + " quit (" + m.P(0) + ")"})
				c.emitBuf(b.Name)
			} else if b.Kind == "query" && strings.EqualFold(b.Name, from) {
				c.addLine(b, Line{Kind: "quit", Nick: from, Text: from + " quit (" + m.P(0) + ")"})
			}
		}
	case "NICK":
		newNick := m.P(0)
		oldKey := strings.ToLower(from)
		if c.isMe(from) {
			c.nick = newNick
			c.serverLine("nick", "You are now known as "+newNick)
			c.emitNet()
		}
		for _, b := range c.buffers {
			if mem, ok := b.Users[oldKey]; ok && b.Kind == "channel" {
				delete(b.Users, oldKey)
				mem.Nick = newNick
				b.Users[strings.ToLower(newNick)] = mem
				c.addLine(b, Line{Kind: "nick", Nick: from, Text: from + " is now known as " + newNick})
				c.emitBuf(b.Name)
			}
		}
		if qb, ok := c.buffers[oldKey]; ok && qb.Kind == "query" {
			if _, taken := c.buffers[strings.ToLower(newNick)]; !taken {
				delete(c.buffers, oldKey)
				qb.Name = newNick
				c.buffers[strings.ToLower(newNick)] = qb
				c.addLine(qb, Line{Kind: "nick", Nick: from, Text: from + " is now known as " + newNick})
				c.emitNet()
			}
		}
	case "PRIVMSG", "NOTICE":
		c.handleMessage(m, from)
	case "TOPIC":
		if b := c.getBuf(m.P(0), "channel", false); b != nil {
			b.Topic = m.P(1)
			c.addLine(b, Line{Kind: "topic", Nick: from, Text: from + " changed the topic to: " + m.P(1)})
			c.emitBuf(b.Name)
		}
	case "332":
		if b := c.getBuf(m.P(1), "channel", false); b != nil {
			b.Topic = m.P(2)
			c.addLine(b, Line{Kind: "topic", Text: "Topic: " + m.P(2)})
			c.emitBuf(b.Name)
		}
	case "353":
		ch := m.P(2)
		b := c.getBuf(ch, "channel", false)
		if b == nil {
			c.serverLine("info", "Users in "+ch+": "+m.P(3))
			return
		}
		key := strings.ToLower(ch)
		if !c.names[key] {
			c.names[key] = true
			b.Users = map[string]*Member{}
		}
		for _, n := range strings.Fields(m.P(3)) {
			modes := ""
			for n != "" && strings.IndexByte(c.prefSyms, n[0]) >= 0 {
				modes += n[:1]
				n = n[1:]
			}
			user, host := "", ""
			if i := strings.IndexByte(n, '!'); i >= 0 {
				user, host = prefixUserHost(n)
				n = n[:i]
			}
			if n != "" {
				old := b.Users[strings.ToLower(n)]
				mem := &Member{Nick: n, Modes: modes, User: user, Host: host}
				if old != nil && mem.Host == "" {
					mem.User, mem.Host = old.User, old.Host
				}
				b.Users[strings.ToLower(n)] = mem
			}
		}
	case "366":
		k := strings.ToLower(m.P(1))
		delete(c.names, k)
		if b := c.getBuf(m.P(1), "channel", false); b != nil {
			c.emitBuf(b.Name)
			if c.quietWho[k] { // just joined: learn hosts (for bans) and channel modes
				c.writeLine("WHO " + b.Name)
			}
			if c.quietMode[k] {
				c.writeLine("MODE " + b.Name)
			}
		}
	case "352": // WHO reply: me channel user host server nick flags :hops realname
		ch, user, host, nick := m.P(1), m.P(2), m.P(3), m.P(5)
		if b := c.getBuf(ch, "channel", false); b != nil {
			if mem := b.Users[strings.ToLower(nick)]; mem != nil {
				mem.User, mem.Host = user, host
			}
		}
		if !c.quietWho[strings.ToLower(ch)] {
			c.serverLine("info", fmt.Sprintf("%s %s!%s@%s %s", ch, nick, user, host, m.P(7)))
		}
	case "315": // end of WHO
		k := strings.ToLower(m.P(1))
		if c.quietWho[k] {
			delete(c.quietWho, k)
		} else {
			c.serverLine("info", "End of WHO list")
		}
	case "324": // channel modes: me channel +modes args...
		k := strings.ToLower(m.P(1))
		if b := c.getBuf(m.P(1), "channel", false); b != nil {
			b.Modes, b.Key, b.Limit = parseChanModes(m.P(2), m.Params[3:])
			c.emitBuf(b.Name)
			if !c.quietMode[k] {
				c.addLine(b, Line{Kind: "mode", Text: "Channel modes: " + strings.Join(m.Params[2:], " ")})
			}
		}
		delete(c.quietMode, k)
	case "329": // channel creation time
	case "367": // ban list entry: me channel mask [setter time]
		if b := c.getBuf(m.P(1), "channel", false); b != nil {
			e := BanEntry{Mask: m.P(2), SetBy: m.P(3)}
			if t, err := strconv.ParseInt(m.P(4), 10, 64); err == nil {
				e.When = time.Unix(t, 0)
			}
			b.banTmp = append(b.banTmp, e)
			if !c.quietBans[strings.ToLower(b.Name)] {
				c.addLine(b, Line{Kind: "mode", Text: "Ban: " + e.Mask + " (set by " + e.SetBy + ")"})
			}
		}
	case "368": // end of ban list
		k := strings.ToLower(m.P(1))
		if b := c.getBuf(m.P(1), "channel", false); b != nil {
			b.Bans, b.banTmp = b.banTmp, nil
			c.emitBuf(b.Name)
			if !c.quietBans[k] {
				c.addLine(b, Line{Kind: "mode", Text: fmt.Sprintf("End of ban list (%d)", len(b.Bans))})
			}
		}
		delete(c.quietBans, k)
	case "302": // USERHOST reply: :nick*=+user@host nick2=-user@host
		handled := false
		for _, item := range strings.Fields(m.P(1)) {
			n, uh, ok := strings.Cut(item, "=")
			if !ok || len(uh) < 2 {
				continue
			}
			n = strings.TrimSuffix(n, "*")
			user, host, _ := strings.Cut(uh[1:], "@")
			if cbs := c.hostWait[strings.ToLower(n)]; cbs != nil {
				delete(c.hostWait, strings.ToLower(n))
				handled = true
				for _, f := range cbs {
					go f(user, host)
				}
			}
		}
		if !handled {
			c.serverLine("info", "Userhost: "+m.P(1))
		}
	case "MODE":
		target := m.P(0)
		text := strings.Join(m.Params[1:], " ")
		if c.isChannel(target) {
			if b := c.getBuf(target, "channel", false); b != nil {
				c.addLine(b, Line{Kind: "mode", Nick: from, Text: from + " sets mode " + text})
				if strings.ContainsAny(m.P(1), c.prefModes) {
					c.writeLine("NAMES " + target)
				}
				if strings.Trim(m.P(1), "+-"+c.prefModes+"b") != "" { // topic lock, key, limit, ...
					c.quietMode[strings.ToLower(target)] = true
					c.writeLine("MODE " + target)
				}
				if strings.Contains(m.P(1), "b") && b.Bans != nil { // keep the ban list current
					c.quietBans[strings.ToLower(target)] = true
					c.writeLine("MODE " + target + " +b")
				}
			}
		} else {
			c.serverLine("mode", "Mode for "+target+": "+text)
		}
	case "INVITE":
		c.serverLine("info", fmt.Sprintf("%s invited you to %s (type /join %s)", from, m.P(1), m.P(1)))
	case "ERROR":
		c.serverLine("error", "Server error: "+m.P(0))
	default:
		if len(m.Cmd) == 3 && m.Cmd[0] >= '0' && m.Cmd[0] <= '9' {
			c.handleNumeric(m)
		} else {
			c.serverLine("info", m.Cmd+" "+strings.Join(m.Params, " "))
		}
	}
}

func (c *Conn) handleNumeric(m msg) {
	switch m.Cmd {
	case "004", "005", "375", "376":
		return
	}
	kind := "info"
	if m.Cmd[0] == '4' || m.Cmd[0] == '5' {
		kind = "error"
	}
	params := m.Params
	if len(params) > 0 {
		params = params[1:]
	}
	if len(params) > 1 && c.isChannel(params[0]) {
		if b := c.getBuf(params[0], "channel", false); b != nil {
			c.addLine(b, Line{Kind: kind, Text: strings.Join(params[1:], " ")})
			return
		}
	}
	c.serverLine(kind, strings.Join(params, " "))
}

func (c *Conn) handleMessage(m msg, from string) {
	target, text := m.P(0), m.P(1)
	if from != "" && !c.isMe(from) && c.cl.IsIgnored(m.Prefix) {
		return
	}
	kind := "msg"
	if m.Cmd == "NOTICE" {
		kind = "notice"
	}
	if strings.HasPrefix(text, "\x01") {
		inner := strings.Trim(text, "\x01")
		cmd, rest, _ := strings.Cut(inner, " ")
		cmd = strings.ToUpper(cmd)
		if cmd == "ACTION" {
			kind, text = "action", rest
		} else {
			if m.Cmd == "PRIVMSG" {
				switch cmd {
				case "DCC":
					c.cl.dccIncoming(c, from, rest)
					return
				}
				if reply := ctcpAnswer(cmd, rest); reply != "" {
					c.writeLine("NOTICE " + from + " :\x01" + cmd + " " + reply + "\x01")
				} else if cmd != "" {
					c.writeLine("NOTICE " + from + " :\x01ERRMSG " + cmd + " :unknown request\x01")
				}
				c.serverLine("info", fmt.Sprintf("%s checked your client (CTCP %s)", from, cmd))
			} else {
				c.ctcpReply(from, cmd, rest)
			}
			return
		}
	}
	t := target
	for len(t) > 1 && strings.IndexByte(c.prefSyms, t[0]) >= 0 && c.isChannel(t[1:]) {
		t = t[1:]
	}
	var b *Buffer
	switch {
	case c.isChannel(t):
		b = c.getBuf(t, "channel", true)
	case !strings.Contains(m.Prefix, "!") || from == "" || !c.registered:
		b = c.buffers["*"]
	case kind == "notice":
		if b = c.getBuf(from, "query", false); b == nil {
			b = c.buffers["*"]
		}
	default:
		b = c.getBuf(from, "query", true)
		b.Name = from
	}
	c.addLine(b, Line{Kind: kind, Nick: from, Text: text, Self: c.isMe(from)})
}

// rememberChannel keeps the saved channel list in sync. Caller holds c.mu.
func (c *Conn) rememberChannel(ch string, add bool) {
	found := containsChan(c.cfg.Channels, ch)
	if add == found {
		return
	}
	if add {
		c.cfg.Channels = append(c.cfg.Channels, ch)
	} else {
		list := []string{}
		for _, x := range c.cfg.Channels {
			if !strings.EqualFold(strings.Fields(x)[0], ch) {
				list = append(list, x)
			}
		}
		c.cfg.Channels = list
	}
	go c.cl.Save()
}

// ---------------------------------------------------------------------------
// Typing: messages and /commands
// ---------------------------------------------------------------------------

// Input handles a line typed into window `target` ("*" = server window).
// It returns a window the UI should switch to (or "").
func (c *Conn) Input(target, text string) (string, error) {
	text = strings.TrimRight(text, "\r\n")
	if strings.TrimSpace(text) == "" {
		return "", nil
	}
	if strings.HasPrefix(text, "/") && !strings.HasPrefix(text, "//") {
		return c.command(target, text[1:])
	}
	if strings.HasPrefix(text, "//") {
		text = text[1:]
	}
	if target == "*" || target == "" {
		return "", errors.New("this is the server window — use /join #channel or /msg nick text")
	}
	if strings.HasPrefix(target, "=") { // DCC chat window
		return "", c.dccSay(target, "msg", text)
	}
	for _, l := range strings.Split(text, "\n") {
		if err := c.say(target, "msg", l); err != nil {
			return "", err
		}
	}
	return "", nil
}

func (c *Conn) online() error {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.sock == nil || !c.registered {
		return errors.New("not connected — use /connect")
	}
	return nil
}

func (c *Conn) say(target, kind, text string) error {
	if strings.TrimSpace(text) == "" {
		return nil
	}
	if err := c.online(); err != nil {
		return err
	}
	verb := "PRIVMSG"
	if kind == "notice" {
		verb = "NOTICE"
	}
	limit := 400 - len(target)
	if kind == "action" {
		limit -= 9
	}
	for _, chunk := range splitText(text, limit) {
		payload := chunk
		if kind == "action" {
			payload = "\x01ACTION " + chunk + "\x01"
		}
		if err := c.writeLine(verb + " " + target + " :" + payload); err != nil {
			return err
		}
		c.mu.Lock()
		bt := "query"
		if c.isChannel(target) {
			bt = "channel"
		}
		var b *Buffer
		if kind == "notice" {
			if b = c.getBuf(target, bt, false); b == nil {
				b = c.buffers["*"]
			}
			chunk = "→ " + target + ": " + chunk
		} else {
			b = c.getBuf(target, bt, true)
		}
		c.addLine(b, Line{Kind: kind, Nick: c.nick, Text: chunk, Self: true})
		c.mu.Unlock()
	}
	return nil
}

func splitText(s string, limit int) []string {
	if limit < 50 {
		limit = 50
	}
	var out []string
	for len(s) > limit {
		cut := limit
		for cut > 0 && !utf8.RuneStart(s[cut]) {
			cut--
		}
		if sp := strings.LastIndexByte(s[:cut], ' '); sp > limit/2 {
			cut = sp
		}
		out = append(out, s[:cut])
		s = strings.TrimLeft(s[cut:], " ")
	}
	if s != "" {
		out = append(out, s)
	}
	return out
}

func (c *Conn) command(target, line string) (string, error) {
	cmd, rest, _ := strings.Cut(line, " ")
	cmd = strings.ToLower(cmd)
	rest = strings.TrimSpace(rest)
	arg1, arg2, _ := strings.Cut(rest, " ")
	arg2 = strings.TrimSpace(arg2)

	switch cmd {
	case "dcc":
		return c.dccCommand(target, rest)
	case "connect", "reconnect":
		c.Connect()
		return "", nil
	case "disconnect":
		c.Disconnect(rest)
		return "", nil
	}
	if handled, out, err := c.cl.GlobalCommand("/" + line); handled {
		return out, err
	}
	if err := c.online(); err != nil {
		return "", err
	}
	switch cmd {
	case "join", "j":
		if arg1 == "" {
			return "", errors.New("usage: /join #channel [key]")
		}
		if !c.IsChannel(arg1) {
			arg1 = "#" + arg1
		}
		if arg2 != "" {
			return arg1, c.writeLine("JOIN " + arg1 + " " + arg2)
		}
		return arg1, c.writeLine("JOIN " + arg1)
	case "part", "leave":
		ch, reason := target, rest
		if c.IsChannel(arg1) {
			ch, reason = arg1, arg2
		}
		if !c.IsChannel(ch) {
			return "", errors.New("usage: /part #channel [reason]")
		}
		if reason != "" {
			return "", c.writeLine("PART " + ch + " :" + reason)
		}
		return "", c.writeLine("PART " + ch)
	case "msg", "privmsg", "m":
		if arg1 == "" || arg2 == "" {
			return "", errors.New("usage: /msg nick message")
		}
		return arg1, c.say(arg1, "msg", arg2)
	case "query", "q":
		if arg1 == "" {
			return "", errors.New("usage: /query nick [message]")
		}
		c.mu.Lock()
		c.getBuf(arg1, "query", true)
		c.mu.Unlock()
		if arg2 != "" {
			c.say(arg1, "msg", arg2)
		}
		return arg1, nil
	case "me", "action":
		if target == "*" {
			return "", errors.New("/me only works in a channel or private chat")
		}
		if strings.HasPrefix(target, "=") {
			return "", c.dccSay(target, "action", rest)
		}
		return "", c.say(target, "action", rest)
	case "notice":
		if arg1 == "" || arg2 == "" {
			return "", errors.New("usage: /notice target message")
		}
		return "", c.say(arg1, "notice", arg2)
	case "nick":
		if arg1 == "" {
			return "", errors.New("usage: /nick newnick")
		}
		return "", c.writeLine("NICK " + arg1)
	case "topic", "t":
		ch := target
		if c.IsChannel(arg1) {
			ch, rest = arg1, arg2
		}
		if rest == "" {
			return "", c.writeLine("TOPIC " + ch)
		}
		return "", c.writeLine("TOPIC " + ch + " :" + rest)
	case "ctcp":
		if arg1 == "" || arg2 == "" {
			return "", errors.New("usage: /ctcp nick VERSION|PING|TIME|CLIENTINFO|FINGER|USERINFO|SOURCE")
		}
		what, extra, _ := strings.Cut(arg2, " ")
		return "", c.CTCP(arg1, what, extra)
	case "version", "ver", "ping", "time", "clientinfo", "finger", "userinfo":
		if arg1 == "" {
			if cmd == "ping" { // plain /ping with no nick: ask the server
				return "", c.writeLine("PING :" + strconv.FormatInt(time.Now().UnixMilli(), 10))
			}
			return "", errors.New("usage: /" + cmd + " nick")
		}
		if cmd == "ver" {
			cmd = "version"
		}
		return "", c.CTCP(arg1, cmd, "")
	case "ban", "b", "kickban", "kb":
		if arg1 == "" || !c.IsChannel(target) {
			return "", errors.New("usage (in a channel): /" + cmd + " nick [mask type 1-6] [reason]  — types: 1 *!*@host 2 *!*user@host 3 *!user@host 4 *!*@*.domain 5 nick!*@* 6 nick!*@host")
		}
		t, reason := 0, arg2
		if f := strings.Fields(arg2); len(f) > 0 {
			if n, err := strconv.Atoi(f[0]); err == nil && n >= 1 && n <= len(BanMaskTypes) {
				t, reason = n-1, strings.TrimSpace(strings.TrimPrefix(arg2, f[0]))
			}
		}
		if strings.Contains(arg1, "!") || strings.Contains(arg1, "@") { // a mask was given
			return "", c.writeLine("MODE " + target + " +b " + arg1)
		}
		return "", c.Ban(target, arg1, t, cmd == "kickban" || cmd == "kb", reason)
	case "unban":
		if arg1 == "" || !c.IsChannel(target) {
			return "", errors.New("usage (in a channel): /unban mask")
		}
		return "", c.Unban(target, arg1)
	case "bans", "banlist":
		if !c.IsChannel(target) {
			return "", errors.New("use /bans in a channel")
		}
		return "", c.writeLine("MODE " + target + " +b")
	case "kick", "k":
		if arg1 == "" || !c.IsChannel(target) {
			return "", errors.New("usage (in a channel): /kick nick [reason]")
		}
		return "", c.writeLine("KICK " + target + " " + arg1 + " :" + arg2)
	case "op", "deop", "voice", "devoice":
		if arg1 == "" || !c.IsChannel(target) {
			return "", errors.New("usage (in a channel): /" + cmd + " nick")
		}
		m := map[string]string{"op": "+o", "deop": "-o", "voice": "+v", "devoice": "-v"}[cmd]
		return "", c.writeLine("MODE " + target + " " + m + " " + arg1)
	case "mode":
		return "", c.writeLine("MODE " + rest)
	case "whois", "w":
		return "", c.writeLine("WHOIS " + arg1)
	case "away":
		if rest == "" {
			return "", c.writeLine("AWAY")
		}
		return "", c.writeLine("AWAY :" + rest)
	case "back":
		return "", c.writeLine("AWAY")
	case "cycle", "rejoin", "hop":
		ch := target
		if arg1 != "" {
			ch = arg1
		}
		if !c.IsChannel(ch) {
			return "", errors.New("usage: /cycle #channel (or use it in a channel window)")
		}
		c.writeLine("PART " + ch + " :rejoining")
		return "", c.writeLine("JOIN " + ch)
	case "list":
		return "Asking the server for its channel list… (big networks can take a while)", c.RequestList(rest)
	case "umode":
		return "", c.writeLine("MODE " + c.Info().Nick + " " + rest)
	case "whowas":
		return "", c.writeLine("WHOWAS " + rest)
	case "motd", "lusers", "admin", "info", "links", "map", "stats", "users":
		return "", c.writeLine(strings.ToUpper(cmd) + " " + rest)
	case "invite":
		ch := target
		if c.IsChannel(arg2) {
			ch = arg2
		}
		return "", c.writeLine("INVITE " + arg1 + " " + ch)
	case "names":
		ch := target
		if arg1 != "" {
			ch = arg1
		}
		return "", c.writeLine("NAMES " + ch)
	case "ns", "nickserv":
		return "", c.writeLine("PRIVMSG NickServ :" + rest)
	case "cs", "chanserv":
		return "", c.writeLine("PRIVMSG ChanServ :" + rest)
	case "raw", "quote":
		if rest == "" {
			return "", errors.New("usage: /raw COMMAND params")
		}
		c.mu.Lock()
		c.serverLine("info", "→ "+rest)
		c.mu.Unlock()
		return "", c.writeLine(rest)
	default:
		return "", c.writeLine(strings.ToUpper(cmd) + " " + rest)
	}
}

// runConnectCommands sends the user's saved commands, then joins channels.
func (c *Conn) runConnectCommands(cmds, chans []string) {
	for i, line := range cmds {
		c.mu.Lock()
		online, nick := c.registered && c.sock != nil, c.nick
		c.mu.Unlock()
		if !online {
			return
		}
		line = strings.NewReplacer("$me", nick, "$nick", nick).Replace(line)
		lower := strings.ToLower(line)
		var err error
		switch {
		case strings.HasPrefix(lower, "/wait ") || strings.HasPrefix(lower, "/sleep "):
			secs, _ := strconv.ParseFloat(strings.Fields(line)[1], 64)
			if secs > 0 && secs <= 30 {
				time.Sleep(time.Duration(secs * float64(time.Second)))
			}
			continue
		case strings.HasPrefix(line, "/"):
			f := strings.SplitN(line[1:], " ", 3)
			verb := strings.ToLower(f[0])
			if (verb == "msg" || verb == "m" || verb == "privmsg" || verb == "notice") && len(f) == 3 {
				irc := "PRIVMSG"
				if verb == "notice" {
					irc = "NOTICE"
				}
				err = c.writeLine(irc + " " + f[1] + " :" + f[2]) // quietly (may contain a password)
			} else {
				_, err = c.command("*", line[1:])
			}
		default:
			err = c.writeLine(line)
		}
		if err != nil {
			c.mu.Lock()
			c.serverLine("error", fmt.Sprintf("Connect command #%d failed: %v", i+1, err))
			c.mu.Unlock()
		}
		time.Sleep(400 * time.Millisecond)
	}
	time.Sleep(1200 * time.Millisecond)
	for _, ch := range chans {
		c.writeLine("JOIN " + ch)
	}
}

// OpenQuery opens (or finds) a private chat window.
func (c *Conn) OpenQuery(nick string) string {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.getBuf(nick, "query", true).Name
}

// CloseBuffer leaves a channel / closes a private chat window.
func (c *Conn) CloseBuffer(name string) {
	c.mu.Lock()
	key := strings.ToLower(name)
	b, ok := c.buffers[key]
	if !ok || b.Kind == "server" {
		c.mu.Unlock()
		return
	}
	if b.Kind == "dcc" {
		if it := c.dccChats[key]; it != nil {
			delete(c.dccChats, key)
			go c.cl.dcc.close(it, "closed")
		}
	}
	joined := b.Joined && b.Kind == "channel" && c.sock != nil
	if b.Kind == "channel" {
		c.rememberChannel(b.Name, false)
	}
	delete(c.buffers, key)
	c.mu.Unlock()
	if joined {
		c.writeLine("PART " + b.Name)
	}
	c.emitNet()
}

// CompleteNick finds nicks in a window starting with prefix (for Tab).
func (c *Conn) CompleteNick(buf, prefix string) []string {
	prefix = strings.ToLower(prefix)
	var out []string
	for _, u := range c.Users(buf) {
		n := strings.TrimLeft(u, "~&@%+!")
		if strings.HasPrefix(strings.ToLower(n), prefix) {
			out = append(out, n)
		}
	}
	if bi, ok := c.Buffer(buf); ok && bi.Kind == "query" && strings.HasPrefix(strings.ToLower(bi.Name), prefix) {
		out = append(out, bi.Name)
	}
	return out
}

// PassLine builds the server password. With a server username (ZNC, BNC and
// most bouncers) it is sent as  username:password  — the username may be
// user/network to choose a network on the bouncer.
func PassLine(user, pass string) string {
	user = strings.TrimSpace(user)
	if user == "" {
		return pass
	}
	return user + ":" + pass
}
