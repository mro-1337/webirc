package core

import (
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
)

// ServerConfig is one IRC server in the settings file.
type ServerConfig struct {
	ID          string
	Name        string
	Host        string
	Port        int
	TLS         bool
	SelfSigned  bool
	ServerUser  string // bouncer login (ZNC/BNC): sent as PASS user:password
	Password    string
	Nick        string // empty = use the global nick
	AltNick     string
	Username    string
	Realname    string
	Channels    []string
	Commands    []string
	AutoConnect bool
	SASLUser    string // SASL login (account name) — used instead of NickServ on most networks
	SASLPass    string
}

func (s *ServerConfig) DisplayName() string {
	if s.Name != "" {
		return s.Name
	}
	return s.Host
}

func (s *ServerConfig) EffectivePort() int {
	if s.Port > 0 && s.Port <= 65535 {
		return s.Port
	}
	if s.TLS {
		return 6697
	}
	return 6667
}

// Settings is everything stored in the settings file.
type Settings struct {
	Nick     string
	AltNick  string
	Realname string
	Theme    string // dark, light, bbs, terminal, ...
	Font     string // desktop version: "Default", "Monospace" or an installed font's name
	FontSize int    // desktop version: text size (0 = normal, 14)
	ChanList string // where channels are listed: left, top or bottom

	// DCC (direct chats and file transfers)
	DCCPorts  string // port range to listen on, e.g. "5000-5010" ("" = any free port)
	DCCIP     string // your public IP / host name to give out ("" = automatic)
	Downloads string // folder for received files ("" = "downloads" next to the program)

	// Desktop version window settings
	Opacity     int     // 20..100 percent (100 = solid)
	HideLeft    bool    // hide the servers & channels pane
	HidePeople  bool    // hide the people pane
	LeftSplit   float64 // width of the left pane (0..1 of the window)
	RightSplit  float64 // where the people pane starts (0..1)
	TrayOnClose bool    // the close button hides the window to the tray
	ShowMedia   bool
	ShowJoins   bool
	Logging     bool
	Notify      bool     // desktop notification / terminal bell when someone mentions you
	Highlights  []string // extra words that count as a mention (besides your nick)
	Ignores     []string // people to ignore: nick or nick!user@host masks (* and ? allowed)
	Servers     []*ServerConfig
}

func DefaultSettings() *Settings {
	return &Settings{
		Nick:      defaultNick(),
		Realname:  "IRC user",
		Theme:     "dark",
		ShowMedia: true,
		ShowJoins: true,
		Logging:   true,
		Notify:    true,
	}
}

func newID() string {
	b := make([]byte, 4)
	rand.Read(b)
	return hex.EncodeToString(b)
}

var badNickChars = regexp.MustCompile("[^A-Za-z0-9_\\-\\[\\]\\\\^{}|`]")

func defaultNick() string {
	u := os.Getenv("USERNAME")
	if u == "" {
		u = os.Getenv("USER")
	}
	u = badNickChars.ReplaceAllString(u, "_")
	if u == "" || u == "root" || u == "Administrator" {
		u = "guest"
	}
	if u[0] >= '0' && u[0] <= '9' || u[0] == '-' {
		u = "_" + u
	}
	if len(u) > 15 {
		u = u[:15]
	}
	return u + strconv.Itoa(10+int(newIDNum()%90))
}

func newIDNum() uint32 {
	b := make([]byte, 4)
	rand.Read(b)
	return uint32(b[0])<<24 | uint32(b[1])<<16 | uint32(b[2])<<8 | uint32(b[3])
}

// SettingsPath returns the settings file, always next to the program (portable).
func SettingsPath(fileName string) string {
	return filepath.Join(ProgramDir(), fileName)
}

// LoadSettings reads the settings file, creating it with defaults if missing.
func LoadSettings(path string) (*Settings, error) {
	b, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		s := DefaultSettings()
		return s, SaveSettings(path, s)
	}
	if err != nil {
		return nil, err
	}
	return ParseSettings(string(b), filepath.Base(path))
}

func yesNo(b bool) string {
	if b {
		return "yes"
	}
	return "no"
}

func parseBool(v string) (bool, error) {
	switch strings.ToLower(v) {
	case "yes", "y", "true", "on", "1":
		return true, nil
	case "no", "n", "false", "off", "0", "":
		return false, nil
	}
	return false, fmt.Errorf("should be yes or no, not %q", v)
}

func normKey(k string) string {
	return strings.NewReplacer(" ", "", "_", "", "-", "").Replace(strings.ToLower(strings.TrimSpace(k)))
}

// ParseSettings reads the "setting: value" format.
func ParseSettings(text, fileName string) (*Settings, error) {
	s := &Settings{Theme: "dark", ShowMedia: true, ShowJoins: true, Logging: true, Notify: true}
	var cur *ServerConfig
	fail := func(n int, f string, a ...any) error {
		return fmt.Errorf("%s line %d: %s", fileName, n, fmt.Sprintf(f, a...))
	}
	text = strings.TrimPrefix(text, "\ufeff")
	for i, raw := range strings.Split(text, "\n") {
		n := i + 1
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "//") || strings.HasPrefix(line, ";") {
			continue
		}
		k, v, ok := strings.Cut(line, ":")
		if !ok {
			return nil, fail(n, "expected  setting: value  but found %q", line)
		}
		key, val := normKey(k), strings.TrimSpace(v)
		boolVal := func() (bool, error) {
			b, err := parseBool(val)
			if err != nil {
				return false, fail(n, "%s %v", strings.TrimSpace(k), err)
			}
			return b, nil
		}
		if key == "server" {
			if val == "" {
				return nil, fail(n, "server: needs an address")
			}
			cur = &ServerConfig{ID: newID(), Host: val, AutoConnect: true}
			s.Servers = append(s.Servers, cur)
			continue
		}
		if cur != nil {
			switch key {
			case "port":
				p, err := strconv.Atoi(val)
				if err != nil || p < 1 || p > 65535 {
					return nil, fail(n, "port must be a number from 1 to 65535")
				}
				cur.Port = p
			case "name":
				cur.Name = val
			case "encryption", "tls", "ssl":
				b, err := boolVal()
				if err != nil {
					return nil, err
				}
				cur.TLS = b
			case "selfsigned", "skipverify":
				b, err := boolVal()
				if err != nil {
					return nil, err
				}
				cur.SelfSigned = b
			case "password", "serverpassword":
				cur.Password = val
			case "serveruser", "serverusername", "login", "bounceruser":
				cur.ServerUser = val
			case "nick", "nickname":
				cur.Nick = val
			case "altnick":
				cur.AltNick = val
			case "username", "ident":
				cur.Username = val
			case "realname":
				cur.Realname = val
			case "channel", "channels":
				for _, c := range strings.Split(val, ",") {
					if c = strings.TrimSpace(c); c != "" {
						cur.Channels = append(cur.Channels, c)
					}
				}
			case "command":
				if val != "" {
					cur.Commands = append(cur.Commands, val)
				}
			case "sasluser", "saslusername", "saslaccount", "saslname", "saslnick":
				cur.SASLUser = val
			case "saslpassword", "saslpass":
				cur.SASLPass = val
			case "autoconnect", "connect":
				b, err := boolVal()
				if err != nil {
					return nil, err
				}
				cur.AutoConnect = b
			default:
				return nil, fail(n, "unknown server setting %q (global settings go above the first  server:  line)", strings.TrimSpace(k))
			}
			continue
		}
		switch key {
		case "nick", "nickname":
			s.Nick = val
		case "altnick":
			s.AltNick = val
		case "realname":
			s.Realname = val
		case "theme":
			s.Theme = strings.ToLower(val)
		case "channellist", "channels", "tabs", "layout":
			v := strings.ToLower(val)
			switch v {
			case "", "left", "pane", "leftpane", "side":
				s.ChanList = "left"
			case "top", "toptabs", "tabs":
				s.ChanList = "top"
			case "bottom", "bottomtabs":
				s.ChanList = "bottom"
			default:
				return nil, fail(n, "channellist must be left, top or bottom")
			}
		case "dccports", "dccport":
			if _, _, err := ParsePortRange(val); err != nil {
				return nil, fail(n, "%v", err)
			}
			s.DCCPorts = val
		case "dccip", "dcchost":
			s.DCCIP = val
		case "downloads", "downloadfolder", "dccfolder":
			s.Downloads = val
		case "opacity", "transparency":
			v, err := strconv.Atoi(strings.TrimSuffix(val, "%"))
			if err != nil || v < 20 || v > 100 {
				return nil, fail(n, "opacity must be a number from 20 to 100")
			}
			s.Opacity = v
		case "hideleftpane", "hideleft":
			b, err := boolVal()
			if err != nil {
				return nil, err
			}
			s.HideLeft = b
		case "hidepeople", "hidepeoplepane":
			b, err := boolVal()
			if err != nil {
				return nil, err
			}
			s.HidePeople = b
		case "leftpanesize", "leftsplit":
			v, _ := strconv.ParseFloat(val, 64)
			if v > 0.05 && v < 0.8 {
				s.LeftSplit = v
			}
		case "peoplepanesize", "rightsplit":
			v, _ := strconv.ParseFloat(val, 64)
			if v > 0.3 && v < 0.98 {
				s.RightSplit = v
			}
		case "trayonclose", "closetotray":
			b, err := boolVal()
			if err != nil {
				return nil, err
			}
			s.TrayOnClose = b
		case "font", "fontname", "fonttype":
			s.Font = val
		case "fontsize", "textsize":
			size, err := strconv.Atoi(val)
			if err != nil || size < 6 || size > 72 {
				return nil, fail(n, "fontsize must be a number from 6 to 72")
			}
			s.FontSize = size
		case "showmedia", "media", "images":
			b, err := boolVal()
			if err != nil {
				return nil, err
			}
			s.ShowMedia = b
		case "showjoins", "joins":
			b, err := boolVal()
			if err != nil {
				return nil, err
			}
			s.ShowJoins = b
		case "logging", "logs", "log":
			b, err := boolVal()
			if err != nil {
				return nil, err
			}
			s.Logging = b
		case "notify", "notifications", "beep", "alert":
			b, err := boolVal()
			if err != nil {
				return nil, err
			}
			s.Notify = b
		case "highlight", "highlights", "highlightwords":
			s.Highlights = appendWords(s.Highlights, val)
		case "ignore", "ignores":
			s.Ignores = appendWords(s.Ignores, val)
		case "port":
			return nil, fail(n, "port: belongs under a  server:  line")
		default:
			return nil, fail(n, "unknown setting %q", strings.TrimSpace(k))
		}
	}
	if s.Nick == "" {
		s.Nick = defaultNick()
	}
	for _, sc := range s.Servers {
		sc.Port = sc.EffectivePort()
		sc.Channels = cleanChannels(sc.Channels)
	}
	return s, nil
}

// SaveSettings writes the settings file (with explanations).
func SaveSettings(path string, s *Settings) error {
	text := RenderSettings(s)
	if runtime.GOOS == "windows" {
		text = strings.ReplaceAll(text, "\n", "\r\n")
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, []byte(text), 0600); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

// RenderSettings returns the settings in the file format (with explanations).
func RenderSettings(s *Settings) string {
	var b strings.Builder
	w := func(f string, a ...any) { b.WriteString(strings.TrimRight(fmt.Sprintf(f, a...), " ") + "\n") }
	w("# ================================================================")
	w("#  IRC client settings  (the program also saves this file itself)")
	w("#  Lines starting with # are notes.  Yes/no settings: yes or no")
	w("# ================================================================")
	w("")
	w("# Your nickname, backup nickname and real name")
	w("nick: %s", s.Nick)
	w("altnick: %s", s.AltNick)
	w("realname: %s", s.Realname)
	w("")
	w("# Look: dark, light, midnight, bbs, terminal, solarized-dark,")
	w("#       solarized-light, classic, high-contrast, dracula, nord,")
	w("#       gruvbox-dark, gruvbox-light, monokai, ocean, amber, sepia")
	w("theme: %s", s.Theme)
	w("")
	w("# Desktop version: font (Default, Monospace, or the name of an installed")
	w("# font, e.g. Arial, DejaVu Sans) and text size (normal is 14)")
	w("font: %s", s.Font)
	if s.FontSize > 0 {
		w("fontsize: %d", s.FontSize)
	} else {
		w("fontsize: 14")
	}
	w("")
	w("# Where servers and channels are listed: left (a pane on the left),")
	w("# top (tabs along the top) or bottom (tabs along the bottom)")
	if s.ChanList == "" {
		w("channellist: left")
	} else {
		w("channellist: %s", s.ChanList)
	}
	w("")
	w("# Desktop version window: opacity 20-100 (100 = solid), hide panes,")
	w("# pane sizes (saved when you drag the dividers), close button -> tray")
	op := s.Opacity
	if op == 0 {
		op = 100
	}
	w("opacity: %d", op)
	w("hideleftpane: %s", yesNo(s.HideLeft))
	w("hidepeople: %s", yesNo(s.HidePeople))
	if s.LeftSplit > 0 {
		w("leftpanesize: %.3f", s.LeftSplit)
	}
	if s.RightSplit > 0 {
		w("peoplepanesize: %.3f", s.RightSplit)
	}
	w("trayonclose: %s", yesNo(s.TrayOnClose))
	w("")
	w("# DCC (direct chats and file transfers)")
	w("#   dccports:  ports to listen on, e.g. 5000-5010 (forward these on your")
	w("#              router so people outside your network can connect). Empty = any.")
	w("#   dccip:     your public IP or host name. Empty = automatic (fine on a")
	w("#              home network; set it if you're behind a router).")
	w("#   downloads: folder for received files. Empty = \"downloads\" next to the program.")
	w("dccports: %s", s.DCCPorts)
	w("dccip: %s", s.DCCIP)
	w("downloads: %s", s.Downloads)
	w("")
	w("# Show pictures/videos posted in chat, and join/part messages")
	w("showmedia: %s", yesNo(s.ShowMedia))
	w("showjoins: %s", yesNo(s.ShowJoins))
	w("")
	w("# Save chat logs in the  logs  folder next to the program")
	w("logging: %s", yesNo(s.Logging))
	w("")
	w("# Mentions: notify = desktop notification (terminal: bell) when someone")
	w("# says your nick or one of your highlight words, or messages you privately.")
	w("# highlight: extra words, comma separated (e.g.  highlight: bob, pizza)")
	w("notify: %s", yesNo(s.Notify))
	w("highlight: %s", strings.Join(s.Highlights, ", "))
	w("")
	w("# People to ignore (one per line): a nick, or a mask like *!*@bad.host")
	for _, ig := range s.Ignores {
		w("ignore: %s", ig)
	}
	w("")
	w("# ------------------------- IRC servers -------------------------")
	w("# Each server starts with a  server:  line; the lines under it")
	w("# belong to it.  Optional per-server lines:")
	w("#   nick: / altnick: / username: / realname:  (override the above)")
	w("#   channel:  a channel to join (one per line)")
	w("#   command:  a command to run after connecting, one per line, e.g.")
	w("#             command: /msg NickServ IDENTIFY mypassword")
	w("#             command: /mode $me +x      ($me = your nick, /wait 2 = pause)")
	w("#   autoconnect: yes = connect when the program starts")
	w("#   sasluser: / saslpassword:  log in to your account (NickServ) while")
	w("#             connecting — the modern way, works on Libera, OFTC, etc.")
	w("#   serveruser: login name for a ZNC/BNC bouncer (sent with password:")
	w("#               as  user:password ; use user/network to pick a network)")
	for _, sc := range s.Servers {
		w("")
		w("server: %s", sc.Host)
		w("port: %d", sc.EffectivePort())
		w("name: %s", sc.Name)
		w("encryption: %s", yesNo(sc.TLS))
		w("selfsigned: %s", yesNo(sc.SelfSigned))
		w("serveruser: %s", sc.ServerUser)
		w("password: %s", sc.Password)
		w("autoconnect: %s", yesNo(sc.AutoConnect))
		if sc.Nick != "" {
			w("nick: %s", sc.Nick)
		}
		if sc.AltNick != "" {
			w("altnick: %s", sc.AltNick)
		}
		if sc.Username != "" {
			w("username: %s", sc.Username)
		}
		if sc.Realname != "" {
			w("realname: %s", sc.Realname)
		}
		for _, c := range sc.Channels {
			w("channel: %s", c)
		}
		for _, c := range sc.Commands {
			w("command: %s", c)
		}
		if sc.SASLUser != "" {
			w("sasluser: %s", sc.SASLUser)
			w("saslpassword: %s", sc.SASLPass)
		}
	}
	return b.String()
}

// appendWords adds comma-separated words to a list (no duplicates).
func appendWords(list []string, val string) []string {
	for _, w := range strings.Split(val, ",") {
		w = strings.TrimSpace(w)
		if w == "" {
			continue
		}
		dup := false
		for _, x := range list {
			if strings.EqualFold(x, w) {
				dup = true
			}
		}
		if !dup {
			list = append(list, w)
		}
	}
	return list
}

func cleanChannels(in []string) []string {
	out := []string{}
	seen := map[string]bool{}
	for _, c := range in {
		parts := strings.Fields(c)
		if len(parts) == 0 {
			continue
		}
		name := parts[0]
		if !strings.ContainsAny(name[:1], "#&+!") {
			name = "#" + name
		}
		if seen[strings.ToLower(name)] {
			continue
		}
		seen[strings.ToLower(name)] = true
		if len(parts) > 1 {
			name += " " + parts[1]
		}
		out = append(out, name)
	}
	return out
}
