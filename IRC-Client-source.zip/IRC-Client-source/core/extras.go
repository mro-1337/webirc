package core

// Channel list (/list), ignore list, highlight words, and commands that
// work without a server (/ignore, /import, /export, /highlight).

import (
	"errors"
	"fmt"
	"os"
	"regexp"
	"strings"
)

// ---------------------------------------------------------------------------
// Channel list
// ---------------------------------------------------------------------------

type ListEntry struct {
	Channel string
	Users   int
	Topic   string
}

var listModesRe = regexp.MustCompile(`^\[\+[^\]]*\]\s*`)

func stripListTopic(t string) string {
	return strings.TrimSpace(listModesRe.ReplaceAllString(StripFormatting(t), ""))
}

// RequestList asks the server for its channels. When it's done an EvBuffer
// event with Buf "*list" is sent; read the result with ChannelList.
func (c *Conn) RequestList(filter string) error {
	if err := c.online(); err != nil {
		return err
	}
	c.mu.Lock()
	c.listing, c.listTmp = true, nil
	c.mu.Unlock()
	if f := strings.TrimSpace(filter); f != "" && (strings.HasPrefix(f, ">") || strings.HasPrefix(f, "<") || c.IsChannel(f)) {
		return c.writeLine("LIST " + f)
	}
	return c.writeLine("LIST")
}

// ChannelList returns the last channel list (biggest first), filtered by
// text in the name or topic. busy = still receiving.
func (c *Conn) ChannelList(filter string) (list []ListEntry, busy bool, received int) {
	c.mu.Lock()
	defer c.mu.Unlock()
	f := strings.ToLower(strings.TrimSpace(filter))
	for _, e := range c.listDone {
		if f == "" || strings.Contains(strings.ToLower(e.Channel), f) || strings.Contains(strings.ToLower(e.Topic), f) {
			list = append(list, e)
		}
	}
	return list, c.listing, len(c.listTmp)
}

// ---------------------------------------------------------------------------
// Ignore list and highlight words
// ---------------------------------------------------------------------------

// wildMatch matches s against a pattern with * and ? (case-insensitive).
func wildMatch(pattern, s string) bool {
	p, t := []rune(strings.ToLower(pattern)), []rune(strings.ToLower(s))
	pi, ti, star, mark := 0, 0, -1, 0
	for ti < len(t) {
		if pi < len(p) && (p[pi] == '?' || p[pi] == t[ti]) {
			pi++
			ti++
		} else if pi < len(p) && p[pi] == '*' {
			star, mark = pi, ti
			pi++
		} else if star >= 0 {
			pi, mark = star+1, mark+1
			ti = mark
		} else {
			return false
		}
	}
	for pi < len(p) && p[pi] == '*' {
		pi++
	}
	return pi == len(p)
}

// fullMask turns "nick" into "nick!*@*" and "user@host" into "*!user@host".
func fullMask(m string) string {
	m = strings.TrimSpace(m)
	switch {
	case strings.Contains(m, "!"):
		if !strings.Contains(m, "@") {
			return m + "@*"
		}
		return m
	case strings.Contains(m, "@"):
		return "*!" + m
	}
	return m + "!*@*"
}

// IsIgnored reports whether a nick!user@host is on the ignore list.
func (cl *Client) IsIgnored(prefix string) bool {
	cl.mu.Lock()
	list := cl.settings.Ignores
	cl.mu.Unlock()
	if len(list) == 0 {
		return false
	}
	if !strings.Contains(prefix, "!") {
		prefix += "!*@*"
	}
	for _, m := range list {
		if wildMatch(fullMask(m), prefix) {
			return true
		}
	}
	return false
}

func (cl *Client) matchesHighlight(text string) bool {
	cl.mu.Lock()
	words := cl.settings.Highlights
	cl.mu.Unlock()
	low := strings.ToLower(text)
	for _, w := range words {
		w = strings.ToLower(strings.TrimSpace(w))
		if w == "" {
			continue
		}
		for i := 0; ; {
			j := strings.Index(low[i:], w)
			if j < 0 {
				break
			}
			a, b := i+j, i+j+len(w)
			if (a == 0 || !isWordByte(low[a-1])) && (b == len(low) || !isWordByte(low[b])) {
				return true
			}
			i = a + 1
		}
	}
	return false
}

func isWordByte(b byte) bool {
	return b >= 'a' && b <= 'z' || b >= '0' && b <= '9' || b == '_' || b >= 0x80
}

// Ignore adds people to the ignore list (nick or mask).
func (cl *Client) Ignore(mask string) error {
	mask = strings.TrimSpace(mask)
	if mask == "" || strings.Contains(mask, " ") {
		return errors.New("usage: /ignore nick   or   /ignore *!*@host")
	}
	return cl.SetGlobal(func(s *Settings) { s.Ignores = appendWords(s.Ignores, mask) })
}

// Unignore removes an entry from the ignore list.
func (cl *Client) Unignore(mask string) error {
	found := false
	err := cl.SetGlobal(func(s *Settings) {
		out := []string{}
		for _, m := range s.Ignores {
			if strings.EqualFold(m, mask) || strings.EqualFold(fullMask(m), fullMask(mask)) {
				found = true
				continue
			}
			out = append(out, m)
		}
		s.Ignores = out
	})
	if err == nil && !found {
		err = fmt.Errorf("%s isn't on your ignore list", mask)
	}
	return err
}

// GlobalCommand runs commands that don't need a server. line starts with "/".
func (cl *Client) GlobalCommand(line string) (handled bool, out string, err error) {
	if !strings.HasPrefix(line, "/") {
		return false, "", nil
	}
	cmd, rest, _ := strings.Cut(strings.TrimSpace(line[1:]), " ")
	rest = strings.TrimSpace(rest)
	switch strings.ToLower(cmd) {
	case "ignore":
		if rest == "" || strings.EqualFold(rest, "list") {
			g := cl.Global()
			if len(g.Ignores) == 0 {
				return true, "Your ignore list is empty. /ignore nick (or /ignore *!*@host) adds someone.", nil
			}
			return true, "Ignoring: " + strings.Join(g.Ignores, ", ") + "   (/unignore nick removes)", nil
		}
		if err := cl.Ignore(rest); err != nil {
			return true, "", err
		}
		return true, "Now ignoring " + rest + " (messages, notices, CTCP and DCC offers).", nil
	case "unignore":
		if err := cl.Unignore(rest); err != nil {
			return true, "", err
		}
		return true, "No longer ignoring " + rest, nil
	case "highlight", "hilight":
		if rest == "" {
			g := cl.Global()
			return true, "Highlight words: " + firstNonEmpty(strings.Join(g.Highlights, ", "), "(none — only your nick)") +
				"   /highlight add word · /highlight del word", nil
		}
		sub, word, _ := strings.Cut(rest, " ")
		word = strings.TrimSpace(word)
		switch strings.ToLower(sub) {
		case "add":
			return true, "Added highlight word: " + word, cl.SetGlobal(func(s *Settings) { s.Highlights = appendWords(s.Highlights, word) })
		case "del", "remove", "rm":
			return true, "Removed highlight word: " + word, cl.SetGlobal(func(s *Settings) {
				out := []string{}
				for _, w := range s.Highlights {
					if !strings.EqualFold(w, word) {
						out = append(out, w)
					}
				}
				s.Highlights = out
			})
		}
		return true, "", errors.New("usage: /highlight add word   or   /highlight del word")
	case "import":
		withSettings := false
		if f := strings.Fields(rest); len(f) > 1 && strings.EqualFold(f[len(f)-1], "all") {
			withSettings = true
			rest = strings.TrimSpace(rest[:len(rest)-3])
		}
		rest = strings.Trim(rest, `"'`)
		if rest == "" {
			return true, "", errors.New("usage: /import path/to/file [all]   (all = also nick, theme and other settings)")
		}
		r, err := cl.Import(rest, withSettings)
		if err != nil {
			return true, "", err
		}
		return true, r.Summary(), nil
	case "export":
		rest = strings.Trim(rest, `"'`)
		if rest == "" {
			return true, "", errors.New("usage: /export path/to/file.txt")
		}
		if err := cl.Export(rest); err != nil {
			return true, "", err
		}
		return true, "Saved your servers and settings to " + rest + " (it includes passwords — keep it safe)", nil
	}
	return false, "", nil
}

// Export writes the current servers and settings to a file.
func (cl *Client) Export(path string) error {
	cl.Save()
	cl.mu.Lock()
	s := *cl.settings
	cl.mu.Unlock()
	if _, err := os.Stat(path); err == nil {
		return errors.New("that file already exists — pick another name")
	}
	return SaveSettings(path, &s)
}

// ExportText is the servers and settings in the file format.
func (cl *Client) ExportText() string {
	cl.Save()
	cl.mu.Lock()
	s := *cl.settings
	cl.mu.Unlock()
	return RenderSettings(&s)
}
