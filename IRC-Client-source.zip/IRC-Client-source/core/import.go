package core

// Importing servers (and optionally settings) from other files:
//   - this program's own settings file (irc-client.txt) or an exported copy
//   - WebIRC-style "setting: value" files (unknown lines are skipped)
//   - HexChat  servlist.conf
//   - mIRC     servers.ini
//   - a plain list: one server per line, e.g.
//       irc.libera.chat 6697 tls #linux #go
//       ircs://irc.oftc.net:6697/#debian
//       irc.example.net:6667

import (
	"errors"
	"fmt"
	"os"
	"regexp"
	"strconv"
	"strings"
)

type ImportResult struct {
	Format   string
	Added    []string
	Updated  []string
	Settings bool
	Warnings []string
}

func (r ImportResult) Summary() string {
	var parts []string
	if len(r.Added) > 0 {
		parts = append(parts, fmt.Sprintf("added %d server(s) (%s)", len(r.Added), shortList(r.Added)))
	}
	if len(r.Updated) > 0 {
		parts = append(parts, fmt.Sprintf("updated %d you already had (%s)", len(r.Updated), shortList(r.Updated)))
	}
	if len(r.Added) == 0 && len(r.Updated) == 0 {
		parts = append(parts, "no servers found")
	}
	if r.Settings {
		parts = append(parts, "settings (nick, theme, …) imported")
	}
	if len(r.Warnings) > 0 {
		parts = append(parts, fmt.Sprintf("%d line(s) skipped: %s", len(r.Warnings), shortList(r.Warnings)))
	}
	return "Imported from a " + r.Format + " file: " + strings.Join(parts, " · ")
}

func shortList(l []string) string {
	if len(l) > 5 {
		return strings.Join(l[:5], ", ") + fmt.Sprintf(", and %d more", len(l)-5)
	}
	return strings.Join(l, ", ")
}

var lineNumRe = regexp.MustCompile(`line (\d+): (.*)`)

// ReadImport reads servers from a file in any supported format. globals is
// the "setting: value" text above the first server (only for that format).
func ReadImport(path string) (servers []*ServerConfig, globals, format string, warnings []string, err error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, "", "", nil, err
	}
	if len(data) > 5<<20 {
		return nil, "", "", nil, errors.New("that file is too big to be a settings file")
	}
	text := strings.ReplaceAll(strings.TrimPrefix(string(data), "\ufeff"), "\r\n", "\n")
	lines := strings.Split(text, "\n")
	has := func(re string) bool { return regexp.MustCompile(`(?mi)` + re).MatchString(text) }
	switch {
	case has(`^N=`) && has(`^S=`):
		s := parseHexChat(lines)
		return s, "", "HexChat", nil, nil
	case has(`^\[servers\]`) || has(`^n\d+=.*SERVER:`):
		s := parseMIRC(lines)
		return s, "", "mIRC", nil, nil
	case has(`^\s*server\s*:`):
		// "setting: value" — skip lines we don't understand
		for tries := 0; tries < 1000; tries++ {
			st, perr := ParseSettings(strings.Join(lines, "\n"), "file")
			if perr == nil {
				var g []string
				for _, l := range lines {
					if k, _, ok := strings.Cut(strings.TrimSpace(l), ":"); ok && normKey(k) == "server" {
						break
					}
					g = append(g, l)
				}
				return st.Servers, strings.Join(g, "\n"), "settings", warnings, nil
			}
			m := lineNumRe.FindStringSubmatch(perr.Error())
			if m == nil {
				return nil, "", "", nil, perr
			}
			n, _ := strconv.Atoi(m[1])
			if n < 1 || n > len(lines) {
				return nil, "", "", nil, perr
			}
			warnings = append(warnings, fmt.Sprintf("line %d (%s)", n, strings.TrimSpace(m[2])))
			if k, _, _ := strings.Cut(strings.TrimSpace(lines[n-1]), ":"); normKey(k) == "server" {
				lines[n-1] = "server: invalid.invalid" // keep the block structure
			} else {
				lines[n-1] = "# " + lines[n-1]
			}
		}
		return nil, "", "", warnings, errors.New("too many lines in that file could not be understood")
	default:
		s := parsePlainList(lines)
		if len(s) == 0 {
			return nil, "", "", nil, errors.New("no servers found in that file (supported: this program's settings file, WebIRC config, HexChat servlist.conf, mIRC servers.ini, or one server per line)")
		}
		return s, "", "server list", nil, nil
	}
}

func parseHexChat(lines []string) []*ServerConfig {
	var out []*ServerConfig
	var cur *ServerConfig
	var flags, login int
	var user, pass string
	finish := func() {
		if cur == nil || cur.Host == "" {
			return
		}
		if flags&4 != 0 {
			cur.TLS = true
		}
		cur.SelfSigned = flags&32 != 0
		cur.AutoConnect = flags&8 != 0
		if flags&2 != 0 { // "use global user information"
			cur.Nick, cur.AltNick, cur.Username, cur.Realname = "", "", "", ""
		} else if user != "" {
			cur.Username = user
		}
		if pass != "" {
			switch login {
			case 6: // SASL PLAIN
				cur.SASLUser, cur.SASLPass = firstNonEmpty(user, cur.Nick), pass
			case 1, 2, 9: // NickServ
				cur.Commands = append(cur.Commands, "/msg NickServ IDENTIFY "+pass)
			default:
				cur.Password = pass
			}
		}
		cur.Port = cur.EffectivePort()
		out = append(out, cur)
	}
	for _, l := range lines {
		l = strings.TrimRight(l, "\r")
		if len(l) < 2 || l[1] != '=' {
			continue
		}
		k, v := l[0], l[2:]
		if k == 'N' {
			finish()
			cur, flags, login, user, pass = &ServerConfig{Name: v}, 0, 0, "", ""
			continue
		}
		if cur == nil {
			continue
		}
		switch k {
		case 'S':
			if cur.Host == "" {
				h, p, _ := strings.Cut(v, "/")
				cur.Host = h
				if strings.HasPrefix(p, "+") {
					cur.TLS = true
					p = p[1:]
				}
				cur.Port, _ = strconv.Atoi(p)
			}
		case 'J':
			chans, _, _ := strings.Cut(v, " ")
			cur.Channels = append(cur.Channels, strings.Split(chans, ",")...)
		case 'C':
			if v = strings.TrimSpace(v); v != "" {
				if !strings.HasPrefix(v, "/") {
					v = "/" + v
				}
				cur.Commands = append(cur.Commands, v)
			}
		case 'I':
			cur.Nick = v
		case 'i':
			cur.AltNick = v
		case 'U':
			user = v
		case 'R':
			cur.Realname = v
		case 'P':
			pass = v
		case 'L':
			login, _ = strconv.Atoi(v)
		case 'F':
			flags, _ = strconv.Atoi(v)
		}
	}
	finish()
	return out
}

var mircRe = regexp.MustCompile(`(?i)^n\d+=(.*?)SERVER:([^:]+):([^G]*?)(?:GROUP:(.*))?$`)

func parseMIRC(lines []string) []*ServerConfig {
	var out []*ServerConfig
	seen := map[string]bool{}
	for _, l := range lines {
		m := mircRe.FindStringSubmatch(strings.TrimSpace(l))
		if m == nil {
			continue
		}
		group := strings.TrimSpace(m[4])
		key := strings.ToLower(firstNonEmpty(group, m[2]))
		if seen[key] { // mIRC lists many servers per network; take the first
			continue
		}
		seen[key] = true
		sc := &ServerConfig{Name: firstNonEmpty(group, strings.TrimSpace(m[1])), Host: m[2]}
		port := strings.Split(strings.Split(m[3], ",")[0], "-")[0]
		if strings.HasPrefix(port, "+") {
			sc.TLS = true
			port = port[1:]
		}
		sc.Port, _ = strconv.Atoi(port)
		sc.Port = sc.EffectivePort()
		out = append(out, sc)
	}
	return out
}

var ircURLRe = regexp.MustCompile(`(?i)^(ircs?)://([^/:]+)(?::(\+?\d+))?/?(.*)$`)

func parsePlainList(lines []string) []*ServerConfig {
	var out []*ServerConfig
	for _, l := range lines {
		l = strings.TrimSpace(l)
		if l == "" || strings.HasPrefix(l, "#") && !strings.Contains(l, ".") || strings.HasPrefix(l, ";") || strings.HasPrefix(l, "//") {
			continue
		}
		f := strings.Fields(l)
		sc := &ServerConfig{}
		if m := ircURLRe.FindStringSubmatch(f[0]); m != nil {
			sc.Host, sc.TLS = m[2], strings.EqualFold(m[1], "ircs")
			p := m[3]
			if strings.HasPrefix(p, "+") {
				sc.TLS, p = true, p[1:]
			}
			sc.Port, _ = strconv.Atoi(p)
			for _, ch := range strings.Split(m[4], ",") {
				if ch = strings.TrimSpace(ch); ch != "" {
					if !strings.HasPrefix(ch, "#") && !strings.HasPrefix(ch, "&") {
						ch = "#" + ch
					}
					sc.Channels = append(sc.Channels, ch)
				}
			}
		} else {
			h := f[0]
			if i := strings.LastIndexAny(h, ":/"); i > 0 && strings.Count(h, ":") <= 1 {
				p := h[i+1:]
				if strings.HasPrefix(p, "+") {
					sc.TLS, p = true, p[1:]
				}
				if n, err := strconv.Atoi(p); err == nil {
					sc.Port, h = n, h[:i]
				}
			}
			if !strings.Contains(h, ".") && !strings.Contains(h, ":") && h != "localhost" {
				continue // not a host name
			}
			sc.Host = h
		}
		for _, w := range f[1:] {
			lw := strings.ToLower(w)
			switch {
			case lw == "tls" || lw == "ssl" || lw == "secure" || lw == "encrypted":
				sc.TLS = true
			case lw == "selfsigned" || lw == "insecure":
				sc.SelfSigned = true
			case strings.HasPrefix(w, "#") || strings.HasPrefix(w, "&"):
				sc.Channels = append(sc.Channels, strings.Split(w, ",")...)
			case strings.HasPrefix(w, "+"):
				if n, err := strconv.Atoi(w[1:]); err == nil {
					sc.Port, sc.TLS = n, true
				}
			default:
				if n, err := strconv.Atoi(w); err == nil && n > 0 && n < 65536 {
					sc.Port = n
				}
			}
		}
		if sc.Port == 6697 {
			sc.TLS = true
		}
		sc.Port = sc.EffectivePort()
		out = append(out, sc)
	}
	return out
}

// Import adds the servers from a file (servers you already have are updated:
// new channels and commands are added, filled-in fields replace yours).
// withSettings also imports nick, theme and other global settings.
func (cl *Client) Import(path string, withSettings bool) (ImportResult, error) {
	servers, globals, format, warnings, err := ReadImport(path)
	if err != nil {
		return ImportResult{}, err
	}
	r := ImportResult{Format: format, Warnings: warnings}
	for _, sc := range servers {
		if sc.Host == "invalid.invalid" {
			continue
		}
		if validateServer(sc) != nil {
			r.Warnings = append(r.Warnings, "server "+sc.Host)
			continue
		}
		var match *Conn
		for _, c := range cl.Conns() {
			cfg := c.Config()
			if strings.EqualFold(cfg.Host, sc.Host) && cfg.EffectivePort() == sc.EffectivePort() {
				match = c
				break
			}
		}
		if match == nil {
			c, err := cl.addServer(*sc, sc.AutoConnect && format == "settings")
			if err != nil {
				r.Warnings = append(r.Warnings, sc.Host+": "+err.Error())
				continue
			}
			cfg := c.Config()
			r.Added = append(r.Added, cfg.DisplayName())
			continue
		}
		cur := match.Config()
		set := func(dst *string, v string) {
			if v != "" {
				*dst = v
			}
		}
		set(&cur.Name, sc.Name)
		set(&cur.Password, sc.Password)
		set(&cur.ServerUser, sc.ServerUser)
		set(&cur.Nick, sc.Nick)
		set(&cur.AltNick, sc.AltNick)
		set(&cur.Username, sc.Username)
		set(&cur.Realname, sc.Realname)
		set(&cur.SASLUser, sc.SASLUser)
		set(&cur.SASLPass, sc.SASLPass)
		cur.TLS = sc.TLS
		cur.SelfSigned = cur.SelfSigned || sc.SelfSigned
		cur.Channels = append(cur.Channels, sc.Channels...)
		for _, cmd := range sc.Commands {
			dup := false
			for _, x := range cur.Commands {
				if x == cmd {
					dup = true
				}
			}
			if !dup {
				cur.Commands = append(cur.Commands, cmd)
			}
		}
		if err := cl.UpdateServer(cur); err != nil {
			r.Warnings = append(r.Warnings, sc.Host+": "+err.Error())
			continue
		}
		r.Updated = append(r.Updated, cur.DisplayName())
	}
	if withSettings && format == "settings" && strings.TrimSpace(globals) != "" {
		cl.mu.Lock()
		base := *cl.settings
		cl.mu.Unlock()
		base.Servers = nil
		ng, err := ParseSettings(RenderSettings(&base)+"\n"+globals, "import")
		if err == nil {
			cl.SetGlobal(func(st *Settings) {
				keep := st.Servers
				*st = *ng
				st.Servers = keep
			})
			r.Settings = true
		} else {
			r.Warnings = append(r.Warnings, "settings: "+err.Error())
		}
	}
	return r, nil
}
