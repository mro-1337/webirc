package core

// Video previews and playback use ffmpeg (a free program). Put ffmpeg.exe
// (Windows) or ffmpeg (Linux) next to the IRC client, or install it
// (Linux: sudo apt install ffmpeg). Without it, videos open in your normal player.

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"image"
	"image/png"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"sync"
	"time"
)

var ErrNoFFmpeg = errors.New("ffmpeg not found — put ffmpeg next to the program to preview and play videos here")

var ffmpegOnce struct {
	sync.Mutex
	path    string
	checked time.Time
}

// FFmpegPath finds ffmpeg: next to the program first (portable), then in a
// "ffmpeg" or "ffmpeg/bin" folder next to it, then on the system PATH.
func FFmpegPath() string {
	ffmpegOnce.Lock()
	defer ffmpegOnce.Unlock()
	if ffmpegOnce.path != "" || time.Since(ffmpegOnce.checked) < 20*time.Second {
		return ffmpegOnce.path
	}
	ffmpegOnce.checked = time.Now()
	name := "ffmpeg"
	if runtime.GOOS == "windows" {
		name = "ffmpeg.exe"
	}
	dir := ProgramDir()
	for _, p := range []string{
		filepath.Join(dir, name),
		filepath.Join(dir, "ffmpeg", name),
		filepath.Join(dir, "ffmpeg", "bin", name),
	} {
		if st, err := os.Stat(p); err == nil && !st.IsDir() {
			ffmpegOnce.path = p
			return p
		}
	}
	if p, err := exec.LookPath("ffmpeg"); err == nil {
		ffmpegOnce.path = p
	}
	return ffmpegOnce.path
}

// HaveFFmpeg reports whether videos can be previewed / played inside the client.
func HaveFFmpeg() bool { return FFmpegPath() != "" }

func ffmpegCmd(ctx context.Context, args ...string) (*exec.Cmd, error) {
	p := FFmpegPath()
	if p == "" {
		return nil, ErrNoFFmpeg
	}
	base := []string{"-hide_banner", "-loglevel", "error", "-nostdin",
		"-user_agent", "Mozilla/5.0 (compatible; IRC client video preview)"}
	cmd := exec.CommandContext(ctx, p, append(base, args...)...)
	hideConsole(cmd)
	return cmd, nil
}

// videoFrame grabs one picture from near the start of a video.
func videoFrame(u string) (image.Image, error) {
	try := func(seek string) (image.Image, error) {
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()
		args := []string{}
		if seek != "" {
			args = append(args, "-ss", seek)
		}
		args = append(args, "-i", u, "-frames:v", "1", "-vf", "scale='min(960,iw)':-2", "-f", "image2pipe", "-vcodec", "png", "-")
		cmd, err := ffmpegCmd(ctx, args...)
		if err != nil {
			return nil, err
		}
		var out, errOut bytes.Buffer
		cmd.Stdout, cmd.Stderr = &out, &errOut
		if err := cmd.Run(); err != nil && out.Len() == 0 {
			msg := bytes.TrimSpace(errOut.Bytes())
			if len(msg) > 200 {
				msg = msg[:200]
			}
			return nil, fmt.Errorf("ffmpeg: %v %s", err, msg)
		}
		if out.Len() == 0 {
			return nil, errors.New("no picture in video")
		}
		return png.Decode(&out)
	}
	img, err := try("1")
	if err != nil {
		img, err = try("") // very short video: use the first frame
	}
	return img, err
}

// VideoPlayer plays a video's pictures inside the client (no sound).
type VideoPlayer struct {
	cancel context.CancelFunc
	done   chan struct{}
	W, H   int
}

// PlayVideo starts decoding a video at w x h pixels. onFrame is called for
// each picture (from a background goroutine) at normal playback speed;
// onEnd is called once when the video ends, fails or is stopped.
func PlayVideo(u string, w, h int, onFrame func(*image.RGBA), onEnd func(error)) (*VideoPlayer, error) {
	if w%2 == 1 {
		w--
	}
	if h%2 == 1 {
		h--
	}
	if w < 2 || h < 2 {
		return nil, errors.New("bad video size")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cmd, err := ffmpegCmd(ctx, "-re", "-i", u, "-an", "-sn",
		"-vf", "scale="+strconv.Itoa(w)+":"+strconv.Itoa(h)+",fps=30",
		"-f", "rawvideo", "-pix_fmt", "rgba", "-")
	if err != nil {
		cancel()
		return nil, err
	}
	out, err := cmd.StdoutPipe()
	if err != nil {
		cancel()
		return nil, err
	}
	var errOut bytes.Buffer
	cmd.Stderr = &errOut
	if err := cmd.Start(); err != nil {
		cancel()
		return nil, err
	}
	p := &VideoPlayer{cancel: cancel, done: make(chan struct{}), W: w, H: h}
	go func() {
		defer close(p.done)
		size := w * h * 4
		frames := 0
		var rerr error
		for {
			buf := make([]byte, size)
			if _, err := io.ReadFull(out, buf); err != nil {
				if !errors.Is(err, io.EOF) && !errors.Is(err, io.ErrUnexpectedEOF) && ctx.Err() == nil {
					rerr = err
				}
				break
			}
			frames++
			onFrame(&image.RGBA{Pix: buf, Stride: w * 4, Rect: image.Rect(0, 0, w, h)})
		}
		cmd.Wait()
		if frames == 0 && ctx.Err() == nil && rerr == nil {
			msg := bytes.TrimSpace(errOut.Bytes())
			if len(msg) > 200 {
				msg = msg[:200]
			}
			rerr = fmt.Errorf("couldn't play this video %s", msg)
		}
		onEnd(rerr)
	}()
	return p, nil
}

// Stop ends playback.
func (p *VideoPlayer) Stop() {
	if p != nil {
		p.cancel()
	}
}
