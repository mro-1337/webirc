package core

// CTCP: asking another person's client for its version, ping (lag), time ...
// and answering when they ask ours.

import (
	"errors"
	"fmt"
	"runtime"
	"strconv"
	"strings"
	"time"
)

// AppVersion is shown when someone asks for your client's version.
const AppVersion = "2.2"

func versionString() string {
	return fmt.Sprintf("IRC Client %s (Go, %s/%s) — portable IRC client for Windows and Linux", AppVersion, runtime.GOOS, runtime.GOARCH)
}

// ctcpAnswer is our reply to a CTCP request ("" = don't know it).
func ctcpAnswer(cmd, arg string) string {
	switch cmd {
	case "VERSION":
		return versionString()
	case "PING":
		return arg
	case "TIME":
		return time.Now().Format(time.RFC1123)
	case "CLIENTINFO":
		return "ACTION CLIENTINFO DCC FINGER PING SOURCE TIME USERINFO VERSION"
	case "FINGER", "USERINFO":
		return "IRC Client " + AppVersion
	case "SOURCE":
		return "portable IRC client written in Go (source included with the program)"
	}
	return ""
}

// CTCP asks someone's client something (VERSION, PING, TIME, CLIENTINFO, ...).
// The answer appears in the server window (and their private window if open).
func (c *Conn) CTCP(nick, what, extra string) error {
	if err := c.online(); err != nil {
		return err
	}
	what = strings.ToUpper(strings.TrimSpace(what))
	if what == "" {
		return errors.New("which CTCP? e.g. VERSION, PING, TIME")
	}
	arg := extra
	if what == "PING" {
		arg = strconv.FormatInt(time.Now().UnixMilli(), 10)
	}
	line := "PRIVMSG " + nick + " :\x01" + what
	if arg != "" {
		line += " " + arg
	}
	if err := c.writeLine(line + "\x01"); err != nil {
		return err
	}
	c.dccNote2(nick, "info", fmt.Sprintf("asked %s for CTCP %s…", nick, what))
	return nil
}

// ctcpReply shows the answer to one of our CTCP requests. Caller holds c.mu.
func (c *Conn) ctcpReply(from, cmd, rest string) {
	text := fmt.Sprintf("CTCP %s reply from %s: %s", cmd, from, rest)
	if cmd == "PING" {
		if ms, err := strconv.ParseInt(strings.TrimSpace(rest), 10, 64); err == nil {
			lag := time.Since(time.UnixMilli(ms))
			text = fmt.Sprintf("Ping reply from %s: %.2f seconds", from, lag.Seconds())
		}
	}
	c.addLine(c.buffers["*"], Line{Kind: "info", Text: text})
	if b, ok := c.buffers[strings.ToLower(from)]; ok && b.Kind == "query" {
		c.addLine(b, Line{Kind: "info", Text: text})
	}
}

// dccNote2 is like dccNote but labelled for CTCP.
func (c *Conn) dccNote2(nick, kind, text string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.addLine(c.buffers["*"], Line{Kind: kind, Text: text})
	if b, ok := c.buffers[strings.ToLower(nick)]; ok && b.Kind == "query" {
		c.addLine(b, Line{Kind: kind, Text: text})
	}
}
