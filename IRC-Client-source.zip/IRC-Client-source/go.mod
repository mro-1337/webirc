module ircclient

go 1.24.7

replace (
	fyne.io/fyne/v2 => github.com/fyne-io/fyne/v2 v2.7.1
	fyne.io/systray => github.com/fyne-io/systray v1.11.1-0.20250603113521-ca66a66d8b58
	golang.org/x/crypto => github.com/golang/crypto v0.33.0
	golang.org/x/exp => github.com/golang/exp v0.0.0-20240506185415-9bf2ced13842
	golang.org/x/exp/shiny => github.com/golang/exp/shiny v0.0.0-20240506185415-9bf2ced13842
	golang.org/x/image => github.com/golang/image v0.24.0
	golang.org/x/mod => github.com/golang/mod v0.20.0
	golang.org/x/net => github.com/golang/net v0.35.0
	golang.org/x/sync => github.com/golang/sync v0.11.0
	golang.org/x/sys => github.com/golang/sys v0.38.0
	golang.org/x/telemetry => github.com/golang/telemetry v0.0.0-20240521205824-bda55230c457
	golang.org/x/term => github.com/golang/term v0.37.0
	golang.org/x/text => github.com/golang/text v0.31.0
	golang.org/x/tools => github.com/golang/tools v0.24.1
	golang.org/x/tools/go/vcs => github.com/golang/tools/go/vcs v0.1.0-deprecated
	golang.org/x/vuln => github.com/golang/vuln v1.0.4
	golang.org/x/xerrors => github.com/golang/xerrors v0.0.0-20240903120638-7835f813f4da
	gopkg.in/check.v1 => github.com/go-check/check v0.0.0-20200227125254-8fa46927fb4f
	gopkg.in/yaml.v3 => github.com/go-yaml/yaml/v3 v3.0.1
)

require (
	fyne.io/fyne/v2 v2.7.1
	github.com/atotto/clipboard v0.1.4
	github.com/gdamore/tcell/v2 v2.13.10
	github.com/rivo/tview v0.42.0
	golang.org/x/image v0.24.0
)

require (
	fyne.io/systray v1.11.1-0.20250603113521-ca66a66d8b58 // indirect
	github.com/BurntSushi/toml v1.5.0 // indirect
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/fredbi/uri v1.1.1 // indirect
	github.com/fsnotify/fsnotify v1.9.0 // indirect
	github.com/fyne-io/gl-js v0.2.0 // indirect
	github.com/fyne-io/glfw-js v0.3.0 // indirect
	github.com/fyne-io/image v0.1.1 // indirect
	github.com/fyne-io/oksvg v0.2.0 // indirect
	github.com/gdamore/encoding v1.0.1 // indirect
	github.com/go-gl/gl v0.0.0-20231021071112-07e5d0ea2e71 // indirect
	github.com/go-gl/glfw/v3.3/glfw v0.0.0-20240506104042-037f3cc74f2a // indirect
	github.com/go-text/render v0.2.0 // indirect
	github.com/go-text/typesetting v0.2.1 // indirect
	github.com/godbus/dbus/v5 v5.1.0 // indirect
	github.com/hack-pad/go-indexeddb v0.3.2 // indirect
	github.com/hack-pad/safejs v0.1.0 // indirect
	github.com/jeandeaual/go-locale v0.0.0-20250612000132-0ef82f21eade // indirect
	github.com/jsummers/gobmp v0.0.0-20230614200233-a9de23ed2e25 // indirect
	github.com/kr/text v0.2.0 // indirect
	github.com/lucasb-eyer/go-colorful v1.3.0 // indirect
	github.com/nfnt/resize v0.0.0-20180221191011-83c6a9932646 // indirect
	github.com/nicksnyder/go-i18n/v2 v2.5.1 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	github.com/rivo/uniseg v0.4.7 // indirect
	github.com/rymdport/portal v0.4.2 // indirect
	github.com/srwiley/oksvg v0.0.0-20221011165216-be6e8873101c // indirect
	github.com/srwiley/rasterx v0.0.0-20220730225603-2ab79fcdd4ef // indirect
	github.com/stretchr/testify v1.11.1 // indirect
	github.com/yuin/goldmark v1.7.8 // indirect
	golang.org/x/net v0.35.0 // indirect
	golang.org/x/sys v0.38.0 // indirect
	golang.org/x/term v0.37.0 // indirect
	golang.org/x/text v0.31.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
